"""Native URL capture into Sources/inbox/ (Second_brain clip.py parity / ADR-014)."""

from __future__ import annotations

import hashlib
import io
import ipaddress
import json
import re
import socket
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from narr.vault import Vault, slugify, write_text_atomic

DEFAULT_TIMEOUT_SECONDS = 15
MAX_PAYLOAD_BYTES = 20 * 1024 * 1024  # 20 MB

YOUTUBE_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"}


class SecurityError(Exception):
    """Raised when a URL violates SSRF or network boundary security policies."""


def is_ip_blocked(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    """Return True if an IP address belongs to loopback, private, link-local, multicast, or reserved ranges.

    Args:
        ip: IPv4 or IPv6 address to check.

    Returns:
        True if the address is blocked under SSRF policies, False otherwise.
    """
    return ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified


def validate_url_security(url: str) -> None:
    """Validate that a URL uses http/https and does not target private or loopback networks (SSRF guard).

    Args:
        url: URL string to inspect.

    Raises:
        SecurityError: If scheme is not http/https, hostname is missing, or resolves to blocked IP ranges.
    """
    parsed = urllib.parse.urlparse(url)
    scheme = (parsed.scheme or "").lower()
    if scheme not in ("http", "https"):
        raise SecurityError(f"Prohibited URL scheme '{parsed.scheme}': only http and https are permitted.")

    hostname = parsed.hostname
    if not hostname:
        raise SecurityError(f"Invalid URL: missing hostname in '{url}'.")

    # Check if hostname is an IP literal
    clean_host = hostname.strip("[]")
    is_ip = False
    try:
        ip = ipaddress.ip_address(clean_host)
        is_ip = True
    except ValueError:
        pass

    if is_ip:
        if is_ip_blocked(ip):
            raise SecurityError(f"SSRF protection: prohibited IP address '{ip}'.")
        return

    # Resolve domain name to IP addresses
    try:
        addr_info = socket.getaddrinfo(hostname, None)
    except socket.gaierror as exc:
        raise SecurityError(f"SSRF protection: could not resolve hostname '{hostname}': {exc}")

    for item in addr_info:
        sockaddr = item[4]
        ip_str = sockaddr[0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            continue

        if is_ip_blocked(ip):
            raise SecurityError(f"SSRF protection: hostname '{hostname}' resolves to prohibited address '{ip}'.")


def _clean_vtt_transcript(vtt_text: str) -> str:
    """Strip WEBVTT timestamps, headers, and cue IDs to produce clean readable text.

    Args:
        vtt_text: Raw VTT subtitle transcript string.

    Returns:
        Joined readable text without time markers or markup tags.
    """
    lines: list[str] = []
    seen: str = ""
    for line in vtt_text.splitlines():
        trimmed = line.strip()
        if not trimmed:
            continue
        if trimmed.startswith("WEBVTT") or "-->" in trimmed or trimmed.isdigit():
            continue
        cleaned = re.sub(r"<[^>]+>", "", trimmed).strip()
        if cleaned and cleaned != seen:
            lines.append(cleaned)
            seen = cleaned
    return "\n\n".join(lines)


def extract_youtube(url: str) -> tuple[str, str]:
    """Extract video title, description, and subtitle transcript using yt-dlp.

    Args:
        url: Cleaned YouTube video URL.

    Returns:
        Tuple of (title, markdown_body).

    Raises:
        RuntimeError: If yt-dlp is not installed.
    """
    try:
        import yt_dlp
    except ImportError:
        raise RuntimeError("yt-dlp is required for YouTube extraction. Install with pip install 'narr[capture]'.")

    ydl_opts = {
        "skip_download": True,
        "writesubtitles": True,
        "writeautomaticsub": True,
        "subtitleslangs": ["en", "pt", "es", "all"],
        "quiet": True,
        "no_warnings": True,
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False) or {}

    title = info.get("title") or "YouTube Video"
    description = (info.get("description") or "").strip()

    # Search subtitles
    sub_text = ""
    subtitles = info.get("subtitles") or info.get("automatic_captions") or {}
    for lang in ["en", "pt", "es"]:
        tracks = subtitles.get(lang) or []
        for track in tracks:
            if "data" in track:
                sub_text = _clean_vtt_transcript(track["data"])
                break
        if sub_text:
            break

    if not sub_text and subtitles:
        # Pick first available track with data
        for _lang, tracks in subtitles.items():
            for track in tracks:
                if "data" in track:
                    sub_text = _clean_vtt_transcript(track["data"])
                    break
            if sub_text:
                break

    body_parts: list[str] = []
    if description:
        body_parts.append(f"## Overview\n\n{description}")
    if sub_text:
        body_parts.append(f"## Transcript\n\n{sub_text}")
    elif not description:
        body_parts.append("*(No transcript or description extracted)*")

    return title, "\n\n".join(body_parts)


def extract_pdf(raw_bytes: bytes, fallback_title: str = "") -> tuple[str, str]:
    """Extract clean text page-by-page from PDF document using pypdf.

    Args:
        raw_bytes: Raw binary bytes of PDF document.
        fallback_title: Fallback title if PDF metadata lacks a title.

    Returns:
        Tuple of (title, markdown_content).

    Raises:
        RuntimeError: If pypdf is not installed.
    """
    try:
        import pypdf
    except ImportError:
        raise RuntimeError("pypdf is required for PDF extraction. Install with pip install 'narr[capture]'.")

    reader = pypdf.PdfReader(io.BytesIO(raw_bytes))
    title = ""
    if reader.metadata:
        title = getattr(reader.metadata, "title", None) or ""

    if not title:
        title = fallback_title or "PDF Document"

    page_blocks: list[str] = []
    for i, page in enumerate(reader.pages):
        page_text = (page.extract_text() or "").strip()
        if page_text:
            page_blocks.append(f"## Page {i + 1}\n\n{page_text}")

    content = "\n\n".join(page_blocks) if page_blocks else "*(No readable text found in PDF document)*"
    return title, content


def extract_html(raw_html: str, fallback_title: str = "") -> tuple[str, str]:
    """Extract article title and markdown text from HTML via trafilatura with clean fallback.

    Args:
        raw_html: Raw HTML string of webpage.
        fallback_title: Fallback title if title cannot be detected.

    Returns:
        Tuple of (title, markdown_content).
    """
    markdown_content: str = ""
    title: str = ""
    try:
        import trafilatura

        extracted = trafilatura.extract(raw_html, include_links=True, output_format="markdown")
        if extracted:
            markdown_content = extracted
            meta_traf = trafilatura.bare_extraction(raw_html)
            if meta_traf:
                t_val = getattr(meta_traf, "title", None) or (meta_traf.get("title") if isinstance(meta_traf, dict) else None)
                if t_val:
                    title = str(t_val)
    except ImportError:
        pass

    if not title:
        title_m = re.search(r"<title>(.*?)</title>", raw_html, re.IGNORECASE | re.DOTALL)
        if title_m:
            title = title_m.group(1).strip()

    if not markdown_content:
        body_text = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", raw_html, flags=re.DOTALL | re.IGNORECASE)
        body_text = re.sub(r"<[^>]+>", " ", body_text)
        markdown_content = "\n\n".join([line.strip() for line in body_text.splitlines() if line.strip()])

    if not title:
        title = fallback_title or "Captured_Source"

    return title, markdown_content


def clip_url(url: str, vault: Vault) -> Path:
    """Clip webpage or media content and stage it in Sources/inbox/ with metadata sidecar.

    Args:
        url: URL of public webpage or media item.
        vault: Target Vault instance.

    Returns:
        Path to the staged markdown source file in Sources/inbox/.

    Raises:
        SecurityError: If URL violates SSRF guards or payload exceeds size limit.
    """
    # Enforce SSRF protection before any network request
    validate_url_security(url)

    parsed = urllib.parse.urlparse(url)

    # Clean tracking query parameters
    clean_query = urllib.parse.parse_qsl(parsed.query)
    filtered_query = [(k, v) for k, v in clean_query if not k.startswith("utm_") and k not in ("ref", "fbclid")]
    clean_url = urllib.parse.urlunparse(
        (
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            parsed.params,
            urllib.parse.urlencode(filtered_query),
            "",
        )
    )

    # Re-validate clean_url
    validate_url_security(clean_url)

    hostname = (parsed.hostname or "").lower()
    path_stem = Path(parsed.path).stem or "Captured_Source"

    title: str = ""
    markdown_content: str = ""

    # 1. Dispatch YouTube
    if hostname in YOUTUBE_HOSTS or "youtube.com" in hostname or "youtu.be" in hostname:
        title, markdown_content = extract_youtube(clean_url)
    else:
        # Fetch webpage or PDF stream with timeout and capped streaming
        req = urllib.request.Request(
            clean_url,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
        )
        with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT_SECONDS) as resp:
            chunks: list[bytes] = []
            total_bytes = 0
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                total_bytes += len(chunk)
                if total_bytes > MAX_PAYLOAD_BYTES:
                    raise SecurityError(f"Response payload exceeds maximum allowed size ({MAX_PAYLOAD_BYTES} bytes).")
                chunks.append(chunk)

            raw_bytes = b"".join(chunks)
            content_type = (resp.headers.get("Content-Type") or "").lower()

            # 2. Dispatch PDF
            if parsed.path.lower().endswith(".pdf") or content_type.startswith("application/pdf"):
                title, markdown_content = extract_pdf(raw_bytes, fallback_title=path_stem)
            else:
                charset = resp.headers.get_content_charset() or "utf-8"
                raw_html = raw_bytes.decode(charset, errors="replace")
                title, markdown_content = extract_html(raw_html, fallback_title=path_stem)

    if not title:
        title = path_stem

    clean_slug = slugify(title)[:60]
    date_str = datetime.now(UTC).strftime("%Y%m%d")
    source_id = f"SRC-{date_str}-{clean_slug}"

    inbox_dir = vault.sources_inbox_dir
    inbox_dir.mkdir(parents=True, exist_ok=True)

    dest_file = inbox_dir / f"{source_id}.md"
    sidecar_file = inbox_dir / f"{source_id}.meta.json"

    # Frontmatter + content
    full_text = f"""---
uid: "{source_id}"
type: source
title: "{title}"
url: "{clean_url}"
status: inbox
captured: "{datetime.now(UTC).isoformat()}"
---
# {title}

{markdown_content}
"""
    dest_file.write_text(full_text, encoding="utf-8")

    # Compute SHA-256
    sha256 = hashlib.sha256(dest_file.read_bytes()).hexdigest()
    sidecar_meta = {
        "source_id": source_id,
        "title": title,
        "url": clean_url,
        "sha256": sha256,
        "status": "inbox",
        "captured": datetime.now(UTC).isoformat(),
    }
    sidecar_file.write_text(json.dumps(sidecar_meta, indent=2), encoding="utf-8")

    # Also register in central Sources/.meta.json for full parity with capture_source
    meta_path = vault.sources_meta_path
    central_meta: dict[str, Any] = {}
    if meta_path.is_file():
        try:
            central_meta = json.loads(meta_path.read_text(encoding="utf-8")) or {}
        except Exception:
            central_meta = {}
    central_meta[source_id] = sidecar_meta
    write_text_atomic(meta_path, json.dumps(central_meta, indent=2, ensure_ascii=False) + "\n")

    return dest_file

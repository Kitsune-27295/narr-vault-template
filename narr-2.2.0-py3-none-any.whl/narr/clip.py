"""Native URL capture into Sources/inbox/ (Second_brain clip.py parity / ADR-014)."""

from __future__ import annotations

import hashlib
import json
import re
import urllib.parse
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

from narr.vault import Vault

# SSRF blocklist
BLOCKED_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0", "169.254.169.254"}


def _slugify(text: str) -> str:
    cleaned = re.sub(r"[^\w\s-]", "", text).strip().replace(" ", "_")
    return re.sub(r"_+", "_", cleaned)


def clip_url(url: str, vault: Vault) -> Path:
    """Clip webpage content and stage it in Sources/inbox/."""
    parsed = urllib.parse.urlparse(url)
    if parsed.hostname and parsed.hostname.lower() in BLOCKED_HOSTS:
        raise ValueError(f"SSRF protection: prohibited host '{parsed.hostname}'")

    # Clean tracking query parameters
    clean_query = urllib.parse.parse_qsl(parsed.query)
    filtered_query = [(k, v) for k, v in clean_query if not k.startswith("utm_") and k not in ("ref", "fbclid")]
    clean_url = urllib.parse.urlunparse(
        (
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            parsed.params,
            urllib.parse.urlencode(filtered_query),
            "",
        )
    )

    # Fetch webpage
    req = urllib.request.Request(clean_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw_bytes = resp.read()
        charset = resp.headers.get_content_charset() or "utf-8"
        raw_html = raw_bytes.decode(charset, errors="replace")

    # Try trafilatura if available, else clean text fallback
    markdown_content: str = ""
    title: str = ""
    try:
        import trafilatura

        extracted = trafilatura.extract(raw_html, include_links=True, output_format="markdown")
        if extracted:
            markdown_content = extracted
            meta_traf = trafilatura.bare_extraction(raw_html)
            if meta_traf:
                t_val = getattr(meta_traf, "title", None) or (meta_traf.get("title") if isinstance(meta_traf, dict) else None)
                if t_val:
                    title = str(t_val)
    except ImportError:
        pass

    if not markdown_content:
        # Fallback extraction: strip script/style, extract title and text
        title_m = re.search(r"<title>(.*?)</title>", raw_html, re.IGNORECASE | re.DOTALL)
        title = title_m.group(1).strip() if title_m else Path(parsed.path).stem or "Captured_Source"
        body_text = re.sub(r"<(script|style)[^>]*>.*?</\1>", "", raw_html, flags=re.DOTALL | re.IGNORECASE)
        body_text = re.sub(r"<[^>]+>", " ", body_text)
        markdown_content = "\n".join([line.strip() for line in body_text.splitlines() if line.strip()])

    if not title:
        title = Path(parsed.path).stem or "Captured_Source"

    clean_title = _slugify(title)[:60]
    date_str = datetime.now(UTC).strftime("%Y%m%d")
    source_id = f"SRC-{date_str}-{clean_title}"

    inbox_dir = vault.root / "01_Canon_and_Divergence" / "Sources" / "inbox"
    inbox_dir.mkdir(parents=True, exist_ok=True)

    dest_file = inbox_dir / f"{source_id}.md"
    sidecar_file = inbox_dir / f"{source_id}.meta.json"

    # Frontmatter + content
    full_text = f"""---
uid: "{source_id}"
type: source
title: "{title}"
url: "{clean_url}"
status: inbox
captured: "{datetime.now(UTC).isoformat()}"
---
# {title}

{markdown_content}
"""
    dest_file.write_text(full_text, encoding="utf-8")

    # Compute SHA-256
    sha256 = hashlib.sha256(dest_file.read_bytes()).hexdigest()
    sidecar_meta = {
        "source_id": source_id,
        "title": title,
        "url": clean_url,
        "sha256": sha256,
        "status": "inbox",
        "captured": datetime.now(UTC).isoformat(),
    }
    sidecar_file.write_text(json.dumps(sidecar_meta, indent=2), encoding="utf-8")

    return dest_file

"""Typer CLI interface for the Narrative Story Bible Framework."""

from __future__ import annotations

import json
import sys
from dataclasses import asdict
from pathlib import Path

import typer

from narr import __version__
from narr.blueprint import create_page
from narr.candidates import find_candidates
from narr.checks import run_all_checks
from narr.clip import clip_url
from narr.consolidate import find_consolidation_leads
from narr.decide import create_decision, supersede_decision
from narr.doctor import run_doctor
from narr.evaluate import evaluate_retrieval
from narr.graph import analyze_graph
from narr.handoff import session_close
from narr.importer import import_folder
from narr.ingest import capture_source, close_ingest, get_pending, plan_ingest, skip_ingest
from narr.memory import session_brief
from narr.pageview import format_page_view, get_page_view
from narr.preset import apply_preset, get_preset_status, list_presets, rollback_preset
from narr.promote import promote_note
from narr.rag import assemble_chapter_context
from narr.related import get_related
from narr.rename import build_rename_plan, execute_rename, undo_last_rename
from narr.search import search
from narr.translate import check_translation_parity
from narr.upgrade import upgrade_vault
from narr.vault import Vault, VaultError, read_text

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

app = typer.Typer(
    name="narr",
    help="Lean CLI toolkit for Narrative Story Bible Framework.",
    no_args_is_help=True,
)


def _version_callback(show: bool) -> None:
    if show:
        from narr import __version__

        typer.echo(f"narr {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    pass


def get_vault(target: Path | None = None) -> Vault:
    try:
        return Vault.find(target)
    except VaultError as exc:
        if target is None:
            candidate = Path.cwd() / "template"
            if (candidate / "vault.yaml").is_file():
                typer.secho("Notice: No vault.yaml in working directory; using ./template", fg=typer.colors.CYAN, err=True)
                return Vault.find(candidate)
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@app.command()
def version():
    """Display CLI version."""
    typer.echo(f"narr version {__version__}")


@app.command()
def lint(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    path: str | None = typer.Option(None, "--path", "-p", help="Filter linting by file or zone path"),
    json_output: bool = typer.Option(False, "--json", help="Output findings as JSON"),
    strict: bool = typer.Option(False, "--strict", help="Fail with exit code 1 on warnings as well as errors"),
):
    """Run all vault invariants and structural linters."""
    vault = get_vault(vault_path)
    findings = run_all_checks(vault, path_filter=path)
    errors = [f for f in findings if f.severity == "error"]
    warnings = [f for f in findings if f.severity == "warning"]

    if json_output:
        data = [{"code": f.code, "path": f.path, "message": f.message, "severity": f.severity} for f in findings]
        typer.echo(json.dumps(data, indent=2))
        should_fail = bool(errors or (strict and warnings))
        raise typer.Exit(1 if should_fail else 0)

    if not findings:
        typer.secho("[OK] Vault 100% compliant (0 errors, 0 warnings)", fg=typer.colors.GREEN)
        return

    for f in findings:
        color = typer.colors.RED if f.severity == "error" else typer.colors.YELLOW
        prefix = "ERROR" if f.severity == "error" else "WARN "
        typer.secho(f"[{prefix}] [{f.code}] {f.path}: {f.message}", fg=color)

    typer.echo(f"\nTotal: {len(errors)} error(s), {len(warnings)} warning(s)")
    if errors or (strict and warnings):
        raise typer.Exit(1)


@app.command()
def crosscheck(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output crosscheck results as JSON"),
):
    """Verify narrative consistency across Chekhov guns, powers, and foreshadowing."""
    vault = get_vault(vault_path)
    findings = run_all_checks(vault)
    continuity_findings = [f for f in findings if f.code in ("VAL019", "VAL020", "VAL025", "VAL028", "VAL029", "VAL037")]

    if json_output:
        data = [{"code": f.code, "path": f.path, "message": f.message} for f in continuity_findings]
        typer.echo(json.dumps(data, indent=2))
        raise typer.Exit(1 if continuity_findings else 0)

    if not continuity_findings:
        typer.secho("[OK] All narrative constants, Chekhov items, and foreshadowing consistent (0 issues)", fg=typer.colors.GREEN)
        return

    for f in continuity_findings:
        typer.secho(f"[{f.code}] {f.path}: {f.message}", fg=typer.colors.YELLOW)
    raise typer.Exit(1)


@app.command(name="new")
def new_page(
    page_type: str = typer.Argument(
        ...,
        help="Type: character, location, faction, power_system, power, technique, baseline, event, arc, pod, design_sheet, chapter_pt, chapter_es",
    ),
    title: str = typer.Argument(..., help="Title of the entity or page"),
    source_ref: str | None = typer.Option(None, "--source-ref", "-s", help="Source reference for chapter translation"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    as_json: bool = typer.Option(False, "--json", help="Output created page path as JSON"),
):
    """Scaffold a new typed page from blueprint with proper frontmatter."""
    vault = get_vault(vault_path) if vault_path is not None else get_vault()
    try:
        created = create_page(vault, page_type, title, source_ref=source_ref)
        if as_json:
            typer.echo(json.dumps({"status": "ok", "path": vault.rel(created), "absolute": str(created)}, indent=2))
            return
        typer.secho(f"[OK] Created: {vault.rel(created)}", fg=typer.colors.GREEN)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@app.command(name="search")
def search_cmd(
    query: str = typer.Argument(..., help="Search terms"),
    limit: int = typer.Option(10, "-k", "--limit", help="Maximum results"),
    zone: str | None = typer.Option(None, "--zone", "-z", help="Filter by zone"),
    page_type: str | None = typer.Option(None, "--type", "-t", help="Filter by page type"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
):
    """Full-text BM25 search over the vault."""
    vault = get_vault(vault_path)
    hits = search(vault, query=query, limit=limit, zone=zone, ptype=page_type)

    if json_output:
        data = [{"rel_path": h.rel_path, "title": h.title, "type": h.page_type, "score": h.score, "snippet": h.snippet} for h in hits]
        typer.echo(json.dumps(data, indent=2))
        return

    if not hits:
        typer.echo("No matching documents found.")
        return

    for h in hits:
        typer.secho(f"[{h.page_type}] {h.title} ({h.rel_path}) — score: {h.score}", fg=typer.colors.CYAN)
        if h.snippet:
            typer.echo(f"   {h.snippet}\n")


# Subcommand group: session
session_app = typer.Typer(name="session", help="Session lifecycle and memory commands")
app.add_typer(session_app)

# Subcommand group: memory (alias / parity for cognitive memory commands)
memory_app = typer.Typer(name="memory", help="Cognitive memory management commands")
app.add_typer(memory_app)


@session_app.command(name="brief")
def session_brief_cmd(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root (default: current directory or ./template)"),
) -> None:
    """Compile and display operational session brief."""
    vault = get_vault(vault_path)
    typer.echo(session_brief(vault))


@memory_app.command(name="brief")
def memory_brief_cmd(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root (default: current directory or ./template)"),
) -> None:
    """Compile and display operational session brief (alias for 'narr session brief')."""
    vault = get_vault(vault_path)
    typer.echo(session_brief(vault))


@session_app.command(name="close")
def session_close_cmd(
    done: str = typer.Option(..., "--done", "-d", help="Summary of work completed"),
    next_action: str = typer.Option(..., "--next", "-n", help="Next immediate priority"),
    decided: str = typer.Option(..., "--decided", help="Key decisions made"),
    questions: str | None = typer.Option(None, "--questions", "-q", help="Open questions"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root (default: current directory or ./template)"),
) -> None:
    """Close session, update handoff ledger, and trim hot.md."""
    vault = get_vault(vault_path)
    msg = session_close(vault, done=done, next_action=next_action, decided=decided, questions=questions)
    typer.secho(f"[OK] {msg}", fg=typer.colors.GREEN)


# Subcommand group: rag
rag_app = typer.Typer(name="rag", help="Fiction-Conscious RAG assembler")
app.add_typer(rag_app)


@rag_app.command(name="context")
def rag_context_cmd(
    chapter: int = typer.Option(..., "--chapter", "-c", help="Target chapter number"),
    character: str | None = typer.Option(None, "--character", help="Character focus for lore injection"),
    budget: int = typer.Option(3500, "--budget", "-b", help="Token budget"),
):
    """Assemble deterministic fiction context block for chapter writing."""
    vault = get_vault()
    ctx = assemble_chapter_context(vault, chapter_num=chapter, character_focus=character, budget_tokens=budget)
    typer.echo(ctx)


# Subcommand group: preset
preset_app = typer.Typer(name="preset", help="Fandom preset management")
app.add_typer(preset_app)


@preset_app.command(name="list")
def preset_list_cmd(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    as_json: bool = typer.Option(False, "--json", help="Output presets as JSON"),
):
    """List available fandom presets in Meta/Presets/."""
    vault = get_vault(vault_path) if vault_path is not None else get_vault()
    presets = list_presets(vault)
    if as_json:
        typer.echo(json.dumps(presets, indent=2, ensure_ascii=False))
        return
    if not presets:
        typer.echo("No presets found in Meta/Presets/.")
        return
    for p in presets:
        typer.secho(f"• {p.get('display_name', p['_folder'])} ({p['_folder']}) - v{p.get('version', '1.0')}", fg=typer.colors.CYAN)
        if p.get("description"):
            typer.echo(f"  {p['description']}")


@preset_app.command(name="apply")
def preset_apply_cmd(
    name: str = typer.Argument(..., help="Preset name"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    as_json: bool = typer.Option(False, "--json", help="Output result as JSON"),
):
    """Apply a fandom preset to the vault."""
    vault = get_vault(vault_path) if vault_path is not None else get_vault()
    try:
        msg = apply_preset(vault, name)
        if as_json:
            typer.echo(json.dumps({"status": "ok", "preset": name, "message": msg}, indent=2))
            return
        typer.secho(f"[OK] {msg}", fg=typer.colors.GREEN)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@preset_app.command(name="status")
def preset_status_cmd(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    as_json: bool = typer.Option(False, "--json", help="Output preset status as JSON"),
):
    """Show applied and available fandom presets."""
    vault = get_vault(vault_path) if vault_path is not None else get_vault()
    status = get_preset_status(vault)

    if as_json:
        typer.echo(json.dumps(status, indent=2, ensure_ascii=False))
        return

    typer.secho("=== Applied Presets ===", fg=typer.colors.CYAN, bold=True)
    if not status["applied"]:
        typer.echo("  (None)")
    else:
        for p in status["applied"]:
            typer.echo(
                f"  • {p.get('display_name', p.get('name', ''))} (v{p.get('version', '1.0')}) - applied {p.get('applied_at', 'unknown')}"
            )

    typer.echo("")
    typer.secho("=== Available Presets ===", fg=typer.colors.CYAN, bold=True)
    if not status["available"]:
        typer.echo("  (None)")
    else:
        for p in status["available"]:
            typer.echo(f"  • {p.get('display_name', p.get('_folder', ''))} ({p.get('_folder', '')}) - v{p.get('version', '1.0')}")

    if status.get("custom_types"):
        typer.echo("")
        typer.secho("=== Custom Types ===", fg=typer.colors.CYAN, bold=True)
        typer.echo("  " + ", ".join(status["custom_types"]))


@preset_app.command(name="remove")
def preset_remove_cmd(
    name: str = typer.Argument(..., help="Preset name to remove/rollback"),
    force: bool = typer.Option(False, "--force", "-f", help="Force deletion even if template files were modified"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    as_json: bool = typer.Option(False, "--json", help="Output rollback report as JSON"),
):
    """Safely roll back an applied preset."""
    vault = get_vault(vault_path) if vault_path is not None else get_vault()
    try:
        report = rollback_preset(vault, name, force=force)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    if as_json:
        typer.echo(json.dumps(asdict(report), indent=2, ensure_ascii=False))
        return

    typer.secho(f"[OK] Preset '{name}' removed successfully.", fg=typer.colors.GREEN)
    if report.removed_seeds:
        typer.echo(f"  Removed templates ({len(report.removed_seeds)}): " + ", ".join(report.removed_seeds))
    if report.kept_seeds:
        typer.secho(f"  Kept modified templates ({len(report.kept_seeds)}): " + ", ".join(report.kept_seeds), fg=typer.colors.YELLOW)
    if report.removed_types:
        typer.echo("  Removed unused custom types: " + ", ".join(report.removed_types))
    for warn in report.warnings:
        typer.secho(f"  Warning: {warn}", fg=typer.colors.YELLOW)


@app.command()
def graph(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output link graph results as JSON"),
):
    """Analyze wikilink health: dead links, orphans, hubs, and cycles."""
    vault = get_vault(vault_path)
    rep = analyze_graph(vault)
    if json_output:
        typer.echo(
            json.dumps(
                {
                    "total_pages": rep.total_pages,
                    "total_links": rep.total_links,
                    "dead_links": rep.dead_links,
                    "orphans": rep.orphans,
                    "hubs": rep.hubs,
                    "cycles": rep.cycles,
                },
                indent=2,
            )
        )
        return
    typer.secho(f"Vault Link Graph: {rep.total_pages} pages, {rep.total_links} links", fg=typer.colors.CYAN)
    if rep.dead_links:
        typer.secho(f"\nDead Links ({len(rep.dead_links)}):", fg=typer.colors.RED)
        for src, dst in rep.dead_links[:10]:
            typer.echo(f"  {src} -> [[{dst}]]")
    if rep.orphans:
        typer.secho(f"\nOrphan Pages (0 inbound links, {len(rep.orphans)}):", fg=typer.colors.YELLOW)
        for o in rep.orphans[:10]:
            typer.echo(f"  {o}")
    if rep.hubs:
        typer.secho("\nTop Hubs:", fg=typer.colors.GREEN)
        for title, count in rep.hubs[:5]:
            typer.echo(f"  {title}: {count} inbound links")
    if rep.cycles:
        typer.secho(f"\nDetected Link Cycles ({len(rep.cycles)}):", fg=typer.colors.RED)
        for cyc in rep.cycles[:10]:
            typer.echo(f"  {' -> '.join(cyc)}")


@app.command()
def related(
    title: str = typer.Argument(..., help="Page title or stem"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output related context as JSON"),
):
    """Show inbound and outbound links for a page."""
    vault = get_vault(vault_path)
    rel = get_related(vault, title)
    if json_output:
        typer.echo(json.dumps(rel, indent=2))
        return
    typer.secho(f"Related Context for: {title}", fg=typer.colors.CYAN)
    typer.echo(f"Outbound links ({len(rel['outbound'])}): {', '.join(rel['outbound']) if rel['outbound'] else 'None'}")
    typer.echo(f"Inbound links ({len(rel['inbound'])}): {', '.join(rel['inbound']) if rel['inbound'] else 'None'}")
    typer.echo(f"Shared tags ({len(rel['shared_tags'])}): {', '.join(rel['shared_tags']) if rel['shared_tags'] else 'None'}")


@app.command()
def doctor(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output doctor results as JSON"),
):
    """Run full environment and vault diagnostics."""
    vault = get_vault(vault_path)
    diags = run_doctor(vault)
    if json_output:
        typer.echo(json.dumps([{"name": d.name, "status": d.status, "detail": d.detail} for d in diags], indent=2))
        return
    for d in diags:
        color = typer.colors.GREEN if d.status else typer.colors.RED
        status_text = "PASS" if d.status else "FAIL"
        typer.secho(f"[{status_text}] {d.name}: {d.detail}", fg=color)


@app.command()
def upgrade(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview upgrade actions without modifying files"),
    json_output: bool = typer.Option(False, "--json", help="Output plan as JSON"),
):
    """Synchronize agent rules, skills, and refresh framework files."""
    vault = get_vault(vault_path)
    changes = upgrade_vault(vault, dry_run=dry_run)
    if json_output:
        typer.echo(json.dumps([c.to_dict() for c in changes], indent=2))
        return
    todo = [c for c in changes if c.action != "current"]
    if not todo:
        typer.echo("Everything up to date. Zero changes needed.")
        return
    for c in todo:
        typer.secho(f"  {c.action}: {c.path} ({c.detail})", fg=typer.colors.GREEN)


# Subcommand group: ingest
ingest_app = typer.Typer(name="ingest", help="Canon ingestion pipeline (Second_brain parity)")
app.add_typer(ingest_app)


@app.command(name="capture")
@ingest_app.command(name="capture")
def capture_cmd(
    file_path: Path = typer.Argument(..., help="Path to raw source file to capture into inbox"),
    url: str | None = typer.Option(None, "--url", "-u", help="Original URL source link"),
    custom_id: str | None = typer.Option(None, "--id", help="Explicit custom source ID (SRC-*)"),
    vault: Path | None = typer.Option(None, "--vault", help="Path to story bible vault root"),
):
    """Capture raw canon source into Sources/inbox/ with sha256 checksum."""
    v = get_vault(vault)
    try:
        sid = capture_source(v, file_path, url=url, custom_id=custom_id)
        typer.secho(f"[OK] Captured: {sid} -> 01_Canon_and_Divergence/Sources/inbox/", fg=typer.colors.GREEN)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@ingest_app.command(name="plan")
def ingest_plan_cmd(
    source_id: str = typer.Argument(..., help="Source ID in Sources/ or Sources/inbox/"),
    limit: int = typer.Option(10, "-k", "--limit", help="Max candidate baselines to display"),
    json_output: bool = typer.Option(False, "--json", help="Output plan as JSON"),
    vault: Path | None = typer.Option(None, "--vault", help="Path to story bible vault root"),
):
    """Context and candidate baseline plan for compiling an ingested source."""
    v = get_vault(vault)
    try:
        p = plan_ingest(v, source_id, limit=limit)
        if json_output:
            typer.echo(json.dumps(p, indent=2))
            return
        typer.secho(f"Ingest Plan for: {p['source_id']} ({p['status']})", fg=typer.colors.CYAN)
        typer.echo(f"Title: {p['title']}")
        typer.echo(f"Size: {p['size_chars']} chars")
        if p["currently_citing_pages"]:
            typer.secho("Currently citing pages:", fg=typer.colors.GREEN)
            for c in p["currently_citing_pages"]:
                typer.echo(f"  - {c}")
        if p["candidate_pages_to_integrate"]:
            typer.secho("Candidate Baselines to integrate with ('Integrate, don't rewrite'):", fg=typer.colors.YELLOW)
            for cand in p["candidate_pages_to_integrate"]:
                typer.echo(f"  - {cand['title']} ({cand['path']})")
        else:
            typer.echo("No existing baselines matched. Propose creating a new consolidated baseline (CAN-*.md).")
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@ingest_app.command(name="close")
def ingest_close_cmd(
    source_id: str = typer.Argument(..., help="Source ID to close and freeze"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate quotes without moving files"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
    vault: Path | None = typer.Option(None, "--vault", help="Path to story bible vault root"),
):
    """Validate literal quotes, freeze source with sha256, and append to audit log."""
    v = get_vault(vault)
    try:
        res = close_ingest(v, source_id, dry_run=dry_run)
        if json_output:
            typer.echo(json.dumps(res, indent=2))
            raise typer.Exit(0 if res.get("success") else 1)

        if not res.get("success"):
            typer.secho(f"[REFUSED] Ingest close failed for {source_id}:", fg=typer.colors.RED, err=True)
            for f in res.get("findings", []):
                typer.secho(f"  [{f['code']}] {f['path']}: {f['message']}", fg=typer.colors.YELLOW)
            raise typer.Exit(1)

        typer.secho(f"[OK] {res['message']}", fg=typer.colors.GREEN)
        typer.echo(f"Citing pages: {', '.join(res['citing_pages'])}")
        if res.get("sha256"):
            typer.echo(f"SHA-256: {res['sha256']}")
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@ingest_app.command(name="pending")
def ingest_pending_cmd(
    json_output: bool = typer.Option(False, "--json", help="Output pending sources as JSON"),
    vault: Path | None = typer.Option(None, "--vault", help="Path to story bible vault root"),
):
    """List uncompiled sources waiting in inbox or unreferenced frozen sources."""
    v = get_vault(vault)
    items = get_pending(v)
    if json_output:
        typer.echo(json.dumps(items, indent=2))
        return
    if not items:
        typer.secho("[OK] No pending sources. All canon sources compiled.", fg=typer.colors.GREEN)
        return
    typer.secho(f"Pending sources ({len(items)}):", fg=typer.colors.CYAN)
    for it in items:
        status_color = typer.colors.YELLOW if it["status"] == "inbox" else typer.colors.MAGENTA
        typer.secho(f"  [{it['status']}] {it['source_id']} ({it['path']})", fg=status_color)


@ingest_app.command(name="skip")
def ingest_skip_cmd(
    source_id: str = typer.Argument(..., help="Source ID to skip"),
    reason: str = typer.Option(..., "--reason", "-r", help="Reason for skipping without compiling"),
    vault: Path | None = typer.Option(None, "--vault", help="Path to story bible vault root"),
):
    """Mark a source as intentionally skipped without compiling."""
    v = get_vault(vault)
    try:
        skip_ingest(v, source_id, reason)
        typer.secho(f"[OK] Skipped {source_id}: {reason}", fg=typer.colors.GREEN)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


# Subcommand group: translate
translate_app = typer.Typer(name="translate", help="Manuscript translation parity and termbase localization")
app.add_typer(translate_app)

# Subcommand group: chapter
chapter_app = typer.Typer(name="chapter", help="Chapter drafting, scaffolding, and lifecycle management")
app.add_typer(chapter_app)
app.add_typer(chapter_app, name="manuscript")


@chapter_app.command(name="new")
def chapter_new_cmd(
    number: int = typer.Argument(..., help="Sequential chapter number (e.g. 1)"),
    slug: str = typer.Argument(..., help="Short descriptive slug for the chapter"),
    title: str | None = typer.Option(None, "--title", "-t", help="Optional full chapter title"),
    pov: str | None = typer.Option(None, "--pov", "-p", help="POV character name"),
    volume: int = typer.Option(1, "--volume", "-v", help="Volume number"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing chapter file"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
) -> None:
    """Scaffold a new manuscript chapter with compliant frontmatter and initial paragraph tag."""
    v = get_vault(vault_path) if vault_path is not None else get_vault()
    from narr.chapter import create_chapter

    try:
        path = create_chapter(v, number=number, slug=slug, title=title, pov=pov, volume=volume, force=force)
        typer.secho(f"[OK] Chapter scaffolded: {v.rel(path)}", fg=typer.colors.GREEN, bold=True)
        typer.echo(f"  UID: C{number:02d}_{slug}")
        typer.echo("  Initial Marker: <!-- p:1 -->")
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@chapter_app.command(name="status")
def chapter_status_cmd(
    chapter: int | None = typer.Argument(None, help="Optional chapter number to inspect"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output status report as JSON"),
) -> None:
    """Inspect and audit all manuscript chapters across pt-BR drafting and es translation."""
    import dataclasses

    v = get_vault(vault_path) if vault_path is not None else get_vault()
    from narr.chapter import get_chapter_status

    records = get_chapter_status(v, chapter_num=chapter)

    if json_output:
        data = [dataclasses.asdict(r) for r in records]
        typer.echo(json.dumps(data, indent=2))
        return

    if not records:
        typer.echo("No manuscript chapters found in 04_Manuscript/pt-BR/Chapters/.")
        return

    typer.secho(f"Manuscript Status ({len(records)} chapter(s)):", bold=True)
    for r in records:
        v_status = typer.style("[VALID]", fg=typer.colors.GREEN) if r.validation_passed else typer.style("[INVALID]", fg=typer.colors.RED)
        if r.es_file:
            t_status = (
                typer.style("[ES OK]", fg=typer.colors.GREEN)
                if r.translation_passed
                else typer.style(f"[ES DIFF: {r.translation_diff}]", fg=typer.colors.YELLOW)
            )
        else:
            t_status = typer.style("[NO ES]", fg=typer.colors.WHITE, dim=True)

        typer.echo(f"  C{r.chapter_num:02d}: {r.title:<30} {r.word_count:>5} words | {r.marker_count:>3} paras | {v_status} | {t_status}")
        if not r.validation_passed:
            for err in r.validation_errors:
                typer.secho(f"      - {err}", fg=typer.colors.RED)


@translate_app.command(name="check")
def translate_check_cmd(
    chapter: int = typer.Argument(..., help="Chapter number to check parity for"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON"),
):
    """Validate paragraph parity (MSC004) and translation between pt-BR and es."""
    v = get_vault(vault_path) if vault_path is not None else get_vault()
    try:
        report = check_translation_parity(v, chapter)
        if json_output:
            typer.echo(
                json.dumps(
                    {
                        "chapter": report.chapter_num,
                        "pt_path": report.pt_path,
                        "es_path": report.es_path,
                        "pt_paragraphs": report.pt_paragraphs,
                        "es_paragraphs": report.es_paragraphs,
                        "diff": report.diff,
                        "tolerance": report.tolerance,
                        "passed": report.passed,
                    },
                    indent=2,
                )
            )
            raise typer.Exit(0 if report.passed else 1)

        status_color = typer.colors.GREEN if report.passed else typer.colors.YELLOW
        status_text = "[OK] PASSED" if report.passed else "[WARN] PARITY DIVERGENCE"
        typer.secho(f"{status_text} (Chapter {report.chapter_num})", fg=status_color)
        typer.echo(f"  pt-BR ({report.pt_path}): {report.pt_paragraphs} paragraphs")
        typer.echo(f"  es    ({report.es_path}): {report.es_paragraphs} paragraphs")
        typer.echo(f"  Difference: {report.diff} paragraphs (Tolerance: {report.tolerance})")
        if not report.passed:
            raise typer.Exit(1)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@app.command(name="decide")
def decide_cmd(
    title: str = typer.Argument(..., help="Title of the architectural or narrative decision"),
    supersedes: str | None = typer.Option(None, "--supersedes", "-s", help="Old decision ID to supersede"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root (default: current directory or ./template)"),
) -> None:
    """Create a new formal decision record (DEC-*) in memory/decisions/."""
    vault = get_vault(vault_path)
    try:
        if supersedes:
            from narr.decide import resolve_decision_file

            resolve_decision_file(vault, supersedes)

        dest = create_decision(vault, title)
        typer.secho(f"[OK] Created decision: {vault.rel(dest)}", fg=typer.colors.GREEN)
        if supersedes:
            supersede_decision(vault, supersedes, dest.stem)
            typer.secho(f"[OK] Superseded earlier decision: {supersedes}", fg=typer.colors.CYAN)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@app.command(name="consolidate")
def consolidate_cmd(
    json_output: bool = typer.Option(False, "--json", help="Output leads as JSON"),
):
    """Scan vault for consolidation leads: dead links, duplicate stems, and open contradictions."""
    vault = get_vault()
    leads = find_consolidation_leads(vault)
    if json_output:
        typer.echo(json.dumps([{"kind": l.kind, "subject": l.subject, "detail": l.detail, "path": l.path} for l in leads], indent=2))
        return

    if not leads:
        typer.secho("[OK] Vault consolidated. Zero duplicate candidates, dead links, or open contradictions.", fg=typer.colors.GREEN)
        return

    typer.secho(f"Consolidation Leads ({len(leads)}):", fg=typer.colors.CYAN)
    for l in leads:
        typer.secho(f"  [{l.kind.upper()}] {l.subject} ({l.path})", fg=typer.colors.YELLOW)
        typer.echo(f"     {l.detail}")


@app.command(name="promote")
def promote_cmd(
    source_file: Path = typer.Argument(..., help="Path to sandbox file in 06_Ideation_and_Unblocking/"),
    zone: str = typer.Option(..., "--zone", "-z", help="Target zone: characters, factions, locations, powers, cosmology, lore, pods"),
    prefix: str = typer.Option(..., "--prefix", "-p", help="Target prefix: CHR, FAC, LOC, PWR, SYS, SCP, POD"),
    slug: str = typer.Option(..., "--slug", "-s", help="Safe filename slug (e.g. Tang_San)"),
    title: str = typer.Option(..., "--title", "-t", help="Formal title of entity"),
    archive: bool = typer.Option(True, "--archive/--no-archive", help="Relocate source file to 06_Ideation_and_Unblocking/archive/"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    as_json: bool = typer.Option(False, "--json", help="Output result as JSON"),
):
    """Sanitize and promote a mature note from 06_Ideation_and_Unblocking to Story Bible."""
    vault = get_vault(vault_path) if vault_path is not None else get_vault()
    try:
        dest = promote_note(
            vault,
            source_file,
            target_zone=zone,
            target_prefix=prefix,
            slug=slug,
            title=title,
            archive_source=archive,
        )
        if as_json:
            typer.echo(json.dumps({"status": "ok", "promoted": vault.rel(dest), "archive_source": archive}, indent=2))
            return
        typer.secho(f"[OK] Promoted to authoritative layer: {vault.rel(dest)}", fg=typer.colors.GREEN)
    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


# Subcommand group: prompt
prompt_app = typer.Typer(name="prompt", help="Fiction-conscious hybrid prompt engine")
app.add_typer(prompt_app)


@prompt_app.command(name="list")
def prompt_list_cmd(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
):
    """List all available prompt generation actions."""
    actions = [
        ("write-chapter", "Assemble deterministic context and write chapter in pt-BR (<!-- p:N --> format)"),
        ("translate-chapter", "Assemble context and translate pt-BR chapter to Spanish (es) with 1:1 parity"),
        ("canon-ingest", "Extract atomic facts, verbatim quotes, and negative boundaries from raw source"),
        ("lore-dossier", "Compile multi-zone lore dossier for character, faction, location, or system"),
        ("foreshadowing-audit", "Audit clue-to-payoff distances and detect overdue foreshadowing items"),
        ("conflict-arbitration", "Arbitrate canon contradictions via Canonical Hierarchy of Truth"),
    ]
    typer.secho("Available Prompt Actions:", fg=typer.colors.CYAN, bold=True)
    for act, desc in actions:
        typer.secho(f"  narr prompt render {act:<22}", fg=typer.colors.GREEN, bold=True)
        typer.echo(f"      {desc}")


@prompt_app.command(name="render")
def prompt_render_cmd(
    action: str = typer.Argument(
        ..., help="Action: write-chapter, translate-chapter, canon-ingest, lore-dossier, foreshadowing-audit, conflict-arbitration"
    ),
    chapter: int | None = typer.Option(None, "--chapter", "-c", help="Chapter number (for write-chapter, translate-chapter)"),
    pov: str | None = typer.Option(None, "--pov", "-p", help="POV character name"),
    arc: str | None = typer.Option(None, "--arc", "-a", help="Arc title or reference"),
    source: str | None = typer.Option(None, "--source", "-s", help="Source ID (for canon-ingest)"),
    entity: str | None = typer.Option(None, "--entity", "-e", help="Topic or entity (for lore-dossier)"),
    target_lang: str = typer.Option("es", "--lang", "-l", help="Target translation language"),
    output_file: Path | None = typer.Option(None, "--output", "-o", help="Optional path to write assembled prompt"),
    json_output: bool = typer.Option(False, "--json", help="Output result as JSON"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
):
    """Render deterministic system and user prompts with token budgeting."""
    v = get_vault(vault_path) if vault_path is not None else get_vault()
    from narr.prompt import PromptEngine

    engine = PromptEngine(v)

    try:
        if action == "write-chapter":
            if chapter is None:
                typer.secho("Error: --chapter is required for write-chapter.", fg=typer.colors.RED, err=True)
                raise typer.Exit(1)
            res = engine.render_write_chapter(chapter_num=chapter, pov=pov, arc=arc)
        elif action == "translate-chapter":
            if chapter is None:
                typer.secho("Error: --chapter is required for translate-chapter.", fg=typer.colors.RED, err=True)
                raise typer.Exit(1)
            res = engine.render_translate_chapter(chapter_num=chapter, target_lang=target_lang)
        elif action == "canon-ingest":
            if not source:
                typer.secho("Error: --source is required for canon-ingest.", fg=typer.colors.RED, err=True)
                raise typer.Exit(1)
            res = engine.render_canon_ingest(source_id=source)
        elif action == "lore-dossier":
            if not entity:
                typer.secho("Error: --entity is required for lore-dossier.", fg=typer.colors.RED, err=True)
                raise typer.Exit(1)
            res = engine.render_lore_dossier(topic_or_entity=entity)
        elif action == "foreshadowing-audit":
            res = engine.render_foreshadowing_audit()
        elif action == "conflict-arbitration":
            res = engine.render_conflict_arbitration()
        else:
            typer.secho(f"Error: Unknown prompt action '{action}'. Run 'narr prompt list'.", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

        if json_output:
            data = {
                "action": res.action,
                "token_estimate": res.token_estimate,
                "system_prompt": res.system_prompt,
                "user_prompt": res.user_prompt,
                "sections": [{"name": s.name, "tokens": s.token_estimate, "priority": s.priority} for s in res.sections],
            }
            typer.echo(json.dumps(data, indent=2))
            return

        full_text = res.render_full()
        if output_file:
            output_file.write_text(full_text, encoding="utf-8")
            typer.secho(f"[OK] Rendered prompt written to: {output_file} (~{res.token_estimate} tokens)", fg=typer.colors.GREEN)
        else:
            typer.echo(full_text)
            typer.secho(
                f"\n[INFO] Estimated Context: ~{res.token_estimate} tokens across {len(res.sections)} sections.", fg=typer.colors.CYAN
            )

    except VaultError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@prompt_app.command(name="validate")
def prompt_validate_cmd(
    action: str = typer.Argument(..., help="Action: write-chapter, translate-chapter, canon-ingest, lore-dossier"),
    file_path: Path = typer.Argument(..., help="Path to generated output file to validate"),
    source_file: Path | None = typer.Option(None, "--source-file", "-s", help="Optional source file for translation parity check"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output validation as JSON"),
):
    """Validate LLM output against deterministic invariants (VAL010, VAL024, MSC004, wikilinks)."""
    v = get_vault(vault_path) if vault_path is not None else get_vault()
    from narr.prompt import PromptEngine

    engine = PromptEngine(v)

    if not file_path.is_file():
        typer.secho(f"Error: Target file not found: {file_path}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    out_text = read_text(file_path)
    src_text = read_text(source_file) if source_file and source_file.is_file() else None

    report = engine.validate_output(action=action, output_text=out_text, source_text=src_text)

    if json_output:
        typer.echo(
            json.dumps(
                {
                    "is_valid": report.is_valid,
                    "errors": report.errors,
                    "warnings": report.warnings,
                    "metrics": report.metrics,
                },
                indent=2,
            )
        )
        raise typer.Exit(0 if report.is_valid else 1)

    if report.is_valid:
        typer.secho(f"[OK] Invariant Validation Passed for: {v.rel(file_path)}", fg=typer.colors.GREEN, bold=True)
    else:
        typer.secho(f"[FAIL] Invariant Validation Failed for: {v.rel(file_path)}", fg=typer.colors.RED, bold=True)

    for err in report.errors:
        typer.secho(f"  [ERROR] {err}", fg=typer.colors.RED)
    for warn in report.warnings:
        typer.secho(f"  [WARN]  {warn}", fg=typer.colors.YELLOW)

    for k, v in report.metrics.items():
        typer.echo(f"  - {k}: {v}")

    if not report.is_valid:
        raise typer.Exit(1)


# Subcommand group: pipeline
pipeline_app = typer.Typer(name="pipeline", help="End-to-end serialized narrative pipeline runner")
app.add_typer(pipeline_app)


@pipeline_app.command(name="plan")
def pipeline_plan_cmd():
    """Display the authoritative end-to-end serialized fiction workflow plan."""
    steps = [
        (
            "Phase 1: Ingestion & Verification",
            "Capture raw canon sources with sha256 checksums",
            "narr clip / narr capture -> narr ingest close",
        ),
        (
            "Phase 2: Worldbuilding (10/90 Iceberg)",
            "Create baselines, PODs, design sheets, power systems",
            "narr new baseline / narr new pod / narr new character",
        ),
        (
            "Phase 3: Serialized Drafting (pt-BR)",
            "Assemble prompt, write chapter with <!-- p:N --> tags",
            "narr prompt render write-chapter -c <N>",
        ),
        (
            "Phase 4: Draft Quality Gate",
            "Check CJK, passive voice, AI fluff, and wikilink syntax",
            "narr prompt validate write-chapter <draft_file>",
        ),
        (
            "Phase 5: Publication Localization (es)",
            "Translate with 1:1 paragraph parity and termbase",
            "narr prompt render translate-chapter -c <N>",
        ),
        ("Phase 6: Parity Quality Gate (MSC004)", "Verify paragraph count parity and translation accuracy", "narr translate check <N>"),
        ("Phase 7: Pre-Commit Lint Gate", "Run pure deterministic linter over all vault zones", "narr lint (0 errors, 0 warnings)"),
        (
            "Phase 8: Environment & Parity Gate",
            "Run environment health and agent rules parity check",
            "narr doctor (4/4 pass, multi-agent 100%)",
        ),
        (
            "Phase 9: Operational Session Close",
            "Record completed milestones, decisions, next priorities",
            "narr session close -d <done> -n <next> --decided <dec>",
        ),
    ]
    typer.secho("================================================================================", fg=typer.colors.CYAN)
    typer.secho("         SERIALIZED NARRATIVE END-TO-END PIPELINE (LUNA ARCHITECTURE)          ", fg=typer.colors.CYAN, bold=True)
    typer.secho("================================================================================", fg=typer.colors.CYAN)
    for title, desc, cmd in steps:
        typer.secho(f"\n{title}", fg=typer.colors.GREEN, bold=True)
        typer.echo(f"  Objective: {desc}")
        typer.secho(f"  Command:   {cmd}", fg=typer.colors.YELLOW)
    typer.secho("\n================================================================================\n", fg=typer.colors.CYAN)


@pipeline_app.command(name="run")
def pipeline_run_cmd(
    step: str = typer.Argument(..., help="Step to run: lint, doctor, crosscheck"),
):
    """Execute a specific automated quality gate in the narrative pipeline."""
    vault = get_vault()
    if step == "lint":
        from narr.checks import run_all_checks

        findings = run_all_checks(vault)
        errors = [f for f in findings if f.severity == "error"]
        warnings = [f for f in findings if f.severity == "warning"]
        if errors:
            typer.secho(
                f"[FAIL] Lint gate failed with {len(errors)} error(s) and {len(warnings)} warning(s).", fg=typer.colors.RED, bold=True
            )
            raise typer.Exit(1)
        typer.secho(f"[PASS] Lint gate passed with 0 errors and {len(warnings)} warnings.", fg=typer.colors.GREEN, bold=True)
    elif step == "doctor":
        from narr.doctor import run_doctor

        diags = run_doctor(vault)
        failed = [d for d in diags if not d.status]
        if failed:
            typer.secho(f"[FAIL] Doctor gate failed ({len(failed)}/{len(diags)} checks failed).", fg=typer.colors.RED, bold=True)
            for f in failed:
                typer.secho(f"  [FAIL] {f.name}: {f.detail}", fg=typer.colors.RED)
            raise typer.Exit(1)
        typer.secho(
            f"[PASS] Doctor gate passed ({len(diags)}/{len(diags)} checks passed, 100% agent parity).", fg=typer.colors.GREEN, bold=True
        )
    elif step == "crosscheck":
        from narr.checks import run_all_checks

        findings = run_all_checks(vault)
        continuity_findings = [cf for cf in findings if cf.code in ("VAL019", "VAL020", "VAL025", "VAL028", "VAL029")]
        if continuity_findings:
            typer.secho(f"[FAIL] Crosscheck found {len(continuity_findings)} continuity issues.", fg=typer.colors.YELLOW, bold=True)
            for cf in continuity_findings:
                typer.secho(f"  [{cf.code}] {cf.path}: {cf.message}", fg=typer.colors.YELLOW)
            raise typer.Exit(1)
        typer.secho("[PASS] Crosscheck clean. Zero issues detected.", fg=typer.colors.GREEN, bold=True)
    else:
        typer.secho(f"Error: Unknown pipeline step '{step}'. Available: lint, doctor, crosscheck", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@app.command(name="page")
def page_cmd(
    name: str = typer.Argument(..., help="Page title, stem, or UID"),
    json_out: bool = typer.Option(False, "--json", help="Output machine-readable JSON"),
):
    """Inspect page metadata, role, links, and lint status without reading full body (ADR-038)."""
    vault = get_vault()
    info = get_page_view(vault, name)
    if not info:
        typer.secho(f"Error: Page '{name}' not found in vault.", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    if json_out:
        typer.echo(json.dumps(info, indent=2))
    else:
        typer.echo(format_page_view(info))


@app.command(name="candidates")
def candidates_cmd(
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_out: bool = typer.Option(False, "--json", help="Output machine-readable JSON"),
):
    """Surface consolidation leads: Jaccard title overlap, stale links, and contradictions (ADR-007)."""
    vault = get_vault(vault_path)
    leads = find_candidates(vault)
    if json_out:
        typer.echo(json.dumps(leads, indent=2))
        return

    if not leads:
        typer.secho("[OK] No consolidation leads found across vault.", fg=typer.colors.GREEN, bold=True)
        return

    typer.secho(f"=== CONSOLIDATION LEADS ({len(leads)}) ===", fg=typer.colors.CYAN, bold=True)
    for lead in leads:
        kind = lead["kind"]
        pages = " vs ".join(lead["pages"])
        reason = lead["reason"]
        color = typer.colors.YELLOW if kind == "merge?" else (typer.colors.RED if kind == "contradiction" else typer.colors.MAGENTA)
        typer.secho(f"[{kind.upper()}] {pages}", fg=color, bold=True)
        typer.echo(f"  Reason: {reason}")


@app.command(name="mv")
def mv_cmd(
    old_name: str = typer.Argument(None, help="Existing page name, stem, or path"),
    new_name: str = typer.Argument(None, help="New page name, stem, or path"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show lines that would change without applying"),
    undo: bool = typer.Option(False, "--undo", help="Roll back the last recorded rename from journal"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output rename plan or result as JSON"),
):
    """Rename or move a page and rewrite every inbound [[wikilink]] with atomic undo (ADR-006)."""
    vault = get_vault(vault_path)
    if undo:
        try:
            res = undo_last_rename(vault)
            if json_output:
                typer.echo(json.dumps(res, indent=2))
                return
            typer.secho(f"[UNDONE] Reverted '{res['reverted_from']}' back to '{res['restored_to']}'.", fg=typer.colors.GREEN, bold=True)
            return
        except Exception as e:
            typer.secho(f"Error during undo: {e}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

    if not old_name or not new_name:
        typer.secho("Error: Both OLD_NAME and NEW_NAME are required (or use --undo).", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    try:
        plan = build_rename_plan(vault, old_name, new_name)
        res = execute_rename(vault, plan, dry_run=dry_run)
        if dry_run:
            if json_output:
                data = {
                    "dry_run": True,
                    "old_rel_path": plan.old_rel_path,
                    "new_rel_path": plan.new_rel_path,
                    "total_references_updated": plan.total_references_updated,
                    "target_replacements": {
                        k: [{"line": idx + 1, "old": old_l, "new": new_l} for idx, old_l, new_l in v]
                        for k, v in plan.target_replacements.items()
                    },
                }
                typer.echo(json.dumps(data, indent=2))
                return
            typer.secho(f"=== RENAME PLAN [DRY-RUN]: {plan.old_rel_path} -> {plan.new_rel_path} ===", fg=typer.colors.CYAN, bold=True)
            typer.echo(f"Files affected: {len(plan.target_replacements)} | Total references to update: {plan.total_references_updated}")
            for path, changes in plan.target_replacements.items():
                typer.secho(f"  {path} ({len(changes)} changes):", fg=typer.colors.YELLOW)
                for idx, old_line, new_line in changes[:3]:
                    typer.echo(f"    Line {idx + 1}: {old_line.strip()} -> {new_line.strip()}")
        else:
            if json_output:
                typer.echo(json.dumps(res, indent=2))
                return
            typer.secho(f"[APPLIED] Renamed '{plan.old_rel_path}' -> '{plan.new_rel_path}'.", fg=typer.colors.GREEN, bold=True)
            typer.echo(f"Updated {plan.total_references_updated} reference(s) across {len(plan.target_replacements)} file(s).")
    except Exception as e:
        typer.secho(f"Rename failed: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@app.command(name="clip")
def clip_cmd(
    urls: list[str] = typer.Argument(..., help="One or more URLs to capture"),
    limit: int = typer.Option(10, help="Maximum links to process"),
    vault: Path | None = typer.Option(None, "--vault", help="Path to story bible vault root"),
):
    """Capture public web pages or fandom wikis into Sources/inbox/ with SHA256 (ADR-014)."""
    v = get_vault(vault)
    count = 0
    errors = 0
    for u in urls[:limit]:
        try:
            dest = clip_url(u, v)
            typer.secho(f"[CLIPPED] {u} -> {dest.relative_to(v.root)}", fg=typer.colors.GREEN)
            count += 1
        except Exception as e:
            typer.secho(f"[FAIL] {u}: {e}", fg=typer.colors.RED)
            errors += 1

    if errors > 0:
        if count == 0:
            typer.secho(f"Failed to clip requested source(s) ({errors} error(s)).", fg=typer.colors.RED, err=True)
        else:
            typer.secho(f"Partially clipped {count} source(s), but encountered {errors} error(s).", fg=typer.colors.YELLOW, err=True)
        raise typer.Exit(1)

    typer.secho(f"Done. Successfully clipped {count} source(s).", fg=typer.colors.CYAN, bold=True)


@app.command(name="import")
def import_cmd(
    folder: Path = typer.Argument(..., help="Path to local folder of lore documents"),
    label: str | None = typer.Option(None, "--label", help="Origin label for metadata"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Inspect without copying"),
    vault: Path | None = typer.Option(None, "--vault", help="Path to story bible vault root"),
):
    """Offline batch mirror of documents into Sources/inbox/ with content hashing (ADR-029)."""
    v = get_vault(vault)
    try:
        res = import_folder(folder, v, label=label, dry_run=dry_run)
        prefix = "[DRY-RUN] " if dry_run else ""
        typer.secho(
            f"{prefix}Import complete: {res['imported_count']} imported, {res['skipped_count']} skipped (already exist).",
            fg=typer.colors.GREEN,
            bold=True,
        )
        if res["imported"]:
            typer.echo(f"Imported sample: {', '.join(res['imported'])}")
    except Exception as e:
        typer.secho(f"Import failed: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


@app.command(name="eval")
def eval_cmd(
    k: int = typer.Option(5, "-k", help="Top-K cutoff for retrieval metrics"),
    record: bool = typer.Option(False, "--record", help="Record benchmark run into eval/runs.jsonl"),
    vault_path: Path | None = typer.Option(None, "--vault", help="Path to vault root"),
    json_output: bool = typer.Option(False, "--json", help="Output benchmark metrics as JSON"),
):
    """Evaluate retrieval precision against eval/queries.yaml (Recall, MRR, NDCG) (ADR-008)."""
    vault = get_vault(vault_path)
    try:
        metrics = evaluate_retrieval(vault, k=k, record=record)
        if json_output:
            typer.echo(json.dumps(asdict(metrics), indent=2))
            return
        if metrics.queries_count == 0:
            typer.secho("No queries found in eval/queries.yaml.", fg=typer.colors.YELLOW)
            return

        typer.secho(f"=== RETRIEVAL BENCHMARK REPORT (queries: {metrics.queries_count}, k: {k}) ===", fg=typer.colors.CYAN, bold=True)
        typer.echo(f"Recall@{k}:   {metrics.recall_at_k:.4f}  (Trigger target: >= 0.8000)")
        typer.echo(f"MRR:         {metrics.mrr:.4f}")
        typer.echo(f"Hit Rate:    {metrics.hit_rate * 100:.1f}%")
        typer.echo(f"NDCG@{k}:     {metrics.ndcg_at_k:.4f}")
        typer.echo(f"Latency p95: {metrics.p95_ms:.2f} ms")

        if metrics.recall_at_k < 0.80:
            typer.secho(
                "[WARN] Recall@5 is below 0.80. Consider tuning FTS5 weights or adding vector embeddings (ADR-003).",
                fg=typer.colors.YELLOW,
                bold=True,
            )
        else:
            typer.secho("[PASS] Retrieval precision healthy (>= 0.80).", fg=typer.colors.GREEN, bold=True)

        if record:
            typer.secho("Run recorded to eval/runs.jsonl.", fg=typer.colors.GREEN)
    except Exception as e:
        typer.secho(f"Evaluation error: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)


if __name__ == "__main__":
    app()

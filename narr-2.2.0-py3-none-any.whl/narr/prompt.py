"""Hybrid Fiction-Conscious Prompt Engine for serialized narrative drafting and validation.

Combines deterministic RAG context assembly, token budgeting, and invariant post-validation
with creative LLM generation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from narr.checks import _AI_PREAMBLES, _CJK_PATTERN, _PASSIVE_INDICATORS
from narr.search import search
from narr.vault import Vault, VaultError, read_text, read_text_or_none


def estimate_tokens(text: str) -> int:
    """Heuristic token estimation: ~4 chars per token / word count multiplier."""
    if not text:
        return 0
    words = len(text.split())
    by_chars = len(text) // 4
    return max(by_chars, int(words * 1.33))


@dataclass
class PromptSection:
    name: str
    content: str
    priority: int = 1  # 1 = critical/mandatory, 2 = operational/ledger, 3 = supplementary
    token_estimate: int = 0

    def __post_init__(self):
        if not self.token_estimate:
            self.token_estimate = estimate_tokens(self.content)


@dataclass
class PromptResult:
    action: str
    system_prompt: str
    user_prompt: str
    token_estimate: int
    sections: list[PromptSection] = field(default_factory=list)

    def render_full(self) -> str:
        return f"=== SYSTEM PROMPT ===\n{self.system_prompt}\n\n=== USER PROMPT ===\n{self.user_prompt}\n"


@dataclass
class ValidationReport:
    is_valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    metrics: dict[str, Any] = field(default_factory=dict)


class PromptEngine:
    """Deterministic prompt assembler and output validator for the narrative framework."""

    def __init__(self, vault: Vault):
        self.vault = vault

    def _budget_sections(self, sections: list[PromptSection], max_tokens: int) -> list[PromptSection]:
        """Prune sections by priority (lowest priority first) to stay under max_tokens."""
        total = sum(s.token_estimate for s in sections)
        if total <= max_tokens:
            return sections

        # Sort by priority ascending (1 stays, 3 dropped first)
        ordered = sorted(sections, key=lambda s: s.priority)
        selected: list[PromptSection] = []
        current_tokens = 0

        for sec in ordered:
            if current_tokens + sec.token_estimate <= max_tokens or sec.priority == 1:
                selected.append(sec)
                current_tokens += sec.token_estimate

        # Restore original order among selected
        return [s for s in sections if s in selected]

    def render_write_chapter(
        self,
        chapter_num: int,
        pov: str | None = None,
        arc: str | None = None,
        max_context_tokens: int = 3500,
    ) -> PromptResult:
        """Assemble deterministic context for writing a serialized chapter in pt-BR."""
        system_prompt = (
            "You are an elite serialized fiction writer, dramaturge, and prose craftsman.\n"
            "OPERATING RULES & INVARIANTS:\n"
            "1. LANGUAGE: Draft strictly in natural, evocative Brazilian Portuguese (pt-BR).\n"
            "2. PARAGRAPH DELIMITERS: Every narrative paragraph MUST be prefixed by an explicit comment: <!-- p:1 -->, <!-- p:2 -->, etc.\n"
            "3. ZERO FLUFF: NEVER output conversational preambles (e.g., 'Certamente', 'Aqui está o capítulo'). Begin directly with markdown header and <!-- p:1 -->.\n"
            "4. SHOW DON'T TELL & ACTIVE VOICE: Prioritize active verbs, visceral sensory cues, and psychological realism over passive summary.\n"
            "5. HARD CONSTRAINTS: Respect epistemic horizons (characters cannot know facts they haven't witnessed), Sanderson's power limits, and established canon baselines."
        )

        sections: list[PromptSection] = []

        # 1. Mandatory Assignment (Priority 1)
        assignment_text = (
            f"# Mission: Write Chapter C{chapter_num:02d}\n"
            f"- Chapter ID: C{chapter_num:02d}\n"
            f"- POV Character: {pov or 'Protagonist'}\n"
            f"- Arc Focus: {arc or 'Current Arc'}\n"
            f"- Target Word Count: 2,500 – 4,500 words\n"
            f"- Format: Clean Markdown with <!-- p:N --> annotations before every narrative paragraph."
        )
        sections.append(PromptSection(name="Chapter Assignment", content=assignment_text, priority=1))

        # 2. Tone and Identity Bible (Priority 1)
        tone_file = self.vault.root / "02_Story_Bible" / "Cosmology_and_Godhood" / "SCP-Tone_and_Identity_Bible.md"
        if tone_file.is_file():
            text = read_text_or_none(tone_file)
            if text:
                sections.append(PromptSection(name="Atmospheric Tone & Negative Boundaries", content=text[:1500], priority=1))

        # 3. POV Character Settei & Epistemic Horizon (Priority 2)
        if pov:
            hits = search(self.vault, query=pov, limit=2, zone="02_Story_Bible")
            for h in hits:
                p_path = self.vault.root / h.rel_path
                p_text = read_text_or_none(p_path)
                if p_text:
                    sections.append(PromptSection(name=f"POV Reference: {h.title}", content=p_text[:1800], priority=2))

        # Character Knowledge Ledger (Priority 2)
        know_file = self.vault.root / "08_Ledgers" / "LDG-Character_Knowledge.md"
        if know_file.is_file():
            text = read_text_or_none(know_file)
            if text:
                sections.append(PromptSection(name="Epistemic Horizon Ledger", content=text[:1200], priority=2))

        # 4. Active Threads & Chekhov Guns (Priority 2)
        threads_file = self.vault.root / "08_Ledgers" / "LDG-Active_Threads.md"
        if threads_file.is_file():
            text = read_text_or_none(threads_file)
            if text:
                sections.append(PromptSection(name="Active Plot Threads", content=text[:1000], priority=2))

        chekhov_file = self.vault.root / "08_Ledgers" / "LDG-Chekhov_Guns.md"
        if chekhov_file.is_file():
            text = read_text_or_none(chekhov_file)
            if text:
                sections.append(PromptSection(name="Chekhov Weapons & Clues", content=text[:1000], priority=2))

        # 5. Foreshadowing Clues (Priority 2)
        fsh_file = self.vault.root / "08_Ledgers" / "LDG-Foreshadowing.md"
        if fsh_file.is_file():
            text = read_text_or_none(fsh_file)
            if text:
                sections.append(PromptSection(name="Foreshadowing Setup Ledger", content=text[:1000], priority=2))

        # Budget and assemble
        budgeted = self._budget_sections(sections, max_tokens=max_context_tokens)
        user_body = "\n\n---\n\n".join(f"## {s.name}\n{s.content}" for s in budgeted)
        user_prompt = (
            f"{user_body}\n\n---\n\n"
            f"## Final Directive\n"
            f"Produce the complete draft of Chapter C{chapter_num:02d} in pt-BR according to all rules and constraints above. "
            f"Ensure every single paragraph has its matching <!-- p:N --> tag."
        )

        total_tokens = estimate_tokens(system_prompt) + sum(s.token_estimate for s in budgeted) + estimate_tokens(user_prompt)
        return PromptResult(
            action="write-chapter",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            token_estimate=total_tokens,
            sections=budgeted,
        )

    def render_translate_chapter(
        self,
        chapter_num: int,
        target_lang: str = "es",
    ) -> PromptResult:
        """Assemble deterministic context for translating a pt-BR draft into es publication."""
        pt_dir = self.vault.root / "04_Manuscript" / "pt-BR" / "Chapters"
        pt_candidates = list(pt_dir.glob(f"C{chapter_num:02d}*.md")) or list(pt_dir.glob(f"C{chapter_num}*.md"))
        if not pt_candidates:
            raise VaultError(f"No pt-BR draft found for chapter {chapter_num} in {self.vault.rel(pt_dir)}")

        pt_file = pt_candidates[0]
        pt_content = read_text(pt_file)

        system_prompt = (
            "You are an elite literary translator and narrative localizer specializing in Brazilian Portuguese to Spanish (es) publication.\n"
            "OPERATING RULES & INVARIANTS (MSC004):\n"
            "1. PARAGRAPH PARITY: Maintain a strict 1:1 paragraph correspondence. For every '<!-- p:N -->' in the source text, provide the exact corresponding '<!-- p:N -->' block in Spanish.\n"
            "2. ZERO PREAMBLE: Do not output 'Aquí está la traducción' or any assistant introductory remarks.\n"
            "3. TERMBASE INTEGRITY: Honor all official termbase mappings, character names, and title registers.\n"
            "4. PROSE RHYTHM: Preserve the dramatic pacing, sentence cadence, and visceral imagery of the original."
        )

        sections: list[PromptSection] = []

        # 1. Source Chapter
        sections.append(PromptSection(name=f"Source Text (pt-BR) - {pt_file.name}", content=pt_content, priority=1))

        # 2. Termbase
        termbase_file = self.vault.root / "02_Story_Bible" / "Terminology" / "TRM-Termbase.md"
        if termbase_file.is_file():
            text = read_text_or_none(termbase_file)
            if text:
                sections.append(PromptSection(name="Master Termbase & Localization Matrix", content=text[:2000], priority=1))

        # 3. Tone Bible
        tone_file = self.vault.root / "02_Story_Bible" / "Cosmology_and_Godhood" / "SCP-Tone_and_Identity_Bible.md"
        if tone_file.is_file():
            text = read_text_or_none(tone_file)
            if text:
                sections.append(PromptSection(name="Narrative Tone Guidelines", content=text[:1000], priority=2))

        user_body = "\n\n---\n\n".join(f"## {s.name}\n{s.content}" for s in sections)
        user_prompt = (
            f"{user_body}\n\n---\n\n"
            f"## Final Translation Directive\n"
            f"Translate the pt-BR chapter above into high-literary Spanish (es). "
            f"Preserve all frontmatter metadata (updating language: es and source_translation_ref) "
            f"and maintain exact 1:1 <!-- p:N --> paragraph count parity."
        )

        total_tokens = estimate_tokens(system_prompt) + sum(s.token_estimate for s in sections) + estimate_tokens(user_prompt)
        return PromptResult(
            action="translate-chapter",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            token_estimate=total_tokens,
            sections=sections,
        )

    def render_canon_ingest(self, source_id: str | list[str]) -> PromptResult:
        """Assemble context for ingesting a canon source or cluster into right-sized baselines."""
        sids = [source_id] if isinstance(source_id, str) else source_id
        loaded_sources: list[tuple[str, str, Path]] = []  # (sid, text, path)

        for sid in sids:
            clean_sid = sid.strip()
            src_path = self.vault.sources_dir / clean_sid
            if not src_path.is_file():
                raw_matches = list(self.vault.sources_dir.glob(f"{clean_sid}*")) or list(self.vault.sources_inbox_dir.glob(f"{clean_sid}*"))
                matches = [m for m in raw_matches if not m.name.endswith(".json")]
                if matches:
                    src_path = matches[0]
                else:
                    raise VaultError(f"Source file '{clean_sid}' not found in Sources/ or Sources/inbox/.")
            raw_text = read_text(src_path)
            loaded_sources.append((clean_sid, raw_text, src_path))

        sid_list_str = ", ".join(f"[[{s[0]}]]" for s in loaded_sources)
        sid_yaml_str = "\n".join(f'  - "{s[0]}"' for s in loaded_sources)

        system_prompt = (
            "You are an elite canon archivist, knowledge architect, and information extractor.\n"
            "OPERATING RULES & INVARIANTS (VAL013, VAL016, VAL030, QUO001):\n"
            "1. RIGHT-SIZED CONSOLIDATION: Synthesize 2 to 5 closely related or versioned sources into high-density baselines (3 KB to 15 KB). Do NOT create 1:1 micro-stubs.\n"
            '2. VERBATIM QUOTES: Ground every assertion in literal quotes from cited sources: *"exact quote"* [[SRC-id]].\n'
            "3. NEGATIVE BOUNDARIES: Every baseline MUST define 'What it does NOT establish' to prevent hallucination.\n"
            "4. CANON PURITY: Strictly exclude fanfiction or divergence concepts from 'CAN-' baselines.\n"
            "5. BLUEPRINT COMPLIANCE: Include sections 'Consolidated Architecture & Overview', 'Atomic Canonical Facts', 'Canon Divergence & Wiki Discrepancies', 'Verbatim Evidence & Source Grounding', and 'What it does NOT establish'."
        )

        sections: list[PromptSection] = []
        user_parts = [f"# Right-Sized Canon Ingestion Request: {sid_list_str}\n"]
        for sid, text, path in loaded_sources:
            user_parts.append(f"### Source: {sid} ({path.name})\n{text[:6000]}\n")
            sections.append(PromptSection(name=f"Source: {path.name}", content=text[:6000], priority=1))

        user_parts.append(
            "---\n\n"
            "## Directive\n"
            f"Synthesize the above sources into a consolidated, right-sized canon baseline (3 KB to 15 KB). "
            f"Record in frontmatter:\nsource_ids:\n{sid_yaml_str}\n"
            'Ground claims with literal quotes *"..."* linking to their respective sources.'
        )
        user_prompt = "\n".join(user_parts)

        return PromptResult(
            action="canon-ingest",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            token_estimate=estimate_tokens(system_prompt) + estimate_tokens(user_prompt),
            sections=sections,
        )

    def render_lore_dossier(self, topic_or_entity: str) -> PromptResult:
        """Assemble dossier context for an entity or concept across all vault zones."""
        hits = search(self.vault, query=topic_or_entity, limit=5)
        sections: list[PromptSection] = []

        for h in hits:
            f_path = self.vault.root / h.rel_path
            txt = read_text_or_none(f_path)
            if txt:
                sections.append(PromptSection(name=f"{h.title} ({h.page_type})", content=txt[:1500], priority=2))

        system_prompt = (
            "You are a narrative continuity auditor and story architect.\n"
            "Synthesize all available knowledge regarding the requested entity into a unified, cross-verified dossier. "
            "Highlight any continuity conflicts, missing visual settei HUDs, or epistemic ambiguities."
        )

        user_body = "\n\n---\n\n".join(f"## {s.name}\n{s.content}" for s in sections)
        user_prompt = (
            f"# Lore Dossier Request: {topic_or_entity}\n\n"
            f"{user_body}\n\n"
            f"---\n\n"
            f"## Synthesis Directive\n"
            f"Provide a cohesive analysis of '{topic_or_entity}', structured by: Summary, Visual HUD, Capabilities, Epistemic Horizon, and Open Questions."
        )

        return PromptResult(
            action="lore-dossier",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            token_estimate=estimate_tokens(system_prompt) + estimate_tokens(user_prompt),
            sections=sections,
        )

    def render_foreshadowing_audit(self) -> PromptResult:
        """Assemble prompt for auditing clue-to-payoff distances in the foreshadowing ledger."""
        fsh_file = self.vault.root / "08_Ledgers" / "LDG-Foreshadowing.md"
        fsh_text = read_text_or_none(fsh_file) or "No foreshadowing ledger found."

        threads_file = self.vault.root / "08_Ledgers" / "LDG-Active_Threads.md"
        threads_text = read_text_or_none(threads_file) or ""

        system_prompt = (
            "You are a narrative structure and pacing consultant.\n"
            "Audit the foreshadowing ledger against active plot threads. Evaluate Chekhov promises, clue setup-to-payoff distance, "
            "and identify any clues at risk of becoming orphaned or overdue."
        )

        user_prompt = (
            f"# Foreshadowing Setup & Payoff Audit\n\n"
            f"## Ledger: LDG-Foreshadowing\n{fsh_text}\n\n"
            f"## Active Threads\n{threads_text}\n\n"
            f"---\n\n"
            f"## Directive\n"
            f"Analyze clue payoff trajectories, calculate chapter distance, and flag overdue items (VAL028)."
        )

        return PromptResult(
            action="foreshadowing-audit",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            token_estimate=estimate_tokens(system_prompt) + estimate_tokens(user_prompt),
            sections=[
                PromptSection(name="Foreshadowing Ledger", content=fsh_text, priority=1),
                PromptSection(name="Active Threads", content=threads_text, priority=1),
            ],
        )

    def render_conflict_arbitration(self, contradiction_file: str | None = None) -> PromptResult:
        """Assemble context for resolving an identified canon or lore contradiction."""
        contra_file = self.vault.root / "08_Ledgers" / "LDG-Contradictions.md"
        contra_text = read_text_or_none(contra_file) or ""

        system_prompt = (
            "You are a canon arbitration specialist.\n"
            "Apply the Canonical Hierarchy of Truth:\n"
            "1. Primary Source Canon (Frozen raw sources)\n"
            "2. Secondary Author Statements\n"
            "3. Fanfiction Canon / Deliberate PODs\n"
            "4. Speculation\n"
            "Resolve the conflict by determining whether it is an in-universe epistemic misunderstanding, a deliberate POD divergence, or a required retcon."
        )

        user_prompt = (
            f"# Canon Contradiction Arbitration\n\n"
            f"## Contradictions Ledger\n{contra_text}\n\n"
            f"---\n\n"
            f"## Directive\n"
            f"Arbitrate the conflict, define the governing resolution rule, and recommend exact updates to baselines and ledgers."
        )

        return PromptResult(
            action="conflict-arbitration",
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            token_estimate=estimate_tokens(system_prompt) + estimate_tokens(user_prompt),
            sections=[PromptSection(name="Contradictions Ledger", content=contra_text, priority=1)],
        )

    def validate_output(
        self,
        action: str,
        output_text: str,
        source_text: str | None = None,
    ) -> ValidationReport:
        """Perform deterministic invariant validation on LLM output."""
        errors: list[str] = []
        warnings: list[str] = []
        metrics: dict[str, Any] = {}

        # 1. VAL010: Zero CJK outside Sources/
        cjk_matches = _CJK_PATTERN.findall(output_text)
        metrics["cjk_char_count"] = len(cjk_matches)
        if cjk_matches:
            sample = "".join(cjk_matches[:5])
            errors.append(f"VAL010 Violation: Output contains {len(cjk_matches)} CJK characters (sample: '{sample}').")

        # 2. VAL024: Anti-AI Preambles
        lines = [line.strip() for line in output_text.splitlines() if line.strip()]
        if lines:
            first_line = lines[0]
            if _AI_PREAMBLES.match(first_line):
                errors.append(f"VAL024 Violation: Conversational AI preamble detected: '{first_line[:40]}...'.")

        # 3. Passive Voice Indicators
        passives = _PASSIVE_INDICATORS.findall(output_text)
        metrics["passive_voice_count"] = len(passives)
        if len(passives) > 6:
            warnings.append(f"Stylistic Warning: High frequency of passive voice constructs ({len(passives)} found).")

        # 4. Paragraph delimiter tracking (<!-- p:N -->)
        p_markers = re.findall(r"<!--\s*p:(\d+)\s*-->", output_text)
        metrics["paragraph_marker_count"] = len(p_markers)

        if action in ("write-chapter", "translate-chapter"):
            if not p_markers:
                warnings.append("Format Warning: No '<!-- p:N -->' paragraph delimiters found in narrative output.")
            else:
                # Check sequential integrity
                nums = [int(m) for m in p_markers]
                expected = list(range(1, len(nums) + 1))
                if nums != expected:
                    warnings.append(f"Sequence Warning: Paragraph markers not strictly sequential from 1 to {len(nums)}.")

        # 5. MSC004: Translation Parity Check
        if action == "translate-chapter" and source_text:
            src_paras = [
                p.strip()
                for p in source_text.split("\n\n")
                if p.strip() and not p.strip().startswith("---") and not p.strip().startswith("# ")
            ]
            out_paras = [
                p.strip()
                for p in output_text.split("\n\n")
                if p.strip() and not p.strip().startswith("---") and not p.strip().startswith("# ")
            ]
            diff = abs(len(src_paras) - len(out_paras))
            tolerance = max(8, int(0.10 * len(src_paras)))
            metrics["source_paragraphs"] = len(src_paras)
            metrics["output_paragraphs"] = len(out_paras)
            metrics["parity_diff"] = diff
            metrics["parity_tolerance"] = tolerance

            if diff > tolerance:
                errors.append(
                    f"MSC004 Violation: Translation divergence ({len(out_paras)} output paras vs {len(src_paras)} source paras, diff {diff} exceeds tolerance {tolerance})."
                )

        # 6. Wikilink bracket syntax check
        open_brackets = output_text.count("[[")
        close_brackets = output_text.count("]]")
        metrics["wikilinks_detected"] = open_brackets
        if open_brackets != close_brackets:
            errors.append(f"Syntax Error: Unbalanced wikilink brackets ({open_brackets} '[[' vs {close_brackets} ']]').")

        is_valid = len(errors) == 0
        return ValidationReport(
            is_valid=is_valid,
            errors=errors,
            warnings=warnings,
            metrics=metrics,
        )

"""Offline folder mirroring into Sources/inbox/ (Second_brain importer.py parity / ADR-029)."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from narr.clip import extract_html, extract_pdf
from narr.vault import Vault


def _collect_existing_hashes(vault: Vault) -> set[str]:
    """Collect all SHA-256 hashes from existing .meta.json sidecars and Sources/.meta.json.

    Args:
        vault: Story bible Vault instance.

    Returns:
        Set of hex-encoded SHA-256 digest strings.
    """
    hashes: set[str] = set()
    sources_dir = vault.sources_dir
    if not sources_dir.exists():
        return hashes

    # 1. Check Sources/.meta.json (central frozen index)
    main_meta_file = vault.sources_meta_path
    if main_meta_file.is_file():
        try:
            main_data = json.loads(main_meta_file.read_text(encoding="utf-8"))
            if isinstance(main_data, dict):
                for val in main_data.values():
                    if isinstance(val, dict) and "sha256" in val:
                        hashes.add(str(val["sha256"]))
        except Exception:
            pass

    # 2. Check individual sidecars across sources (including inbox)
    for meta_p in sources_dir.rglob("*.meta.json"):
        if meta_p.name == ".meta.json":
            continue
        try:
            m_data = json.loads(meta_p.read_text(encoding="utf-8"))
            if isinstance(m_data, dict) and "sha256" in m_data:
                hashes.add(str(m_data["sha256"]))
        except Exception:
            continue

    return hashes


def import_folder(folder: Path, vault: Vault, label: str | None = None, dry_run: bool = False) -> dict[str, Any]:
    """Mirror folder of lore documents into Sources/inbox/ with content hashing.

    Args:
        folder: Local directory path containing lore documents.
        vault: Target story bible Vault instance.
        label: Optional origin label describing the source collection.
        dry_run: When True, simulates the import without modifying files on disk.

    Returns:
        Dictionary containing counts of imported and skipped files, and sample IDs.

    Raises:
        NotADirectoryError: If folder path does not exist or is not a directory.
    """
    if not folder.is_dir():
        raise NotADirectoryError(f"Target path '{folder}' is not a directory.")

    inbox_dir = vault.sources_inbox_dir
    inbox_dir.mkdir(parents=True, exist_ok=True)

    existing_hashes = _collect_existing_hashes(vault)

    imported: list[str] = []
    skipped: list[str] = []

    supported_suffixes = {".md", ".txt", ".html", ".htm", ".pdf"}

    for file_path in sorted(folder.rglob("*")):
        if not file_path.is_file() or file_path.suffix.lower() not in supported_suffixes:
            continue

        data = file_path.read_bytes()
        file_hash = hashlib.sha256(data).hexdigest()
        stem = file_path.stem.replace(" ", "_")
        source_id = f"SRC-IMP-{stem}"

        if file_hash in existing_hashes:
            skipped.append(file_path.name)
            continue

        if dry_run:
            imported.append(f"[dry-run] {source_id} ({file_path.name})")
            continue

        # Extract text content cleanly based on suffix
        ext = file_path.suffix.lower()
        title = file_path.stem
        text_content: str = ""

        if ext == ".pdf":
            extracted_title, text_content = extract_pdf(data, fallback_title=file_path.stem)
            if extracted_title and extracted_title != "PDF Document":
                title = extracted_title
        elif ext in (".html", ".htm"):
            raw_html = data.decode("utf-8", errors="replace")
            extracted_title, text_content = extract_html(raw_html, fallback_title=file_path.stem)
            if extracted_title and extracted_title != "Captured_Source":
                title = extracted_title
        else:
            text_content = data.decode("utf-8", errors="replace")

        # Write to inbox
        dest_file = inbox_dir / f"{source_id}.md"
        sidecar_file = inbox_dir / f"{source_id}.meta.json"

        wrapped_text = f"""---
uid: "{source_id}"
type: source
title: "{title}"
origin_label: "{label or "folder_import"}"
origin_file: "{file_path.name}"
status: inbox
imported: "{datetime.now(UTC).isoformat()}"
---
# {title}

{text_content}
"""
        dest_file.write_text(wrapped_text, encoding="utf-8")
        sidecar_meta = {
            "source_id": source_id,
            "title": title,
            "sha256": file_hash,
            "status": "inbox",
            "imported": datetime.now(UTC).isoformat(),
        }
        sidecar_file.write_text(json.dumps(sidecar_meta, indent=2), encoding="utf-8")
        existing_hashes.add(file_hash)
        imported.append(source_id)

    return {
        "imported_count": len(imported),
        "skipped_count": len(skipped),
        "imported": imported[:10],
        "skipped": skipped[:10],
    }

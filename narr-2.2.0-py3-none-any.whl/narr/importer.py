"""Offline folder mirroring into Sources/inbox/ (Second_brain importer.py parity / ADR-029)."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from narr.vault import Vault


def import_folder(folder: Path, vault: Vault, label: str | None = None, dry_run: bool = False) -> dict[str, Any]:
    """Mirror folder of lore documents into Sources/inbox/ with content hashing."""
    if not folder.is_dir():
        raise NotADirectoryError(f"Target path '{folder}' is not a directory.")

    inbox_dir = vault.root / "01_Canon_and_Divergence" / "Sources" / "inbox"
    inbox_dir.mkdir(parents=True, exist_ok=True)

    # Collect existing sha256 hashes
    existing_hashes: set[str] = set()
    sources_dir = vault.root / "01_Canon_and_Divergence" / "Sources"
    for meta_p in sources_dir.rglob("*.meta.json"):
        try:
            m_data = json.loads(meta_p.read_text(encoding="utf-8"))
            if "sha256" in m_data:
                existing_hashes.add(m_data["sha256"])
        except Exception:
            continue

    imported: list[str] = []
    skipped: list[str] = []

    for file_path in folder.rglob("*"):
        if not file_path.is_file() or file_path.suffix.lower() not in (".md", ".txt", ".html", ".htm"):
            continue

        data = file_path.read_bytes()
        file_hash = hashlib.sha256(data).hexdigest()
        stem = file_path.stem.replace(" ", "_")
        source_id = f"SRC-IMP-{stem}"

        if file_hash in existing_hashes:
            skipped.append(file_path.name)
            continue

        if dry_run:
            imported.append(f"[dry-run] {source_id} ({file_path.name})")
            continue

        # Write to inbox
        dest_file = inbox_dir / f"{source_id}.md"
        sidecar_file = inbox_dir / f"{source_id}.meta.json"

        text_content = data.decode("utf-8", errors="replace")
        wrapped_text = f"""---
uid: "{source_id}"
type: source
title: "{file_path.stem}"
origin_label: "{label or "folder_import"}"
origin_file: "{file_path.name}"
status: inbox
imported: "{datetime.now(UTC).isoformat()}"
---
# {file_path.stem}

{text_content}
"""
        dest_file.write_text(wrapped_text, encoding="utf-8")
        sidecar_meta = {
            "source_id": source_id,
            "title": file_path.stem,
            "sha256": file_hash,
            "status": "inbox",
            "imported": datetime.now(UTC).isoformat(),
        }
        sidecar_file.write_text(json.dumps(sidecar_meta, indent=2), encoding="utf-8")
        existing_hashes.add(file_hash)
        imported.append(source_id)

    return {
        "imported_count": len(imported),
        "skipped_count": len(skipped),
        "imported": imported[:10],
        "skipped": skipped[:10],
    }

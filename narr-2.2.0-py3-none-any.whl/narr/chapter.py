"""Chapter drafting, scaffolding, and lifecycle management (narr.chapter)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from narr.frontmatter import FrontmatterError, parse
from narr.prompt import PromptEngine
from narr.translate import check_translation_parity, extract_paragraph_markers
from narr.vault import Vault, VaultError, read_text, slugify, write_text_atomic


@dataclass
class ChapterStatusRecord:
    """Consolidated lifecycle status for a serialized chapter."""

    chapter_num: int
    pt_file: str
    title: str
    pov: str
    word_count: int
    marker_count: int
    validation_passed: bool
    validation_errors: list[str] = field(default_factory=list)
    es_file: str | None = None
    translation_passed: bool = False
    translation_diff: int = 0


def create_chapter(
    vault: Vault,
    number: int,
    slug: str,
    title: str | None = None,
    pov: str | None = None,
    volume: int = 1,
    force: bool = False,
) -> Path:
    """Scaffold a new pt-BR manuscript chapter with compliant frontmatter and initial paragraph tag.

    Args:
        vault: Story bible Vault instance.
        number: Sequential chapter number.
        slug: Short descriptive slug for filename.
        title: Optional full chapter title.
        pov: Optional POV character name.
        volume: Volume number (default: 1).
        force: If True, overwrite existing chapter file.

    Returns:
        Path to the newly created chapter file.

    Raises:
        VaultError: If chapter file already exists and force is False.
    """
    clean_slug = slugify(slug)
    clean_title = title.strip() if title else f"Capítulo {number:02d}: {slug.replace('_', ' ').title()}"

    if pov:
        clean_pov = pov.strip()
        if not clean_pov.startswith("[["):
            clean_pov = f"[[CHR-{clean_pov.replace(' ', '_')}]]"
    else:
        clean_pov = "[[CHR-Protagonist]]"

    dest_dir = vault.root / "04_Manuscript" / "pt-BR" / "Chapters"
    dest_dir.mkdir(parents=True, exist_ok=True)

    file_path = dest_dir / f"C{number:02d}_{clean_slug}.md"
    if file_path.is_file() and not force:
        raise VaultError(f"Chapter file '{vault.rel(file_path)}' already exists. Use --force to overwrite.")

    today = datetime.now().strftime("%Y-%m-%d")
    frontmatter = (
        f"---\n"
        f"uid: C{number:02d}_{clean_slug}\n"
        f"type: chapter\n"
        f'title: "{clean_title}"\n'
        f"chapter_number: {number}\n"
        f"volume_number: {volume}\n"
        f"status: draft\n"
        f"language: pt-BR\n"
        f'pov: "{clean_pov}"\n'
        f"word_count: 0\n"
        f"created: {today}\n"
        f"updated: {today}\n"
        f"tags:\n"
        f"  - manuscript/draft\n"
        f"---\n"
        f"# {clean_title}\n\n"
        f"<!-- p:1 -->\n"
    )

    write_text_atomic(file_path, frontmatter)
    return file_path


def get_chapter_status(
    vault: Vault,
    chapter_num: int | None = None,
) -> list[ChapterStatusRecord]:
    """Inspect and audit all manuscript chapters across pt-BR drafting and es translation."""
    pt_dir = vault.root / "04_Manuscript" / "pt-BR" / "Chapters"
    es_dir = vault.root / "04_Manuscript" / "es" / "Chapters"

    if not pt_dir.is_dir():
        return []

    chapter_files = sorted(pt_dir.glob("C*.md"))
    records: list[ChapterStatusRecord] = []
    engine = PromptEngine(vault)

    for pt_file in chapter_files:
        m = re.match(r"^C(\d+)[_-](.*)\.md$", pt_file.name)
        if not m:
            continue

        c_num = int(m.group(1))
        if chapter_num is not None and c_num != chapter_num:
            continue

        raw_text = read_text(pt_file)
        try:
            doc = parse(raw_text)
            title = str(doc.meta.get("title", pt_file.stem))
            pov = str(doc.meta.get("pov", "Unknown"))
            body = doc.body
        except FrontmatterError:
            title = pt_file.stem
            pov = "Unknown"
            body = raw_text

        # Word count & markers
        words = len(body.split())
        markers = extract_paragraph_markers(body)
        marker_count = len(markers)

        # Invariant validation
        v_report = engine.validate_output("write-chapter", body)

        # Translation check
        es_file_rel: str | None = None
        translation_passed = False
        translation_diff = 0

        if es_dir.is_dir():
            es_candidates = list(es_dir.glob(f"C{c_num:02d}[_-]*.md")) or list(es_dir.glob(f"C{c_num}[_-]*.md"))
            if es_candidates:
                es_file_rel = vault.rel(es_candidates[0])
                try:
                    p_report = check_translation_parity(vault, c_num)
                    translation_passed = p_report.passed
                    translation_diff = p_report.diff
                except VaultError:
                    translation_passed = False

        records.append(
            ChapterStatusRecord(
                chapter_num=c_num,
                pt_file=vault.rel(pt_file),
                title=title,
                pov=pov,
                word_count=words,
                marker_count=marker_count,
                validation_passed=v_report.is_valid,
                validation_errors=v_report.errors,
                es_file=es_file_rel,
                translation_passed=translation_passed,
                translation_diff=translation_diff,
            )
        )

    return sorted(records, key=lambda r: r.chapter_num)

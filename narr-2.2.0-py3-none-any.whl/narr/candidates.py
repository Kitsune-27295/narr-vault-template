"""Consolidation candidates engine (Second_brain review.py parity / ADR-004).

Surfaces deterministic leads: title overlap via token Jaccard similarity,
stale links pointing to superseded pages, and declared/open contradictions.
"""

from __future__ import annotations

import re
from itertools import combinations
from pathlib import Path
from typing import Any

from narr.pages import Page
from narr.vault import Vault, read_text_or_none

TITLE_JACCARD_THRESHOLD = 0.60


def _tokens(text: str) -> set[str]:
    """Extract significant lowercase word tokens >= 3 chars."""
    cleaned = text.lower().replace("_", " ").replace("-", " ")
    return {t for t in re.findall(r"\w+", cleaned) if len(t) >= 3 and not t.isdigit()}


def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


def find_candidates(vault: Vault) -> list[dict[str, Any]]:
    """Surface actionable consolidation leads across vault."""
    pages: list[tuple[Page, str]] = []
    for rel_path, _ in vault.entries(".md"):
        if "Meta/Templates" in rel_path or "Sources/" in rel_path:
            continue
        p = Page.load(vault.root / rel_path, rel_path)
        if p:
            pages.append((p, rel_path))

    active = [(p, r) for p, r in pages if (p.doc.meta or {}).get("status") != "superseded"]
    leads: list[dict[str, Any]] = []

    # 1. Jaccard Token Overlap (Merge Candidates)
    links_by_path = {r: {l.split("|", 1)[0].split("#", 1)[0].strip().lower() for l in p.links} for p, r in active}
    tokens_by_path = {r: _tokens(f"{Path(r).stem} {p.title or ''}") for p, r in active}

    for (p1, r1), (p2, r2) in combinations(sorted(active, key=lambda x: x[1]), 2):
        type1 = p1.page_type
        type2 = p2.page_type
        if type1 != type2 or not type1:
            continue

        tok1 = tokens_by_path[r1]
        tok2 = tokens_by_path[r2]
        score = _jaccard(tok1, tok2)
        if score >= TITLE_JACCARD_THRESHOLD:
            # If already linked both ways, considered mutually judged
            stem1 = Path(r1).stem.lower()
            stem2 = Path(r2).stem.lower()
            if stem2 in links_by_path[r1] and stem1 in links_by_path[r2]:
                continue
            leads.append(
                {
                    "kind": "merge?",
                    "pages": [r1, r2],
                    "score": round(score, 2),
                    "reason": f"Same type '{type1}', title tokens overlap (Jaccard {score:.2f})",
                }
            )

    # 2. Stale Links pointing to Superseded Pages
    superseded_stems: dict[str, tuple[str, str]] = {}
    for p, r in pages:
        meta = p.doc.meta or {}
        if meta.get("status") == "superseded":
            stem = Path(r).stem.lower()
            successor = meta.get("superseded_by", "")
            superseded_stems[stem] = (r, str(successor))

    for p, r in active:
        for l in p.links:
            clean_l = l.split("|", 1)[0].split("#", 1)[0].strip().lower()
            if clean_l in superseded_stems:
                old_path, successor = superseded_stems[clean_l]
                leads.append(
                    {
                        "kind": "stale_link",
                        "pages": [r, old_path],
                        "reason": f"Links to superseded [[{clean_l}]]; update to successor [[{successor}]]"
                        if successor
                        else f"Links to superseded [[{clean_l}]]",
                    }
                )

    # 3. Contradictions
    for p, r in active:
        meta = p.doc.meta or {}
        if meta.get("contradicts"):
            c_val = meta["contradicts"]
            leads.append(
                {
                    "kind": "contradiction",
                    "pages": [r],
                    "reason": f"Declared contradiction against [[{c_val}]]",
                }
            )

    # Open contradictions from ledger
    ledger_path = vault.root / "08_Ledgers" / "LDG-Contradictions.md"
    if ledger_path.is_file():
        txt = read_text_or_none(ledger_path) or ""
        for line in txt.splitlines():
            if line.startswith("|") and ("open" in line.lower() or "aberta" in line.lower()):
                leads.append(
                    {
                        "kind": "contradiction",
                        "pages": ["08_Ledgers/LDG-Contradictions.md"],
                        "reason": f"Ledger Open: {line.strip()}",
                    }
                )

    return leads

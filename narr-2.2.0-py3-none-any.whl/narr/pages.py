"""Markdown page loading, link extraction, verbatim quote harvesting, and AST normalization."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from narr.frontmatter import Doc, parse
from narr.vault import read_text_or_none

_WIKILINK = re.compile(r"\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|([^\]]+))?\]\]")
_TAG = re.compile(r"(?<![A-Za-z0-9_])#([A-Za-z0-9_/-]+)")
_VERBATIM = re.compile(r"\*\"([^\"]+)\"\*")
_DATA_URI = re.compile(r"data:[^;]+;base64,[A-Za-z0-9+/=]+")


def strip_data_uris(text: str) -> str:
    """Strip base64 data URIs to avoid index bloat (ADR-020)."""
    return _DATA_URI.sub("", text)


def extract_links(text: str) -> list[str]:
    """Extract list of target page titles from [[Target]] or [[Target|Label]]."""
    targets: list[str] = []
    for match in _WIKILINK.finditer(text):
        target = match.group(1).strip()
        if target and target not in targets:
            targets.append(target)
    return targets


def extract_verbatim_quotes(text: str) -> list[str]:
    """Extract literal quotes in *"..."* format."""
    return [m.group(1).strip() for m in _VERBATIM.finditer(text)]


def extract_tags(text: str) -> list[str]:
    """Extract markdown tags like #character/protagonist."""
    tags: list[str] = []
    for match in _TAG.finditer(text):
        t = match.group(1).strip()
        if t and t not in tags:
            tags.append(t)
    return tags


def is_placeholder(target: str) -> bool:
    """Check if a wikilink target is a known blueprint placeholder (DEC-05)."""
    t = target.strip()
    return t.endswith("-Pending") or (t.startswith("<") and t.endswith(">"))


def meta_links(meta: dict[str, Any]) -> list[str]:
    """Extract list of target page titles from wikilinks inside frontmatter YAML values (DEC-06)."""
    targets: list[str] = []

    def _walk(val: Any) -> None:
        if isinstance(val, str):
            for t in extract_links(val):
                if t not in targets:
                    targets.append(t)
        elif isinstance(val, list):
            for item in val:
                _walk(item)
        elif isinstance(val, dict):
            for item in val.values():
                _walk(item)

    _walk(meta)
    return targets


@dataclass
class Page:
    path: Path
    rel_path: str
    doc: Doc
    title: str = ""
    uid: str = ""
    page_type: str = ""
    status: str = ""
    scope: str = ""
    links: list[str] = field(default_factory=list)
    verbatim_quotes: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, path: Path, rel_path: str) -> Page | None:
        raw = read_text_or_none(path)
        if raw is None:
            return None
        clean = strip_data_uris(raw)
        try:
            doc = parse(clean)
        except Exception:
            return None
        meta = doc.meta
        title = str(meta.get("title") or path.stem)
        uid = str(meta.get("uid") or "")
        ptype = str(meta.get("type") or "")
        status = str(meta.get("status") or "")
        scope = str(meta.get("scope") or "")
        links = extract_links(doc.body)
        for ml in meta_links(meta):
            if ml not in links:
                links.append(ml)
        quotes = extract_verbatim_quotes(doc.body)
        tags = list(meta.get("tags") or [])
        tags.extend(extract_tags(doc.body))
        return cls(
            path=path,
            rel_path=rel_path,
            doc=doc,
            title=title,
            uid=uid,
            page_type=ptype,
            status=status,
            scope=scope,
            links=links,
            verbatim_quotes=quotes,
            tags=sorted(set(tags)),
        )

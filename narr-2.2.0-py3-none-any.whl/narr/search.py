"""SQLite FTS5 full-text index with auto-synchronization and BM25 ranking."""

from __future__ import annotations

import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from narr.pages import Page
from narr.vault import Vault, fold


@dataclass(frozen=True)
class SearchHit:
    """Represents a ranked full-text search match.

    Attributes:
        rel_path: Vault-relative path of the matching note.
        title: Title of the matched page.
        page_type: Entity or note type identifier.
        zone: Vault zone directory name.
        snippet: Keyword-highlighted excerpt from the document body.
        score: BM25 relevance score (lower absolute is closer match in FTS5).
    """

    rel_path: str
    title: str
    page_type: str
    zone: str
    snippet: str
    score: float


def open_db(vault: Vault) -> sqlite3.Connection:
    """Open or initialize the SQLite FTS5 index database.

    Args:
        vault: Story bible vault instance.

    Returns:
        Active sqlite3 Connection object with WAL mode enabled.
    """
    db_path = vault.index_db
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pages (
            rel_path TEXT PRIMARY KEY,
            title TEXT,
            ptype TEXT,
            zone TEXT,
            scope TEXT,
            mtime REAL,
            size INT
        )
    """)
    conn.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS pages_fts USING fts5(
            rel_path UNINDEXED,
            title,
            body,
            tags,
            tokenize='porter unicode61 remove_diacritics 2'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS links (
            src_path TEXT,
            dst_title TEXT,
            FOREIGN KEY(src_path) REFERENCES pages(rel_path) ON DELETE CASCADE
        )
    """)
    return conn


def sync_index(vault: Vault) -> int:
    """Synchronize SQLite FTS5 index with filesystem state.

    Args:
        vault: Story bible vault instance.

    Returns:
        Number of modified, newly inserted, or deleted files synchronized.
    """
    conn = open_db(vault)
    changed = 0

    try:
        # Get existing indexed state
        cursor = conn.cursor()
        existing = {row[0]: (row[1], row[2]) for row in cursor.execute("SELECT rel_path, mtime, size FROM pages")}

        fs_files: dict[str, Path] = {}
        for rel_path, entry in vault.entries(".md"):
            fs_files[rel_path] = Path(entry.path)
            stat = entry.stat()
            mtime, size = stat.st_mtime, stat.st_size

            old = existing.get(rel_path)
            if old is None or old[0] != mtime or old[1] != size:
                page = Page.load(Path(entry.path), rel_path)
                if not page:
                    continue

                zone = rel_path.split("/", 1)[0]
                cursor.execute(
                    "INSERT OR REPLACE INTO pages VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (rel_path, page.title, page.page_type, zone, page.scope, mtime, size),
                )
                cursor.execute("DELETE FROM pages_fts WHERE rel_path = ?", (rel_path,))
                tags_str = " ".join(page.tags)
                body_with_uid = f"{page.uid}\n\n{page.doc.body}" if page.uid else page.doc.body
                cursor.execute(
                    "INSERT INTO pages_fts (rel_path, title, body, tags) VALUES (?, ?, ?, ?)",
                    (rel_path, page.title, body_with_uid, tags_str),
                )
                cursor.execute("DELETE FROM links WHERE src_path = ?", (rel_path,))
                for target in page.links:
                    cursor.execute("INSERT INTO links VALUES (?, ?)", (rel_path, target))
                changed += 1

        # Delete removed files
        for rel_path in existing:
            if rel_path not in fs_files:
                cursor.execute("DELETE FROM pages WHERE rel_path = ?", (rel_path,))
                cursor.execute("DELETE FROM pages_fts WHERE rel_path = ?", (rel_path,))
                cursor.execute("DELETE FROM links WHERE src_path = ?", (rel_path,))
                changed += 1

        conn.commit()
    finally:
        conn.close()

    return changed


def search(
    vault: Vault,
    query: str,
    limit: int = 10,
    zone: str | None = None,
    ptype: str | None = None,
    sync: bool = True,
) -> list[SearchHit]:
    """Execute BM25 ranked full-text search over synchronized FTS5 index.

    Args:
        vault: Story bible vault instance.
        query: User search string with keyword terms.
        limit: Maximum number of search hits to return.
        zone: Optional vault zone filter (e.g. 02_Story_Bible).
        ptype: Optional entity type filter (e.g. character, martial_soul).
        sync: Whether to trigger incremental index synchronization prior to search.

    Returns:
        List of ranked SearchHit instances matching the query.
    """
    if sync:
        sync_index(vault)
    conn = open_db(vault)
    hits: list[SearchHit] = []

    try:
        cursor = conn.cursor()
        clean_q = fold(query).replace('"', '""')
        terms: list[str] = []
        for raw_term in clean_q.split():
            clean_term = re.sub(r"[^\w\-]", "", raw_term)
            if clean_term:
                terms.append(f'"{clean_term}"*')
        if not terms:
            return []
        fts_match = " OR ".join(terms)

        sql = """
            SELECT p.rel_path, p.title, p.ptype, p.zone,
                   snippet(pages_fts, 2, '==', '==', '...', 15) as snip,
                   bm25(pages_fts, 5.0, 1.0, 2.0) as rank
            FROM pages_fts
            JOIN pages p ON pages_fts.rel_path = p.rel_path
            WHERE pages_fts MATCH ?
        """
        params: list[Any] = [fts_match]
        if zone:
            sql += " AND p.zone = ?"
            params.append(zone)
        if ptype:
            sql += " AND p.ptype = ?"
            params.append(ptype)

        sql += " ORDER BY rank LIMIT ?"
        params.append(limit)

        for row in cursor.execute(sql, params):
            hits.append(
                SearchHit(
                    rel_path=row[0],
                    title=row[1],
                    page_type=row[2],
                    zone=row[3],
                    snippet=row[4] or "",
                    score=round(abs(float(row[5])), 3),
                )
            )
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()

    return hits

"""Vault location, configuration, atomic IO and safe filesystem boundaries."""

from __future__ import annotations

import os
import re
import tempfile
import unicodedata
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

MARKER = ".narr"
CONFIG_FILE = "vault.yaml"
BOM = chr(0xFEFF)
_SKIP_DIRS = frozenset(
    {MARKER, ".bible", ".claude", ".agents", ".git", ".obsidian", ".trash", "tools", "__pycache__", ".venv", "venv", "node_modules"}
)
_ILLEGAL_NAME = re.compile(r'[#|^:\[\]%<>"/\\?*\x00-\x1f\s]')
_RESERVED = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}

ZONES = {
    "atlas": "00_Atlas",
    "sources": "01_Canon_and_Divergence/Sources",
    "baselines": "01_Canon_and_Divergence/Baselines",
    "pods": "01_Canon_and_Divergence/PODs",
    "bible": "02_Story_Bible",
    "continuity": "03_Continuity_and_Timeline",
    "manuscript": "04_Manuscript",
    "craft": "05_Craft_and_Feedback",
    "sandbox": "06_Ideation_and_Unblocking",
    "cosmology": "07_Cosmologies_and_Multiverse",
    "ledgers": "08_Ledgers",
    "context": "context",
    "memory": "memory",
    "meta": "Meta",
}


class VaultError(Exception):
    """An operation on the narrative vault was refused or failed."""


def is_safe_name(name: str) -> bool:
    """Validate filename safety: zero spaces, no illegal characters, no Windows reserved stems."""
    stem = name.split(".", 1)[0]
    return bool(name.strip()) and not _ILLEGAL_NAME.search(name) and not name.endswith((" ", ".")) and stem.upper() not in _RESERVED


def fold(text: str) -> str:
    """Accent- and case-insensitive string folding."""
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(c for c in decomposed if not unicodedata.combining(c)).casefold()


def slugify(text: str, limit: int = 60) -> str:
    """Create URL/file safe slug."""
    slug = re.sub(r"[^a-zA-Z0-9_-]+", "_", text).strip("_")
    return slug[:limit].rstrip("_") or "untitled"


def read_text(path: Path) -> str:
    """Read file text stripping BOM."""
    return path.read_text(encoding="utf-8").removeprefix(BOM)


def read_text_or_none(path: Path) -> str | None:
    """Read file text or None if unreadable."""
    try:
        return read_text(path)
    except (OSError, UnicodeDecodeError):
        return None


def write_text_atomic(path: Path, text: str) -> bool:
    """Write text atomically via temporary file and replace. Return False if identical."""
    data = text.encode("utf-8")
    with suppress(OSError):
        if path.stat().st_size == len(data) and path.read_bytes() == data:
            return False
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".narr-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        Path(tmp).replace(path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
    return True


@dataclass(frozen=True)
class Vault:
    root: Path
    config: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def find(cls, start: Path | None = None) -> Vault:
        """Find vault root walking upwards looking for vault.yaml."""
        here = (start or Path.cwd()).resolve()
        for candidate in (here, *here.parents):
            config_path = candidate / CONFIG_FILE
            if config_path.is_file():
                try:
                    cfg = yaml.safe_load(read_text(config_path)) or {}
                except Exception as exc:
                    raise VaultError(f"Malformed {CONFIG_FILE}: {exc}") from exc
                return cls(candidate, cfg if isinstance(cfg, dict) else {})
            if (candidate / MARKER).is_dir():
                return cls(candidate, {})
        raise VaultError(f"No narrative vault found at or above {here} (missing {CONFIG_FILE})")

    @property
    def name(self) -> str:
        """Name of the vault from config, vault.yaml, or root folder name."""
        if "name" in self.config:
            return str(self.config["name"])
        cfg_path = self.root / CONFIG_FILE
        if cfg_path.is_file():
            try:
                data = yaml.safe_load(read_text(cfg_path))
                if isinstance(data, dict) and "name" in data:
                    return str(data["name"])
            except Exception:
                pass
        return self.root.name

    @property
    def state(self) -> Path:
        p = self.root / MARKER
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def index_db(self) -> Path:
        return self.state / "index.sqlite"

    @property
    def sources_dir(self) -> Path:
        return self.root / ZONES["sources"]

    @property
    def sources_inbox_dir(self) -> Path:
        p = self.sources_dir / "inbox"
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def sources_meta_path(self) -> Path:
        return self.sources_dir / ".meta.json"

    @property
    def baselines_dir(self) -> Path:
        return self.root / ZONES["baselines"]

    @property
    def pods_dir(self) -> Path:
        return self.root / ZONES["pods"]

    @property
    def bible_dir(self) -> Path:
        return self.root / ZONES["bible"]

    @property
    def ledgers_dir(self) -> Path:
        return self.root / ZONES["ledgers"]

    @property
    def manuscript_dir(self) -> Path:
        return self.root / ZONES["manuscript"]

    @property
    def timeline_dir(self) -> Path:
        return self.root / ZONES["continuity"]

    def entries(self, suffix: str = "") -> list[tuple[str, os.DirEntry[str]]]:
        """List (vault_rel_posix, DirEntry) excluding caches/state."""
        out: list[tuple[str, os.DirEntry[str]]] = []
        pending = [("", self.root)]
        while pending:
            prefix, folder = pending.pop()
            try:
                with os.scandir(folder) as listing:
                    for entry in listing:
                        rel = f"{prefix}{entry.name}"
                        if entry.is_dir(follow_symlinks=False):
                            if not (prefix == "" and entry.name in _SKIP_DIRS):
                                pending.append((f"{rel}/", Path(entry.path)))
                        elif entry.is_file(follow_symlinks=False):
                            if not suffix or entry.name.lower().endswith(suffix):
                                out.append((rel, entry))
            except OSError:
                continue
        return sorted(out, key=lambda item: item[0])

    def files(self) -> list[Path]:
        return [Path(entry.path) for _, entry in self.entries()]

    def markdown_files(self) -> list[Path]:
        return [Path(entry.path) for _, entry in self.entries(".md")]

    def resolve_path(self, target: str | Path) -> Path:
        """Resolve a path canonically and ensure it remains strictly within the vault root (SEC-01)."""
        p = Path(target)
        resolved = (self.root / p).resolve() if not p.is_absolute() else p.resolve()
        if not resolved.is_relative_to(self.root.resolve()):
            raise VaultError(f"Path traversal detected: '{target}' is outside vault boundary")
        return resolved

    def is_immutable(self, target: str | Path) -> bool:
        """Check if a path points to the immutable Sources directory (Rule 30, SEC-01)."""
        resolved = self.resolve_path(target)
        sources_canonical = self.sources_dir.resolve()
        return resolved == sources_canonical or resolved.is_relative_to(sources_canonical)

    def rel(self, path: Path) -> str:
        return path.resolve().relative_to(self.root.resolve()).as_posix()

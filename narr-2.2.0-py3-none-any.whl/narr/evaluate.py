"""Retrieval quality evaluation engine (Second_brain evaluate.py parity / ADR-022).

Evaluates search retrieval quality against eval/queries.yaml (Recall@5, MRR, Hit Rate, NDCG).
"""

from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from narr.search import search, sync_index
from narr.vault import Vault


@dataclass
class EvalMetrics:
    """Benchmark metrics representing retrieval ranking quality.

    Attributes:
        queries_count: Number of evaluation queries executed.
        recall_at_k: Average fraction of expected results retrieved within top K.
        mrr: Mean Reciprocal Rank of first relevant retrieved result.
        hit_rate: Proportion of queries with at least one relevant document retrieved.
        ndcg_at_k: Normalized Discounted Cumulative Gain at rank cutoff K.
        p95_ms: 95th percentile query latency in milliseconds.
        misses: Detailed list of queries that failed to achieve 100% recall.
    """

    queries_count: int
    recall_at_k: float
    mrr: float
    hit_rate: float
    ndcg_at_k: float
    p95_ms: float
    misses: list[dict[str, Any]]


def _dcg(ranks: list[int], k: int) -> float:
    """Calculate Discounted Cumulative Gain for retrieved item ranks."""
    score = 0.0
    for r in ranks:
        if 1 <= r <= k:
            score += 1.0 / math.log2(r + 1)
    return score


def evaluate_retrieval(vault: Vault, k: int = 5, record: bool = False) -> EvalMetrics:
    """Run golden queries evaluation and calculate ranking metrics.

    Args:
        vault: Story bible vault instance.
        k: Cutoff rank for evaluation metrics (default: 5).
        record: If True, append results to eval/runs.jsonl.

    Returns:
        EvalMetrics object containing benchmark scores.

    Raises:
        FileNotFoundError: If eval/queries.yaml is missing from the vault.
    """
    eval_file = vault.root / "eval" / "queries.yaml"
    if not eval_file.is_file():
        raise FileNotFoundError("Missing eval/queries.yaml for retrieval evaluation.")

    raw_queries = yaml.safe_load(eval_file.read_text(encoding="utf-8")) or []
    if not isinstance(raw_queries, list) or not raw_queries:
        return EvalMetrics(0, 0.0, 0.0, 0.0, 0.0, 0.0, [])

    # Pre-sync index once to avoid redundant filesystem scans across batch queries
    sync_index(vault)

    total_recall = 0.0
    total_rr = 0.0
    total_hits = 0
    total_ndcg = 0.0
    latencies: list[float] = []
    misses: list[dict[str, Any]] = []

    for item in raw_queries:
        query_str = item.get("query", "")
        raw_exp = item.get("expect") or item.get("expected") or []
        if isinstance(raw_exp, str):
            raw_exp = [raw_exp]
        expected = [
            Path(e).stem.lower() if ("/" in str(e) or "\\" in str(e) or str(e).endswith(".md")) else str(e).lower() for e in raw_exp
        ]
        if not query_str or not expected:
            continue

        t0 = time.perf_counter()
        results = search(vault, query_str, limit=k, sync=False)
        t1 = time.perf_counter()
        latencies.append((t1 - t0) * 1000)

        retrieved_stems = [Path(r.rel_path).stem.lower() for r in results]

        # Recall
        found = set(expected) & set(retrieved_stems)
        recall = len(found) / len(expected)
        total_recall += recall

        # Hit rate
        if found:
            total_hits += 1

        # MRR
        rr = 0.0
        ranks: list[int] = []
        for idx, stem in enumerate(retrieved_stems, 1):
            if stem in expected:
                ranks.append(idx)
                if rr == 0.0:
                    rr = 1.0 / idx
        total_rr += rr

        # NDCG
        actual_dcg = _dcg(ranks, k)
        ideal_dcg = sum(1.0 / math.log2(i + 1) for i in range(1, min(len(expected), k) + 1))
        ndcg = (actual_dcg / ideal_dcg) if ideal_dcg > 0 else 0.0
        total_ndcg += ndcg

        if recall < 1.0:
            misses.append(
                {
                    "query": query_str,
                    "expected": expected,
                    "retrieved": retrieved_stems,
                    "missing": list(set(expected) - set(retrieved_stems)),
                }
            )

    n = len(raw_queries)
    latencies.sort()
    p95 = latencies[int(len(latencies) * 0.95)] if latencies else 0.0

    metrics = EvalMetrics(
        queries_count=n,
        recall_at_k=round(total_recall / n, 4) if n > 0 else 0.0,
        mrr=round(total_rr / n, 4) if n > 0 else 0.0,
        hit_rate=round(total_hits / n, 4) if n > 0 else 0.0,
        ndcg_at_k=round(total_ndcg / n, 4) if n > 0 else 0.0,
        p95_ms=round(p95, 2),
        misses=misses,
    )

    if record:
        runs_file = vault.root / "eval" / "runs.jsonl"
        runs_file.parent.mkdir(parents=True, exist_ok=True)
        record_entry = {
            "timestamp": datetime.now(UTC).isoformat(),
            "queries": metrics.queries_count,
            "k": k,
            "recall_at_k": metrics.recall_at_k,
            "mrr": metrics.mrr,
            "hit_rate": metrics.hit_rate,
            "ndcg_at_k": metrics.ndcg_at_k,
            "p95_ms": metrics.p95_ms,
        }
        with runs_file.open("a", encoding="utf-8") as rf:
            rf.write(json.dumps(record_entry) + "\n")

    return metrics

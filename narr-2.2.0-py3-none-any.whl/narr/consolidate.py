"""Consolidation engine: candidate duplicates, broken links, and unresolved contradictions (Second_brain parity)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from narr.graph import analyze_graph
from narr.vault import Vault, read_text_or_none


@dataclass
class Lead:
    kind: str  # dead_link, duplicate_candidate, contradiction, orphan
    subject: str
    detail: str
    path: str


def find_consolidation_leads(vault: Vault) -> list[Lead]:
    """Gather leads for vault consolidation."""
    leads: list[Lead] = []

    # 1. Dead links and Orphans from Graph
    rep = analyze_graph(vault)
    for src, dst in rep.dead_links:
        leads.append(
            Lead(
                kind="dead_link",
                subject=dst,
                detail=f"Dead link [[{dst}]] referenced in {src}",
                path=src,
            )
        )

    for orphan in rep.orphans:
        path, role, in_count, out_count = orphan
        leads.append(
            Lead(
                kind="orphan",
                subject=path,
                detail=f"Role: {role}, inbound: {in_count}, outbound: {out_count}",
                path=path,
            )
        )

    # 2. Open Contradictions
    contradictions_ledger = vault.root / "08_Ledgers" / "LDG-Contradictions.md"
    if contradictions_ledger.is_file():
        text = read_text_or_none(contradictions_ledger) or ""
        lines = text.splitlines()
        for idx, line in enumerate(lines):
            if line.startswith("|") and ("open" in line.lower() or "aberta" in line.lower() or "ambiguous" in line.lower()):
                leads.append(
                    Lead(
                        kind="contradiction",
                        subject="Contradição Aberta",
                        detail=line.strip(),
                        path="08_Ledgers/LDG-Contradictions.md",
                    )
                )

    # 3. Near-duplicate titles / candidate stems
    seen_stems: dict[str, str] = {}
    for rel_path, entry in vault.entries(".md"):
        if "Meta/Templates" in rel_path:
            continue
        p = Path(entry.path)
        stem_clean = p.stem.lower().replace("_", "").replace("-", "")
        if stem_clean in seen_stems:
            other = seen_stems[stem_clean]
            leads.append(
                Lead(
                    kind="duplicate_candidate",
                    subject=p.stem,
                    detail=f"Potential title collision or near-duplicate with {other}",
                    path=rel_path,
                )
            )
        else:
            seen_stems[stem_clean] = rel_path

    return sorted(leads, key=lambda l: (l.kind, l.subject))

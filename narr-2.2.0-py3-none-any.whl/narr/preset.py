"""Fandom preset management (narr preset list/apply/export)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from narr.vault import Vault, VaultError, read_text_or_none, write_text_atomic


def list_presets(vault: Vault) -> list[dict[str, Any]]:
    """List all available fandom presets in Meta/Presets/."""
    presets_dir = vault.root / "Meta" / "Presets"
    if not presets_dir.is_dir():
        return []

    manifests: list[dict[str, Any]] = []
    for manifest_path in presets_dir.glob("*/manifest.json"):
        text = read_text_or_none(manifest_path)
        if text:
            try:
                data = json.loads(text)
                if isinstance(data, dict):
                    data["_folder"] = manifest_path.parent.name
                    manifests.append(data)
            except Exception:
                continue
    return manifests


def apply_preset(vault: Vault, name: str) -> str:
    """Apply fandom preset overlay safely without overwriting user data."""
    presets_dir = vault.root / "Meta" / "Presets"
    target_dir = presets_dir / name
    manifest_path = target_dir / "manifest.json"

    if not manifest_path.is_file():
        raise VaultError(f"Preset '{name}' not found at {manifest_path}")

    text = read_text_or_none(manifest_path)
    data = json.loads(text or "{}")
    title = data.get("display_name", name)

    # Copy seed pages if they don't exist
    seeds = data.get("seed_pages", [])
    copied = 0
    for seed_rel in seeds:
        src = target_dir / "seeds" / Path(seed_rel).name
        dst = vault.root / seed_rel
        if src.is_file() and not dst.exists():
            content = read_text_or_none(src)
            if content:
                write_text_atomic(dst, content)
                copied += 1

    return f"Preset '{title}' applied successfully. ({copied} seed pages copied)."

"""Fandom preset management (narr preset list/apply/export/status/remove)."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from narr.vault import Vault, VaultError, read_text_or_none, write_text_atomic


@dataclass
class PresetRollbackReport:
    """Report detailing changes made during a preset rollback.

    Attributes:
        preset_name: Identifier of the rolled back preset.
        removed_seeds: List of seed template relative paths that were safely deleted.
        kept_seeds: List of seed templates preserved due to user modifications.
        removed_types: List of custom types pruned from vault.yaml.
        warnings: Advisory messages regarding preserved files or shared types.
    """

    preset_name: str
    removed_seeds: list[str] = field(default_factory=list)
    kept_seeds: list[str] = field(default_factory=list)
    removed_types: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def list_presets(vault: Vault) -> list[dict[str, Any]]:
    """List all available fandom presets in Meta/Presets/.

    Args:
        vault: Story bible vault instance.

    Returns:
        List of manifest dictionaries for presets discovered on disk.
    """
    presets_dir = vault.root / "Meta" / "Presets"
    if not presets_dir.is_dir():
        return []

    manifests: list[dict[str, Any]] = []
    for manifest_path in presets_dir.glob("*/manifest.json"):
        text = read_text_or_none(manifest_path)
        if text:
            try:
                data = json.loads(text)
                if isinstance(data, dict):
                    data["_folder"] = manifest_path.parent.name
                    manifests.append(data)
            except Exception:
                continue
    return manifests


_CUSTOM_BLOCK = re.compile(r"^custom_types:[ \t]*(?:\[\])?[ \t]*\n((?:[ \t]+-[^\n]*\n?)*)", re.MULTILINE)


def get_active_custom_types(vault: Vault) -> list[str]:
    """Get the list of custom types currently defined in vault.yaml.

    Args:
        vault: Story bible vault instance.

    Returns:
        List of custom type identifiers defined in vault configuration.
    """
    cfg_path = vault.root / "vault.yaml"
    text = read_text_or_none(cfg_path)
    if text is None:
        return []
    text = text.replace("\r\n", "\n")
    match = _CUSTOM_BLOCK.search(text)
    if not match:
        return []
    return re.findall(r'-\s*"?([A-Za-z0-9_]+)"?', match.group(1))


def merge_custom_types(vault: Vault, types: list[str]) -> list[str]:
    """Append preset page types missing from vault.yaml `custom_types`.

    Args:
        vault: Story bible vault instance.
        types: List of custom type strings to ensure in vault configuration.

    Returns:
        List of new custom types appended to vault.yaml.
    """
    cfg_path = vault.root / "vault.yaml"
    text = read_text_or_none(cfg_path)
    if text is None or not types:
        return []
    text = text.replace("\r\n", "\n")
    match = _CUSTOM_BLOCK.search(text)
    present = set(re.findall(r'-\s*"?([A-Za-z0-9_]+)"?', match.group(1))) if match else set()
    missing = [t for t in types if t not in present]
    if not missing:
        return []
    lines = "".join(f'  - "{t}"\n' for t in missing)
    if match:
        body = match.group(1)
        if body and not body.endswith("\n"):
            body += "\n"
        text = text[: match.start()] + "custom_types:\n" + body + lines + text[match.end() :]
    else:
        block = "custom_types:\n" + lines + "\n"
        anchor = re.search(r"^locales:", text, re.MULTILINE)
        if anchor:
            text = text[: anchor.start()] + block + text[anchor.start() :]
        else:
            text = text.rstrip("\n") + "\n\n" + block
    write_text_atomic(cfg_path, text)
    return missing


def remove_custom_types(vault: Vault, types: list[str]) -> list[str]:
    """Remove specified custom types from vault.yaml if present.

    Args:
        vault: Story bible vault instance.
        types: List of custom types to prune.

    Returns:
        List of custom types successfully removed from configuration.
    """
    cfg_path = vault.root / "vault.yaml"
    text = read_text_or_none(cfg_path)
    if text is None or not types:
        return []
    text = text.replace("\r\n", "\n")
    match = _CUSTOM_BLOCK.search(text)
    if not match:
        return []

    types_set = set(types)
    removed: list[str] = []
    new_lines: list[str] = []
    for line in match.group(1).splitlines(keepends=True):
        m = re.search(r'-\s*"?([A-Za-z0-9_]+)"?', line)
        if m and m.group(1) in types_set:
            removed.append(m.group(1))
        else:
            new_lines.append(line)

    if not removed:
        return []

    new_body = "".join(new_lines)
    new_block = "custom_types:\n" + new_body
    text = text[: match.start()] + new_block + text[match.end() :]
    write_text_atomic(cfg_path, text)
    return removed


def get_types_in_use(vault: Vault) -> set[str]:
    """Scan all active markdown notes once and return all frontmatter types in use.

    Args:
        vault: Story bible vault instance.

    Returns:
        Set of type strings referenced in frontmatter of active notes.
    """
    active_types: set[str] = set()
    type_pattern = re.compile(r"^type:\s*[\"']?([A-Za-z0-9_]+)[\"']?\s*$", re.MULTILINE)

    for md_path in vault.root.rglob("*.md"):
        try:
            rel = md_path.relative_to(vault.root).as_posix()
        except ValueError:
            continue
        if rel.startswith("Meta/") or rel.startswith(".narr/"):
            continue
        content = read_text_or_none(md_path)
        if content:
            m = type_pattern.search(content)
            if m:
                active_types.add(m.group(1))

    return active_types


def is_type_in_use(vault: Vault, custom_type: str) -> bool:
    """Check if any markdown note in the vault (excluding Meta and .narr) uses this type.

    Args:
        vault: Story bible vault instance.
        custom_type: Identifier of the custom entity type.

    Returns:
        True if at least one active note references this type, False otherwise.
    """
    return custom_type in get_types_in_use(vault)


def _read_applied_presets(vault: Vault) -> dict[str, Any]:
    """Read and parse the .narr/applied_presets.json registry.

    Args:
        vault: Story bible vault instance.

    Returns:
        Dictionary mapping preset names to their applied metadata records.
    """
    applied_file = vault.root / ".narr" / "applied_presets.json"
    if not applied_file.is_file():
        return {}
    raw = read_text_or_none(applied_file)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _write_applied_presets(vault: Vault, data: dict[str, Any]) -> None:
    """Atomically persist the .narr/applied_presets.json registry.

    Args:
        vault: Story bible vault instance.
        data: Dictionary mapping preset names to metadata records.
    """
    applied_file = vault.root / ".narr" / "applied_presets.json"
    applied_file.parent.mkdir(parents=True, exist_ok=True)
    write_text_atomic(applied_file, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def list_applied_presets(vault: Vault) -> list[dict[str, Any]]:
    """List all presets that have been applied to this vault.

    Args:
        vault: Story bible vault instance.

    Returns:
        List of applied preset metadata records.
    """
    data = _read_applied_presets(vault)
    return list(data.values())


def get_preset_status(vault: Vault) -> dict[str, Any]:
    """Return applied presets, available unapplied presets, and active custom types.

    Args:
        vault: Story bible vault instance.

    Returns:
        Dictionary containing 'applied', 'available', and 'custom_types' entries.
    """
    applied = list_applied_presets(vault)
    applied_names = {p.get("name") for p in applied if isinstance(p, dict)}
    all_presets = list_presets(vault)
    available = [p for p in all_presets if p.get("_folder") not in applied_names and p.get("name") not in applied_names]
    custom_types = get_active_custom_types(vault)
    return {
        "applied": applied,
        "available": available,
        "custom_types": custom_types,
    }


def apply_preset(vault: Vault, name: str) -> str:
    """Apply fandom preset overlay safely without overwriting user data.

    Args:
        vault: Target narrative vault instance.
        name: Name of the fandom preset to apply.

    Returns:
        Success message describing seed pages copied and custom types merged.

    Raises:
        VaultError: If the preset or its manifest cannot be found on disk.
    """
    presets_dir = vault.root / "Meta" / "Presets"
    target_dir = presets_dir / name
    manifest_path = target_dir / "manifest.json"

    if not manifest_path.is_file():
        raise VaultError(f"Preset '{name}' not found at {manifest_path}")

    text = read_text_or_none(manifest_path)
    data = json.loads(text or "{}")
    title = data.get("display_name", name)
    version = data.get("version", "1.0")
    custom_types = [str(t) for t in data.get("custom_types", [])]

    # Copy seed pages if they don't exist
    seeds = data.get("seed_pages", [])
    copied = 0
    for seed_rel in seeds:
        src = target_dir / "seeds" / Path(seed_rel).name
        if not src.is_file():
            # Seeds are stored as "<name>.seed" so linters and the search index skip them until applied.
            src = src.with_name(src.name + ".seed")
        dst = vault.root / seed_rel
        if src.is_file() and not dst.exists():
            content = read_text_or_none(src)
            if content:
                write_text_atomic(dst, content)
                copied += 1

    added = merge_custom_types(vault, custom_types)
    note = f" Added custom_types: {', '.join(added)}." if added else ""

    # Record in .narr/applied_presets.json via helper
    applied_data = _read_applied_presets(vault)
    applied_data[name] = {
        "name": name,
        "display_name": title,
        "version": version,
        "applied_at": datetime.now(UTC).isoformat(),
        "custom_types": custom_types,
        "seed_pages": seeds,
    }
    _write_applied_presets(vault, applied_data)

    return f"Preset '{title}' applied successfully. ({copied} seed pages copied).{note}"


def rollback_preset(vault: Vault, name: str, force: bool = False) -> PresetRollbackReport:
    """Safely roll back an applied preset, preserving modified templates and in-use types.

    Args:
        vault: Story bible vault instance.
        name: Name of the applied preset to remove.
        force: If True, delete modified seed templates without preserving them.

    Returns:
        PresetRollbackReport detailing removed/preserved templates and types.

    Raises:
        VaultError: If the specified preset is not currently recorded as applied.
    """
    applied_data = _read_applied_presets(vault)

    if name not in applied_data:
        raise VaultError(f"Preset '{name}' is not currently applied to this vault.")

    preset_rec = applied_data[name]
    report = PresetRollbackReport(preset_name=name)

    # Check manifest or recorded seed pages
    presets_dir = vault.root / "Meta" / "Presets"
    target_dir = presets_dir / name
    manifest_path = target_dir / "manifest.json"
    manifest_data: dict[str, Any] = {}
    if manifest_path.is_file():
        try:
            m_raw = read_text_or_none(manifest_path)
            if m_raw:
                manifest_data = json.loads(m_raw)
        except Exception:
            manifest_data = {}

    seeds = preset_rec.get("seed_pages") or manifest_data.get("seed_pages", [])
    custom_types = preset_rec.get("custom_types") or manifest_data.get("custom_types", [])

    # Process seed files
    for seed_rel in seeds:
        dst = vault.root / seed_rel
        if not dst.is_file():
            continue

        src = target_dir / "seeds" / Path(seed_rel).name
        if not src.is_file():
            src = src.with_name(src.name + ".seed")

        src_text = read_text_or_none(src) if src.is_file() else None
        dst_text = read_text_or_none(dst)

        # Detect modification
        is_modified = False
        if src_text is None or (dst_text is not None and dst_text.strip() != src_text.strip()):
            is_modified = True

        if is_modified and not force:
            report.kept_seeds.append(seed_rel)
            report.warnings.append(f"Kept modified seed template: {seed_rel}")
        else:
            try:
                dst.unlink()
                report.removed_seeds.append(seed_rel)
            except OSError as err:
                report.warnings.append(f"Could not remove {seed_rel}: {err}")

    # Process custom types with single scan of active notes
    active_types = get_types_in_use(vault)
    types_to_remove: list[str] = []

    # Check if any other applied preset also defines this custom type
    other_applied_types: dict[str, list[str]] = {}
    for other_name, other_rec in applied_data.items():
        if other_name != name and isinstance(other_rec, dict):
            for t in other_rec.get("custom_types", []):
                other_applied_types.setdefault(str(t), []).append(other_name)

    for ctype in custom_types:
        ctype_str = str(ctype)
        if ctype_str in other_applied_types:
            sharing = ", ".join(other_applied_types[ctype_str])
            report.warnings.append(f"Custom type '{ctype_str}' is shared with active preset(s) ({sharing}); retained in vault.yaml.")
        elif ctype_str in active_types:
            report.warnings.append(f"Custom type '{ctype_str}' is in use by active notes; retained in vault.yaml.")
        else:
            types_to_remove.append(ctype_str)

    if types_to_remove:
        removed = remove_custom_types(vault, types_to_remove)
        report.removed_types.extend(removed)

    # Remove preset from applied_presets.json
    del applied_data[name]
    _write_applied_presets(vault, applied_data)

    return report

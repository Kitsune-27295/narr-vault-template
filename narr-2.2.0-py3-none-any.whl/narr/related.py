"""Related pages, inbound/outbound links, and shared context."""

from __future__ import annotations

from narr.pages import Page
from narr.vault import Vault


def get_related(vault: Vault, title: str) -> dict[str, list[str]]:
    """Get all inbound links, outbound links, and shared tag connections for a page.

    Args:
        vault: Story bible vault instance.
        title: Title, UID, or filename stem of target note.

    Returns:
        Dictionary with sorted lists of 'inbound', 'outbound', and 'shared_tags' relative paths.
    """
    inbound: list[str] = []
    outbound: list[str] = []
    shared_tags: list[str] = []

    target_page: Page | None = None
    all_pages: list[Page] = []

    for rel_path, entry in vault.entries(".md"):
        p = Page.load(vault.root / rel_path, rel_path)
        if p:
            all_pages.append(p)
            stem = entry.name.split(".", 1)[0]
            if stem == title or p.title == title or p.uid == title:
                target_page = p

    if not target_page:
        return {"inbound": [], "outbound": [], "shared_tags": []}

    target_stem = target_page.path.stem
    target_tags = set(target_page.tags)

    outbound = [l for l in target_page.links]

    for p in all_pages:
        if p.path == target_page.path:
            continue
        # Inbound check
        for l in p.links:
            clean = l.split("|", 1)[0].split("#", 1)[0].strip()
            if clean in (target_stem, target_page.title, target_page.uid):
                inbound.append(p.rel_path)
        # Shared tags
        if target_tags and target_tags.intersection(p.tags):
            shared_tags.append(p.rel_path)

    return {
        "inbound": sorted(set(inbound)),
        "outbound": sorted(set(outbound)),
        "shared_tags": sorted(set(shared_tags))[:10],
    }

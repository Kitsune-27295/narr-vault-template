"""Decision records (ADRs) management for narrative architecture and continuity (ADR-004 & Second_brain parity)."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from narr.frontmatter import parse
from narr.vault import Vault, VaultError, read_text, slugify, write_text_atomic


def create_decision(
    vault: Vault,
    title: str,
    context: str = "",
    consequences: str = "",
    alternatives: str = "",
) -> Path:
    """Create a new decision record in memory/decisions/DEC-<slug>.md with status proposed."""
    slug = slugify(title)
    decisions_dir = vault.root / "memory" / "decisions"
    decisions_dir.mkdir(parents=True, exist_ok=True)

    uid = f"DEC-{slug}"
    dest = decisions_dir / f"{uid}.md"
    if dest.exists():
        raise VaultError(f"Decision {uid} already exists at {vault.rel(dest)}")

    today = datetime.now().strftime("%Y-%m-%d")
    body = f"""---
uid: "{uid}"
type: decision
title: "{title}"
status: proposed
updated: {today}
scope: meta
tags: ["memory/decision"]
---
# {uid}: {title}

## Contexto e Motivação
{context.strip() if context else "[PENDING VALIDATION: O que forçou esta escolha ou problema a ser resolvido]"}

## Decisão Tomada
Uma sentença declarativa e objetiva sobre a escolha efetuada.

## Consequências Narrativas e Técnicas
- **O que fica mais fácil**: [Ganhos de clareza, alinhamento ou consistência]
- **O que fica mais difícil**: [Trade-offs, restrições adicionadas]
- **O que agora é imutável**: [Fatos e convenções fixadas]

## Alternativas Consideradas e Rejeitadas
- **Alternativa A**: [Por que foi descartada]
- **Alternativa B**: [Por que foi descartada]
"""
    write_text_atomic(dest, body)
    return dest


def supersede_decision(vault: Vault, old_id: str, new_id: str) -> None:
    """Mark an old decision as superseded by a newer one."""
    decisions_dir = vault.root / "memory" / "decisions"
    clean_old = old_id.strip("[]")
    old_file = decisions_dir / f"{clean_old}.md"
    if not old_file.is_file():
        raise VaultError(f"Decision file {clean_old}.md not found in memory/decisions/")

    text = read_text(old_file)
    doc = parse(text)
    doc.meta["status"] = "superseded"
    doc.meta["superseded_by"] = f"[[{new_id.strip('[]')}]]"
    doc.meta["updated"] = datetime.now().strftime("%Y-%m-%d")

    import yaml

    new_fm = yaml.safe_dump(doc.meta, sort_keys=False, allow_unicode=True).strip()
    new_content = f"---\n{new_fm}\n---\n{doc.body}"
    write_text_atomic(old_file, new_content)

"""Decision records (ADRs) management for narrative architecture and continuity (ADR-004 & Second_brain parity)."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from narr.frontmatter import Doc, dump, parse
from narr.vault import Vault, VaultError, read_text, slugify, write_text_atomic


def _normalize_key(key: str) -> str:
    """Normalize decision identifier for resilient case- and delimiter-insensitive lookup."""
    cleaned = key.strip("[]").removesuffix(".md").strip()
    if cleaned.upper().startswith("DEC-"):
        cleaned = cleaned[4:]
    return re.sub(r"[-_\s]+", "_", cleaned).lower()


def resolve_decision_file(vault: Vault, decision_id: str) -> Path:
    """Resolve an existing decision file by ID, slug, or wikilink; raise VaultError if not found."""
    decisions_dir = vault.root / "memory" / "decisions"
    if not decisions_dir.is_dir():
        raise VaultError(f"Decision directory does not exist in {vault.name}")
    norm_id = _normalize_key(decision_id)
    for f in sorted(decisions_dir.glob("*.md")):
        if _normalize_key(f.stem) == norm_id:
            return f
    raise VaultError(f"Decision '{decision_id}' not found in memory/decisions/")


def create_decision(
    vault: Vault,
    title: str,
    context: str = "",
    consequences: str = "",
    alternatives: str = "",
) -> Path:
    """Create a new decision record in memory/decisions/DEC-<slug>.md with status proposed."""
    slug = slugify(title)
    decisions_dir = vault.root / "memory" / "decisions"
    decisions_dir.mkdir(parents=True, exist_ok=True)

    uid = f"DEC-{slug}"
    dest = decisions_dir / f"{uid}.md"
    if dest.exists():
        raise VaultError(f"Decision {uid} already exists at {vault.rel(dest)}")

    today = datetime.now().strftime("%Y-%m-%d")
    meta = {
        "uid": uid,
        "type": "decision",
        "title": title,
        "status": "proposed",
        "updated": today,
        "scope": "meta",
        "tags": ["memory/decision"],
    }

    body = f"""# {uid}: {title}

## Contexto e Motivação
{context.strip() if context else "[PENDING VALIDATION: O que forçou esta escolha ou problema a ser resolvido]"}

## Decisão Tomada
Uma sentença declarativa e objetiva sobre a escolha efetuada.

## Consequências Narrativas e Técnicas
- **O que fica mais fácil**: [Ganhos de clareza, alinhamento ou consistência]
- **O que fica mais difícil**: [Trade-offs, restrições adicionadas]
- **O que agora é imutável**: [Fatos e convenções fixadas]

## Alternativas Consideradas e Rejeitadas
- **Alternativa A**: [Por que foi descartada]
- **Alternativa B**: [Por que foi descartada]
"""

    doc = Doc(meta=meta, body=body)
    write_text_atomic(dest, dump(doc))
    return dest


def supersede_decision(vault: Vault, old_id: str, new_id: str) -> None:
    """Mark an old decision as superseded by a newer one."""
    old_file = resolve_decision_file(vault, old_id)

    decisions_dir = vault.root / "memory" / "decisions"
    norm_new = _normalize_key(new_id)
    target_stem = None
    for f in sorted(decisions_dir.glob("*.md")):
        if _normalize_key(f.stem) == norm_new:
            target_stem = f.stem
            break

    if target_stem is None:
        clean_new = new_id.strip("[]").removesuffix(".md").strip()
        if not clean_new.upper().startswith("DEC-"):
            clean_new = f"DEC-{slugify(clean_new)}"
        target_stem = clean_new

    text = read_text(old_file)
    doc = parse(text)
    doc.meta["status"] = "superseded"
    doc.meta["superseded_by"] = f"[[{target_stem}]]"
    doc.meta["updated"] = datetime.now().strftime("%Y-%m-%d")

    write_text_atomic(old_file, dump(doc))

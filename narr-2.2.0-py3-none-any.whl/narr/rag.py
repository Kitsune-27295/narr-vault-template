"""Fiction-Conscious RAG (F-RAG) context assembler for chapter drafting (ADR-004 & Second_brain parity)."""

from __future__ import annotations

import logging
import re

from narr.frontmatter import parse
from narr.search import search
from narr.vault import Vault, read_text_or_none

logger = logging.getLogger(__name__)


def extract_baseline_constraints(baseline_text: str) -> str:
    """Extract mechanics, rigid rules, and negative boundaries from a consolidated canon baseline.

    Args:
        baseline_text: Full markdown text of a canon baseline page.

    Returns:
        Formatted string containing extracted constraint and boundary sections.
    """
    sections: list[str] = []
    lines = baseline_text.splitlines()
    capturing = False
    current_block: list[str] = []

    target_keywords = (
        "capacidades",
        "mecanicas",
        "mecânicas",
        "regras rigidas",
        "regras rígidas",
        "nao estabelece",
        "não estabelece",
        "fronteiras negativas",
        "negative boundary",
    )

    for line in lines:
        if line.startswith("## "):
            h = line.strip().lower()
            if any(term in h for term in target_keywords):
                if capturing and current_block:
                    sections.append("\n".join(current_block))
                capturing = True
                current_block = [line.strip()]
            else:
                if capturing and current_block:
                    sections.append("\n".join(current_block))
                capturing = False
                current_block = []
        elif capturing:
            current_block.append(line)

    if capturing and current_block:
        sections.append("\n".join(current_block))

    return "\n\n".join(sections)


def assemble_chapter_context(
    vault: Vault,
    chapter_num: int,
    character_focus: str | None = None,
    budget_tokens: int = 3500,
) -> str:
    """Deterministic context assembler for serialized fiction writing with Canon Baseline fallback.

    Args:
        vault: Story bible vault instance.
        chapter_num: Numerical chapter sequence indicator.
        character_focus: Optional character or entity focus name to retrieve context for.
        budget_tokens: Context budget limit in tokens (default: 3500).

    Returns:
        Markdown context block assembled from active ledgers, tone bible, and lore entities.
    """
    sections: list[str] = [
        f"# Fiction Context Assembler - Chapter {chapter_num:02d}",
        "> [!IMPORTANT]\n> Adhere strictly to character knowledge horizons, Chekhov promises, and power limitations.",
    ]

    # 1. Active Ledgers
    active_threads = vault.root / "08_Ledgers" / "LDG-Active_Threads.md"
    if active_threads.is_file():
        text = read_text_or_none(active_threads)
        if text:
            sections.append(f"## Active Plot Threads\n{text.strip()}")

    chekhov_guns = vault.root / "08_Ledgers" / "LDG-Chekhov_Guns.md"
    if chekhov_guns.is_file():
        text = read_text_or_none(chekhov_guns)
        if text:
            sections.append(f"## Active Chekhov Weapons & Items\n{text.strip()}")

    knowledge_ledger = vault.root / "08_Ledgers" / "LDG-Character_Knowledge.md"
    if knowledge_ledger.is_file():
        text = read_text_or_none(knowledge_ledger)
        if text:
            sections.append(f"## Character Epistemic Horizons\n{text.strip()}")

    # 2. Tone and Identity Boundaries
    tone_bible = vault.root / "02_Story_Bible" / "Cosmology_and_Godhood" / "SCP-Tone_and_Identity_Bible.md"
    if tone_bible.is_file():
        text = read_text_or_none(tone_bible)
        if text:
            sections.append(f"## Atmospheric & Negative Boundaries\n{text.strip()[:1500]}")

    # 3. Lore Entities with Canon Baseline Ground Truth Fallback
    if character_focus:
        hits = search(vault, query=character_focus, limit=3, zone="02_Story_Bible")
        for hit in hits:
            p_path = vault.root / hit.rel_path
            p_text = read_text_or_none(p_path)
            if p_text:
                sections.append(f"## Story Bible Reference: {hit.title}\n{p_text[:2000]}")
                # Check for linked baseline
                try:
                    doc = parse(p_text)
                    baseline_ref = doc.meta.get("baseline")
                    if isinstance(baseline_ref, str):
                        m = re.search(r"\[\[(CAN-[^\]|#]+)", baseline_ref)
                        base_stem = m.group(1) if m else baseline_ref.strip()
                        base_file = vault.baselines_dir / f"{base_stem}.md"
                        if base_file.is_file():
                            b_text = read_text_or_none(base_file)
                            if b_text:
                                constraints = extract_baseline_constraints(b_text)
                                if constraints:
                                    canon_ref = base_stem if base_stem.startswith("CAN-") else f"CAN-{base_stem}"
                                    sections.append(f"## Ground Truth Canon Constraints ([[{canon_ref}]])\n{constraints}")
                except (OSError, ValueError) as exc:
                    logger.debug("Failed to extract baseline constraints for %s: %s", hit.rel_path, exc)

    combined = "\n\n---\n\n".join(sections)
    return combined

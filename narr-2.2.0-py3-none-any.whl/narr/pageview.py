"""Compact page metadata inspector (Second_brain parity / ADR-038).

Allows an agent to inspect a narrative entity's role, links, sources, and lint health
in <100 tokens before opening a full markdown body.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from narr.checks import run_all_checks
from narr.pages import Page
from narr.vault import Vault


def find_page(vault: Vault, query: str) -> tuple[Page, str] | None:
    """Find a page by relative path, stem, title, or UID."""
    q_clean = query.strip().lower()

    # 1. Exact relative path or stem
    for rel_path, entry in vault.entries(".md"):
        p_stem = Path(rel_path).stem.lower()
        if rel_path.lower() == q_clean or p_stem == q_clean:
            p = Page.load(vault.root / rel_path, rel_path)
            if p:
                return p, rel_path

    # 2. Match by title or UID in frontmatter
    for rel_path, entry in vault.entries(".md"):
        p = Page.load(vault.root / rel_path, rel_path)
        if p:
            if p.title and p.title.lower() == q_clean:
                return p, rel_path
            if p.uid and p.uid.lower() == q_clean:
                return p, rel_path

    return None


def get_page_view(vault: Vault, name: str) -> dict[str, Any] | None:
    """Build compact page view dictionary."""
    result = find_page(vault, name)
    if not result:
        return None
    page, rel_path = result

    # 1. Scan links across the vault
    all_pages: list[tuple[Page, str]] = []
    for r_path, _ in vault.entries(".md"):
        p = Page.load(vault.root / r_path, r_path)
        if p:
            all_pages.append((p, r_path))

    page_stem = Path(rel_path).stem
    inbound_sources: list[str] = []

    valid_targets = {page_stem.lower()}
    if page.title:
        valid_targets.add(page.title.lower())
    if page.uid:
        valid_targets.add(page.uid.lower())

    for other_p, other_rel in all_pages:
        if other_rel == rel_path:
            continue
        for l in other_p.links:
            clean_l = l.split("|", 1)[0].split("#", 1)[0].strip().lower()
            if clean_l in valid_targets:
                inbound_sources.append(other_rel)
                break

    outbound_links = list(page.links)
    inbound_count = len(inbound_sources)
    outbound_count = len(outbound_links)

    # 2. Determine role
    if inbound_count == 0:
        role = "orphan"
    elif inbound_count >= 5:
        role = "hub"
    elif outbound_count > 0:
        role = "connector"
    else:
        role = "leaf"

    # 3. Sources cited
    sources: list[str] = []
    meta = page.doc.meta or {}
    if "sources" in meta and isinstance(meta["sources"], list):
        sources = [str(s) for s in meta["sources"]]
    elif "source_ids" in meta and isinstance(meta["source_ids"], list):
        sources = [str(s) for s in meta["source_ids"]]

    # 4. Lint status for this page
    findings = [f for f in run_all_checks(vault) if f.path == rel_path]
    errors = [f.message for f in findings if f.severity == "error"]
    warnings = [f.message for f in findings if f.severity == "warning"]

    return {
        "path": rel_path,
        "stem": page_stem,
        "title": page.title or page_stem,
        "uid": page.uid or "",
        "type": page.page_type or "untyped",
        "status": meta.get("status", "active"),
        "scope": meta.get("scope", ""),
        "role": role,
        "inbound_count": inbound_count,
        "inbound_sample": inbound_sources[:5],
        "outbound_count": outbound_count,
        "outbound_sample": outbound_links[:5],
        "sources": sources,
        "lint_errors": errors,
        "lint_warnings": warnings,
    }


def format_page_view(info: dict[str, Any]) -> str:
    """Format page view dictionary as a clean CLI summary."""
    lines = [
        f"=== PAGE: {info['title']} ({info['path']}) ===",
        f"UID: {info['uid'] or '(none)'} | Type: {info['type']} | Role: {info['role']} | Status: {info['status']}",
        f"Inbound Links: {info['inbound_count']} -> {', '.join(info['inbound_sample']) if info['inbound_sample'] else '(none)'}",
        f"Outbound Links: {info['outbound_count']} -> {', '.join(info['outbound_sample']) if info['outbound_sample'] else '(none)'}",
    ]
    if info["sources"]:
        lines.append(f"Sources Cited: {', '.join(info['sources'])}")
    if info["lint_errors"]:
        lines.append(f"Lint Errors: {len(info['lint_errors'])}")
        for err in info["lint_errors"]:
            lines.append(f"  - [ERR] {err}")
    elif info["lint_warnings"]:
        lines.append(f"Lint Warnings: {len(info['lint_warnings'])}")
        for warn in info["lint_warnings"]:
            lines.append(f"  - [WARN] {warn}")
    else:
        lines.append("Lint: [OK] 100% compliant")

    return "\n".join(lines)

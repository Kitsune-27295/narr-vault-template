"""Session close protocol and handoff archival."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from narr.frontmatter import Doc, dump, parse
from narr.vault import Vault, read_text_or_none, write_text_atomic

DEFAULT_HANDOFF_META: dict[str, Any] = {
    "uid": "LDG-Session_Handoff",
    "type": "ledger",
    "title": "Session Handoff & Ledger State",
    "status": "active",
    "scope": "meta",
    "tags": ["ledger/handoff"],
}

DEFAULT_ARCHIVE_META: dict[str, Any] = {
    "uid": "LDG-Session_Handoff-full",
    "type": "ledger",
    "title": "Session Handoff Archive",
    "status": "active",
    "scope": "meta",
    "tags": ["ledger/handoff", "ledger/archive"],
}


def session_close(
    vault: Vault,
    done: str,
    next_action: str,
    decided: str,
    questions: str | None = None,
) -> str:
    """Close active session, update handoff ledger with preserved frontmatter, and append to archive."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    entry = f"## Session Handoff – {now_str}\n\n- **Done:** {done}\n- **Next:** {next_action}\n- **Decided:** {decided}\n"
    if questions:
        entry += f"- **Open Questions:** {questions}\n"

    # 1. Update active handoff ledger, preserving existing frontmatter
    active_path = vault.root / "08_Ledgers" / "LDG-Session_Handoff.md"
    existing_active = read_text_or_none(active_path)
    if existing_active:
        doc = parse(existing_active)
        meta = doc.meta if doc.meta else DEFAULT_HANDOFF_META.copy()
    else:
        meta = DEFAULT_HANDOFF_META.copy()

    active_body = f"# LDG-Session_Handoff – Active Session Handoff\n\n{entry.strip()}\n"
    active_doc = Doc(meta=meta, body=active_body)
    write_text_atomic(active_path, dump(active_doc))

    # 2. Append to full archive with canonical frontmatter
    archive_path = vault.root / "08_Ledgers" / "archive" / "LDG-Session_Handoff-full.md"
    existing_archive = read_text_or_none(archive_path)
    if existing_archive:
        archive_doc = parse(existing_archive)
        if not archive_doc.meta:
            archive_doc.meta = DEFAULT_ARCHIVE_META.copy()
        archive_doc.body = archive_doc.body.rstrip() + "\n\n" + entry.strip() + "\n"
    else:
        archive_doc = Doc(
            meta=DEFAULT_ARCHIVE_META.copy(),
            body=f"# LDG-Session_Handoff-full – Session Handoff Archive\n\n{entry.strip()}\n",
        )
    write_text_atomic(archive_path, dump(archive_doc))

    # 3. Trim hot.md
    hot_path = vault.root / "memory" / "hot.md"
    hot_content = f"""# Working Memory (hot.md)

## Current Objective
{next_action}

## Last Updated
{now_str}
"""
    write_text_atomic(hot_path, hot_content)

    return f"Session closed successfully. Active handoff and hot.md updated ({now_str})."

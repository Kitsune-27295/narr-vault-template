"""Session close protocol and handoff archival."""

from __future__ import annotations

from datetime import datetime

from narr.vault import Vault, read_text_or_none, write_text_atomic


def session_close(
    vault: Vault,
    done: str,
    next_action: str,
    decided: str,
    questions: str | None = None,
) -> str:
    """Close active session, update handoff ledger, and append to archive."""
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    entry = f"""## Session Handoff — {now_str}

- **Done:** {done}
- **Next:** {next_action}
- **Decided:** {decided}
"""
    if questions:
        entry += f"- **Open Questions:** {questions}\n"

    # 1. Update active handoff ledger
    active_path = vault.root / "08_Ledgers" / "LDG-Session_Handoff.md"
    write_text_atomic(active_path, entry)

    # 2. Append to full archive
    archive_path = vault.root / "08_Ledgers" / "archive" / "LDG-Session_Handoff-full.md"
    old_archive = read_text_or_none(archive_path) or "# Session Handoff Archive\n\n"
    write_text_atomic(archive_path, old_archive.rstrip() + "\n\n" + entry)

    # 3. Trim hot.md
    hot_path = vault.root / "memory" / "hot.md"
    hot_content = f"""# Working Memory (hot.md)

## Current Objective
{next_action}

## Last Updated
{now_str}
"""
    write_text_atomic(hot_path, hot_content)

    return f"Session closed successfully. Active handoff and hot.md updated ({now_str})."

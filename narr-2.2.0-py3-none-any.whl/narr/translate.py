"""Translation parity and Termbase localization verification (MSC004 & V1 sanitization)."""

from __future__ import annotations

from dataclasses import dataclass

from narr.vault import Vault, VaultError, read_text


@dataclass
class ParityReport:
    chapter_num: int
    pt_path: str
    es_path: str
    pt_paragraphs: int
    es_paragraphs: int
    diff: int
    tolerance: int
    passed: bool
    missing_termbase_terms: list[str]


def _strip_paragraphs(text: str) -> list[str]:
    clean = text
    if clean.startswith("---"):
        parts = clean.split("---", 2)
        if len(parts) >= 3:
            clean = parts[2]
    paras: list[str] = []
    for p in clean.split("\n\n"):
        p_str = p.strip()
        if not p_str or p_str.startswith("# "):
            continue
        paras.append(p_str)
    return paras


def check_translation_parity(vault: Vault, chapter_num: int) -> ParityReport:
    """Validate paragraph parity and termbase localization between pt-BR draft and es publication."""
    pt_dir = vault.root / "04_Manuscript" / "pt-BR" / "Chapters"
    es_dir = vault.root / "04_Manuscript" / "es" / "Chapters"

    pt_files = list(pt_dir.glob(f"C{chapter_num:02d}[_-]*.md")) or list(pt_dir.glob(f"C{chapter_num}[_-]*.md"))
    if not pt_files:
        raise VaultError(f"No pt-BR chapter draft found for chapter {chapter_num} in {vault.rel(pt_dir)}")

    es_files = list(es_dir.glob(f"C{chapter_num:02d}[_-]*.md")) or list(es_dir.glob(f"C{chapter_num}[_-]*.md"))
    if not es_files:
        raise VaultError(f"No es publication chapter found for chapter {chapter_num} in {vault.rel(es_dir)}")

    pt_file = pt_files[0]
    es_file = es_files[0]

    pt_text = read_text(pt_file)
    es_text = read_text(es_file)

    pt_paras = _strip_paragraphs(pt_text)
    es_paras = _strip_paragraphs(es_text)

    diff = abs(len(pt_paras) - len(es_paras))
    tolerance = max(8, int(0.10 * len(pt_paras)))
    passed = diff <= tolerance

    # Termbase check (stub)
    missing_terms: list[str] = []

    return ParityReport(
        chapter_num=chapter_num,
        pt_path=vault.rel(pt_file),
        es_path=vault.rel(es_file),
        pt_paragraphs=len(pt_paras),
        es_paragraphs=len(es_paras),
        diff=diff,
        tolerance=tolerance,
        passed=passed,
        missing_termbase_terms=missing_terms,
    )

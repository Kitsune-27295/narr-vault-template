"""Translation parity and Termbase localization verification (MSC004 & V1 sanitization)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from narr.vault import Vault, VaultError, read_text, read_text_or_none


@dataclass
class TermMapping:
    """Represents a localized terminology mapping between pt-BR and es."""

    source_pt: str
    target_es: str
    category: str = "general"
    notes: str = ""


@dataclass
class TermbaseValidationReport:
    """Report detailing missing translations or leaked source terms."""

    is_valid: bool
    missing_terms: list[str] = field(default_factory=list)
    leaked_terms: list[str] = field(default_factory=list)
    matched_terms: list[tuple[str, str]] = field(default_factory=list)


@dataclass
class ParityReport:
    """Report evaluating translation paragraph parity and termbase integrity."""

    chapter_num: int
    pt_path: str
    es_path: str
    pt_paragraphs: int
    es_paragraphs: int
    diff: int
    tolerance: int
    passed: bool
    missing_termbase_terms: list[str] = field(default_factory=list)
    leaked_source_terms: list[str] = field(default_factory=list)
    marker_mode: bool = False
    diagnostics: list[str] = field(default_factory=list)


def parse_termbase(vault: Vault) -> list[TermMapping]:
    """Parse all terminology tables in TRM-Termbase.md into bidirectional mappings."""
    termbase_file = vault.root / "02_Story_Bible" / "Terminology" / "TRM-Termbase.md"
    if not termbase_file.is_file():
        return []

    content = read_text_or_none(termbase_file)
    if not content:
        return []

    mappings: list[TermMapping] = []
    current_category = "general"

    lines = content.splitlines()
    in_table = False
    pt_idx = -1
    es_idx = -1
    notes_idx = -1

    for line in lines:
        s_line = line.strip()
        if s_line.startswith("#"):
            current_category = s_line.lstrip("#").strip().lower()
            in_table = False
            continue

        if s_line.startswith("|") and s_line.endswith("|"):
            cells = [c.strip() for c in s_line.split("|")[1:-1]]
            if not cells:
                continue

            # Check if this is a header row
            lower_cells = [c.lower() for c in cells]
            is_header = any(re.search(r"pt[-_]?br|portugu[eê]s", c) or re.search(r"\bes\b|spanish|español", c) for c in lower_cells)

            if is_header:
                pt_idx = -1
                es_idx = -1
                notes_idx = -1
                for idx, col in enumerate(lower_cells):
                    if re.search(r"pt[-_]?br|portugu[eê]s", col):
                        pt_idx = idx
                    elif re.search(r"\bes\b|spanish|español", col):
                        es_idx = idx
                    elif re.search(r"rule|context|notes?|register|benchmark|system", col):
                        notes_idx = idx
                in_table = pt_idx >= 0 and es_idx >= 0
                continue

            # Separator line |---|---|
            if in_table and all(set(c).issubset({"-", ":", " "}) for c in cells):
                continue

            if in_table and pt_idx < len(cells) and es_idx < len(cells):
                raw_pt = cells[pt_idx]
                raw_es = cells[es_idx]
                raw_notes = cells[notes_idx] if (notes_idx >= 0 and notes_idx < len(cells)) else ""

                # Strip markdown links and brackets
                clean_pt = re.sub(r"\[\[.*?\|(.*?)\]\]", r"\1", raw_pt)
                clean_pt = re.sub(r"\[\[(.*?)\]\]", r"\1", clean_pt).strip()
                clean_es = re.sub(r"\[\[.*?\|(.*?)\]\]", r"\1", raw_es)
                clean_es = re.sub(r"\[\[(.*?)\]\]", r"\1", clean_es).strip()

                if clean_pt and clean_es and clean_pt != "-" and clean_es != "-":
                    mappings.append(
                        TermMapping(
                            source_pt=clean_pt,
                            target_es=clean_es,
                            category=current_category,
                            notes=raw_notes,
                        )
                    )
        else:
            in_table = False

    return mappings


def validate_termbase_consistency(
    pt_text: str,
    es_text: str,
    mappings: list[TermMapping],
) -> TermbaseValidationReport:
    """Validate that terms in the pt-BR draft are correctly translated to es with zero source leaks."""
    missing_terms: list[str] = []
    leaked_terms: list[str] = []
    matched_terms: list[tuple[str, str]] = []

    for m in mappings:
        # Check if source term appears in Portuguese draft
        pt_pattern = rf"(?<!\w){re.escape(m.source_pt)}(?!\w)"
        if re.search(pt_pattern, pt_text, re.IGNORECASE):
            # Target Spanish term must exist in Spanish text
            es_pattern = rf"(?<!\w){re.escape(m.target_es)}(?!\w)"
            if not re.search(es_pattern, es_text, re.IGNORECASE):
                missing_terms.append(f"Missing official Spanish term '{m.target_es}' for '{m.source_pt}'")
            else:
                matched_terms.append((m.source_pt, m.target_es))

            # Source term must not leak into Spanish publication (unless identical)
            if m.source_pt.lower() != m.target_es.lower():
                if re.search(pt_pattern, es_text, re.IGNORECASE):
                    leaked_terms.append(f"Untranslated Portuguese term '{m.source_pt}' leaked into Spanish publication")

    is_valid = len(missing_terms) == 0 and len(leaked_terms) == 0
    return TermbaseValidationReport(
        is_valid=is_valid,
        missing_terms=missing_terms,
        leaked_terms=leaked_terms,
        matched_terms=matched_terms,
    )


def extract_paragraph_markers(text: str) -> dict[int, str]:
    """Extract all <!-- p:N --> markers and their associated paragraph text."""
    pattern = re.compile(r"<!--\s*p:(\d+)\s*-->", re.IGNORECASE)
    matches = list(pattern.finditer(text))
    if not matches:
        return {}

    markers: dict[int, str] = {}
    for i, m in enumerate(matches):
        p_num = int(m.group(1))
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        para_text = text[start:end].strip()
        markers[p_num] = para_text
    return markers


def _strip_paragraphs(text: str) -> list[str]:
    """Strip frontmatter and extract non-empty paragraph blocks."""
    clean = text
    if clean.startswith("---"):
        parts = clean.split("---", 2)
        if len(parts) >= 3:
            clean = parts[2]
    paras: list[str] = []
    for p in clean.split("\n\n"):
        p_str = p.strip()
        if not p_str or p_str.startswith("# "):
            continue
        paras.append(p_str)
    return paras


def check_translation_parity(vault: Vault, chapter_num: int) -> ParityReport:
    """Validate paragraph parity and termbase localization between pt-BR draft and es publication."""
    pt_dir = vault.root / "04_Manuscript" / "pt-BR" / "Chapters"
    es_dir = vault.root / "04_Manuscript" / "es" / "Chapters"

    pt_files = list(pt_dir.glob(f"C{chapter_num:02d}[_-]*.md")) or list(pt_dir.glob(f"C{chapter_num}[_-]*.md"))
    if not pt_files:
        raise VaultError(f"No pt-BR chapter draft found for chapter {chapter_num} in {vault.rel(pt_dir)}")

    es_files = list(es_dir.glob(f"C{chapter_num:02d}[_-]*.md")) or list(es_dir.glob(f"C{chapter_num}[_-]*.md"))
    if not es_files:
        raise VaultError(f"No es publication chapter found for chapter {chapter_num} in {vault.rel(es_dir)}")

    pt_file = pt_files[0]
    es_file = es_files[0]

    pt_text = read_text(pt_file)
    es_text = read_text(es_file)

    pt_markers = extract_paragraph_markers(pt_text)
    es_markers = extract_paragraph_markers(es_text)

    diagnostics: list[str] = []
    passed = True

    if pt_markers and es_markers:
        marker_mode = True
        pt_paragraphs = len(pt_markers)
        es_paragraphs = len(es_markers)
        diff = abs(pt_paragraphs - es_paragraphs)
        tolerance = 0  # Marker mode requires exact 1:1 match

        pt_keys = set(pt_markers.keys())
        es_keys = set(es_markers.keys())

        missing_in_es = pt_keys - es_keys
        extra_in_es = es_keys - pt_keys

        for m in sorted(missing_in_es):
            diagnostics.append(f"Missing paragraph marker <!-- p:{m} --> in Spanish publication.")
            passed = False

        for m in sorted(extra_in_es):
            diagnostics.append(f"Extra paragraph marker <!-- p:{m} --> in Spanish publication not in pt-BR.")
            passed = False

        # Check for empty paragraphs
        for k, text in es_markers.items():
            if not text.strip():
                diagnostics.append(f"Paragraph <!-- p:{k} --> in Spanish publication is empty.")
                passed = False
    else:
        marker_mode = False
        pt_paras = _strip_paragraphs(pt_text)
        es_paras = _strip_paragraphs(es_text)
        pt_paragraphs = len(pt_paras)
        es_paragraphs = len(es_paras)
        diff = abs(pt_paragraphs - es_paragraphs)
        tolerance = max(8, int(0.10 * len(pt_paras)))
        passed = diff <= tolerance
        diagnostics.append(f"Fallback heuristic used: {es_paragraphs} es blocks vs {pt_paragraphs} pt-BR blocks (tolerance: {tolerance}).")
        if not passed:
            diagnostics.append(f"Paragraph divergence exceeds tolerance {tolerance} (diff: {diff}).")

    # Validate termbase
    term_mappings = parse_termbase(vault)
    tb_report = validate_termbase_consistency(pt_text, es_text, term_mappings)

    if not tb_report.is_valid:
        passed = False
        for missing_term in tb_report.missing_terms:
            diagnostics.append(f"Termbase violation: {missing_term}")
        for leaked_term in tb_report.leaked_terms:
            diagnostics.append(f"Termbase leak: {leaked_term}")

    return ParityReport(
        chapter_num=chapter_num,
        pt_path=vault.rel(pt_file),
        es_path=vault.rel(es_file),
        pt_paragraphs=pt_paragraphs,
        es_paragraphs=es_paragraphs,
        diff=diff,
        tolerance=tolerance,
        passed=passed,
        missing_termbase_terms=tb_report.missing_terms,
        leaked_source_terms=tb_report.leaked_terms,
        marker_mode=marker_mode,
        diagnostics=diagnostics,
    )

"""Blueprint scaffolding for typed narrative pages (narr new <type> <title>)."""

from __future__ import annotations

import re
from datetime import date
from pathlib import Path

from narr.vault import Vault, VaultError, slugify, write_text_atomic

BLUEPRINTS = {
    "character": (
        "02_Story_Bible/Characters",
        "CHR-",
        """---
uid: "{uid}"
type: character
title: "{title}"
aliases: []
status: active
gender: unknown
age: 0
birth_year: 0
primary_faction: "[[ORG-Pending]]"
power_system: "[[SYS-Pending]]"
tier_rank: "Pending"
scope: fanfic_canon
created: {today}
updated: {today}
tags:
  - character/active
---
# {title}

> [!NOTE]
> Executive summary: 2-3 lines detailing narrative role, archetypal want/need, and core relationship.

## Settei & Visual HUD (Visual-First)
- **Combat Silhouette:** [PENDING VALIDATION: distinctive outline and weapon profile]
- **Comparative Height:** [PENDING VALIDATION: height in cm and scale relative to peers]
- **Color Palette:** Primary (#000000), Secondary (#FFFFFF), Accent (#FF0000)
- **Everyday Attire:** [PENDING VALIDATION]
- **Key Facial Expressions:** [PENDING VALIDATION]

## Voice & Mannerisms
- **Catchphrase / Verbal Tic:** [PENDING VALIDATION]
- **Formality Register:** [PENDING VALIDATION]
- **Stress Reaction:** [PENDING VALIDATION]

## RPG Status Sheet & Attributes
| Attribute | Score / Tier | Notes |
|---|---|---|
| Physical Strength | Rank C | Base baseline |
| Energy Capacity | Level 1 | Base tier |
| Agility / Speed | Rank C | Base baseline |
| Tactical Intellect | Adept | Base baseline |

## Powers & Manifestations
- **Primary Domain:** [[PWR-Pending]]
- **Techniques Known:**
  - [[TEC-Pending]]

## Knowledge State & Epistemic Horizon
- **Secret Known:** [PENDING VALIDATION]
- **Critical Blindspot:** [PENDING VALIDATION]

## Timeline of Events
- **Year 00:** Origin event.
""",
    ),
    "power_system": (
        "02_Story_Bible/Powers_and_Systems",
        "SYS-",
        """---
uid: "{uid}"
type: power_system
title: "{title}"
description: "Universal metaphysical laws and energy economics"
energy_source: "[PENDING VALIDATION]"
governing_realm: "Universal"
scope: source_canon
status: active
---
# {title}

## Universal Metaphysical Laws
[PENDING VALIDATION: universal physics engine governing supernatural interactions]

## Energy Source & Mechanics
[PENDING VALIDATION: how energy is cultivated, stored, and circulated]

## Sanderson's Law: Costs & Absolute Limitations
- **Energy Cost:** [PENDING VALIDATION: exact toll on body and soul]
- **Absolute Limitations (What is IMPOSSIBLE):** [PENDING VALIDATION: universal impossibilities]
- **Consequences of Abuse:** [PENDING VALIDATION: backlash and burn-out]

## Hierarchy & Progression Tiers
| Tier Number | Tier Name | Universal Benchmark | Sensory Manifestation |
|---|---|---|---|
| 1 | Novice | Rank 1–10 | Faint aura shimmer |
""",
    ),
    "power": (
        "02_Story_Bible/Powers_and_Systems",
        "PWR-",
        """---
uid: "{uid}"
type: power
title: "{title}"
system: "[[SYS-Pending]]"
category: "Elemental / Transformation / Special"
status: active
---
# {title}

## Domain & Core Concept
[PENDING VALIDATION]

## Mechanics of Manifestation
[PENDING VALIDATION]

## Sub-Abilities & Variations
- **Ability A:** [PENDING VALIDATION]
""",
    ),
    "technique": (
        "02_Story_Bible/Powers_and_Systems",
        "TEC-",
        """---
uid: "{uid}"
type: technique
title: "{title}"
power: "[[PWR-Pending]]"
creator_lineage: "[[ORG-Pending]]"
cost_per_cast: "Moderate Energy"
cooldown_recharge: "Immediate"
status: active
---
# {title}

## Technical Execution & Kata
[PENDING VALIDATION: stance, movement, breath and activation sequence]

## Combat Function & Tactical Utility
[PENDING VALIDATION: combat function and battlefield utility]

## Vulnerabilities & Counters
[PENDING VALIDATION: how an informed adversary parries this technique]
""",
    ),
    "faction": (
        "02_Story_Bible/Factions",
        "FAC-",
        """---
uid: "{uid}"
type: faction
title: "{title}"
headquarters: "[[LOC-Pending]]"
leader: "[[CHR-Pending]]"
reputation: "Orthodox / Righteous"
scope: fanfic_canon
status: active
---
# {title}

## Public Stance & Ideology
[PENDING VALIDATION: proclaimed mission to common folk and realm]

## Secret Agenda & True Motives
[PENDING VALIDATION: covert objective pursued by leadership]

## Resources, Military & Economy
- **Revenue Stream:** [PENDING VALIDATION]
- **Standing Forces:** [PENDING VALIDATION]

## Political Alliances & Hostilities
- **Allies:** [[FAC-Pending]]
- **Rivals:** [[FAC-Pending]]
""",
    ),
    "location": (
        "02_Story_Bible/Locations",
        "LOC-",
        """---
uid: "{uid}"
type: location
title: "{title}"
region: "[[LOC-Pending]]"
climate: "Temperate"
controlling_faction: "[[FAC-Pending]]"
status: active
---
# {title}

## Spatial Scale & Floor Plan
- **Overview:** [PENDING VALIDATION: spatial scale and visual layout]
- **Key Layout:** Lower Sector → Upper Sector → Core Sanctum

## Ecology & Environment
[PENDING VALIDATION: flora, fauna, and environmental hazards]

## Economy & Everyday Life
- **Primary Exports:** [PENDING VALIDATION]
- **Local Currency & Trade:** [PENDING VALIDATION]
""",
    ),
    "baseline": (
        "01_Canon_and_Divergence/Baselines",
        "CAN-",
        """---
uid: "{uid}"
type: baseline
title: "{title}"
source_ids:
  - "SRC-Pending"
status: confirmed
scope: source_canon
---
# {title}

## Consolidated Architecture & Overview
[PENDING VALIDATION: High-density synthesis of this canonical entity, system, or mechanism across all cited sources]

## Atomic Canonical Facts
- **[Concept/Mechanism 1]:** [Factual assertion in active voice]
- **[Concept/Mechanism 2]:** [Factual assertion in active voice]

## Canon Divergence & Wiki Discrepancies
- **Discrepancy / Variation:** [Note any conflicts, novel retcons, or terminology shifts across cited fandom sources; link [[LDG-Contradictions]] if unresolved]

## Verbatim Evidence & Source Grounding
- *"[PENDING VALIDATION verbatim quote]"* [[SRC-Pending]]

## What it does NOT establish (Negative Boundaries)
- [Explicit boundary of what these canonical sources do NOT state, preventing LLM hallucination and fanon bleed]
""",
    ),
    "event": (
        "03_Continuity_and_Timeline/Events",
        "EVT-",
        """---
uid: "{uid}"
type: event
title: "{title}"
timeline_year: 0
arc: "[[ARC-Pending]]"
status: confirmed
---
# {title}

## Summary
[PENDING VALIDATION: 2-3 lines describing the event]

## Key Participants
- [[CHR-Pending]]

## Direct Consequences & Outcome
[PENDING VALIDATION: permanent changes caused by this event]
""",
    ),
    "arc": (
        "03_Continuity_and_Timeline/Arcs",
        "ARC-",
        """---
uid: "{uid}"
type: arc
title: "{title}"
description: "One-line dramatic spine of this arc"
status: active
created: {today}
updated: {today}
phase: setup
chapters_span: [C01, C05]
tags:
  - arc/setup
---
# {title}

## Dramatic Spine
- **Want:** [PENDING VALIDATION]
- **Need:** [PENDING VALIDATION]

## Beat Sheet
| Beat | Chapter | Event | Emotional Charge |
|---|---|---|---|
| Inciting Incident | [[C01-Pending]] | Initial disruption | +++ |
| Midpoint | [[C03-Pending]] | Active shift in strategy | 0 |
| Dark Night | [[C04-Pending]] | Core loss and vulnerability | --- |
| Climax | [[C05-Pending]] | Decisive confrontation | +++ |

## Active Threads
- [[LDG-Active_Threads]]
""",
    ),
    "pod": (
        "01_Canon_and_Divergence/PODs",
        "POD-",
        """---
uid: "{uid}"
type: pod
title: "{title}"
divergence_point: "[[EVT-Pending]]"
canon_anchor: "[[CAN-Pending]]"
status: active
scope: fanfic_canon
created: {today}
updated: {today}
tags:
  - pod/active
---
# {title}

## Point of Divergence
[PENDING VALIDATION: exact canon moment where the timeline diverges]

## Immediate Causal Butterfly
[PENDING VALIDATION: direct and immediate consequences in timeline and characters]

## Second & Third Order Consequences
- **Second Order:** [PENDING VALIDATION]
- **Third Order:** [PENDING VALIDATION]

## Affected Canon Baselines
- [[CAN-Pending]]
""",
    ),
    "design_sheet": (
        "02_Story_Bible/Characters",
        "SHT-",
        """---
uid: "{uid}"
type: design_sheet
title: "{title}"
character_ref: "[[CHR-Pending]]"
status: active
created: {today}
updated: {today}
tags:
  - visual/design_sheet
---
# {title} - Design Sheet & Visual HUD

## Visual Anchor & Silhouette
- **Combat Silhouette:** [PENDING VALIDATION: distinctive outline and weapon profile]
- **Comparative Height:** [PENDING VALIDATION: height in cm and scale relative to peers]
- **Color Palette:** Primary (#000000), Secondary (#FFFFFF), Accent (#FF0000)

## Wardrobe & Gear
- **Everyday Attire:** [PENDING VALIDATION]
- **Combat Attire:** [PENDING VALIDATION]
- **Signature Items:** [PENDING VALIDATION]

## Facial Expressions & Body Language
- **Resting Expression:** [PENDING VALIDATION]
- **Combat Stance:** [PENDING VALIDATION]
- **Micro-expressions:** [PENDING VALIDATION]
""",
    ),
    "chapter_pt": (
        "04_Manuscript/pt-BR/Chapters",
        "C",
        """---
uid: "{uid}"
type: chapter
title: "{title}"
language: pt-BR
status: draft
pov: "[[CHR-Pending]]"
timeline_event: "[[EVT-Pending]]"
arc: "[[ARC-Pending]]"
created: {today}
updated: {today}
tags:
  - manuscript/pt-BR
---
# {title}

<!-- p:1 -->
[Texto inicial do capítulo em português brasileiro...]

<!-- p:2 -->
[Continuação narrativa...]
""",
    ),
    "chapter_es": (
        "04_Manuscript/es/Chapters",
        "C",
        """---
uid: "{uid}"
type: chapter
title: "{title}"
language: es
status: draft
source_translation_ref: "[[{source_ref}]]"
pov: "[[CHR-Pending]]"
timeline_event: "[[EVT-Pending]]"
arc: "[[ARC-Pending]]"
created: {today}
updated: {today}
tags:
  - manuscript/es
---
# {title}

<!-- p:1 -->
[Traducción al español correspondiente al párrafo 1...]

<!-- p:2 -->
[Continuación narrativa...]
""",
    ),
}


def _parse_chapter_identity(title: str) -> tuple[str, str]:
    """Parse a chapter title and return (uid, filename_stem).
    Examples:
      '01_O_Despertar' -> ('C01_O_Despertar', 'C01_O_Despertar')
      'Capitulo 1 - O Despertar' -> ('C01_O_Despertar', 'C01_O_Despertar')
      'O Despertar' -> ('C_O_Despertar', 'C_O_Despertar')
    """
    m = re.match(r"^(?:c(?:hapter)?|cap(?:[ií]tulo)?|cap)?\s*0*(\d+)(?:[-_:\s]+(.*))?$", title.strip(), re.IGNORECASE)
    if m:
        num = int(m.group(1))
        rest = (m.group(2) or "").strip()
        slug = slugify(rest) if rest else f"Chapter_{num:02d}"
        stem = f"C{num:02d}_{slug}" if slug else f"C{num:02d}"
        return stem, stem
    slug = slugify(title)
    stem = f"C_{slug}"
    return stem, stem


def create_page(vault: Vault, ptype: str, title: str, source_ref: str | None = None) -> Path:
    """Create a new typed page from blueprint without overwriting existing files."""
    if not title or not title.strip():
        raise VaultError("Title must not be empty")
    spec = BLUEPRINTS.get(ptype)
    if not spec:
        raise VaultError(f"Unknown page type '{ptype}'. Available types: {sorted(BLUEPRINTS.keys())}")

    folder_rel, prefix, template = spec

    if ptype in ("chapter_pt", "chapter_es"):
        uid, stem = _parse_chapter_identity(title)
        filename = f"{stem}.md"
    else:
        slug = slugify(title)
        uid = f"{prefix}{slug}"
        filename = f"{uid}.md"

    target_path = vault.root / folder_rel / filename

    if target_path.exists():
        raise VaultError(f"File already exists: {vault.rel(target_path)}")

    today = date.today().isoformat()
    resolved_source_ref = source_ref or "C01-Pending"
    content = template.format(
        uid=uid,
        title=title,
        today=today,
        source_ref=resolved_source_ref,
    )
    write_text_atomic(target_path, content)
    return target_path

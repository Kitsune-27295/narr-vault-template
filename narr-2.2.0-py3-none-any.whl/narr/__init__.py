"""narr - Lean CLI toolkit for Narrative Story Bible Framework."""

__version__ = "2.2.0"

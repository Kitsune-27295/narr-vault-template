"""Entrypoint for python -m narr."""

from narr.cli import app

if __name__ == "__main__":
    app()

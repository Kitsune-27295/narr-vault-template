"""Session brief and multi-tier operational memory management (ADR-005 / Second_brain parity)."""

from __future__ import annotations

from pathlib import Path

from narr.checks import run_all_checks
from narr.pages import Page
from narr.vault import Vault, read_text_or_none

BRIEF_MAX_CHARS = 9_000
HOT_MAX_LINES = 60
MAX_ITEMS = 5


def session_brief(vault: Vault) -> str:
    """Compile high-signal, budget-constrained operational session brief (<9,000 chars)."""
    parts: list[str] = [
        f"=== NARRATIVE VAULT SESSION BRIEF: {vault.root.name} ===",
        "",
    ]

    # Tier 1: Hot working memory (quoted, max 60 lines)
    hot_path = vault.root / "memory" / "hot.md"
    parts.append("## In Flight (memory/hot.md)")
    if hot_path.is_file():
        hot_text = read_text_or_none(hot_path) or ""
        lines = hot_text.strip().splitlines()
        kept_lines = lines[:HOT_MAX_LINES]
        for l in kept_lines:
            parts.append(f"> {l}")
        if len(lines) > HOT_MAX_LINES:
            parts.append(f"> _(cut: {len(lines) - HOT_MAX_LINES} lines exceeding 60-line budget)_")
    else:
        parts.append("> _memory/hot.md is empty or not created yet_")
    parts.append("")

    # Tier 2: Active Threads & Chekhov Guns
    threads_path = vault.root / "08_Ledgers" / "LDG-Active_Threads.md"
    if threads_path.is_file():
        t_text = read_text_or_none(threads_path) or ""
        active_t = [l.strip() for l in t_text.splitlines() if l.startswith("|") and ("active" in l.lower() or "ativo" in l.lower())]
        parts.append(f"## Active Plot Threads ({len(active_t)})")
        for item in active_t[:MAX_ITEMS]:
            parts.append(f"- {item}")
        if len(active_t) > MAX_ITEMS:
            parts.append(f"- ... and {len(active_t) - MAX_ITEMS} more in LDG-Active_Threads.md")
        parts.append("")

    guns_path = vault.root / "08_Ledgers" / "LDG-Chekhov_Guns.md"
    if guns_path.is_file():
        g_text = read_text_or_none(guns_path) or ""
        primed_g = [l.strip() for l in g_text.splitlines() if l.startswith("|") and ("primed" in l.lower() or "armada" in l.lower())]
        if primed_g:
            parts.append(f"## Primed Chekhov Guns ({len(primed_g)})")
            for item in primed_g[:MAX_ITEMS]:
                parts.append(f"- {item}")
            parts.append("")

    # Tier 3: Open Decisions (status: proposed)
    pages: list[Page] = []
    for r_path, _ in vault.entries(".md"):
        p = Page.load(vault.root / r_path, r_path)
        if p:
            pages.append(p)

    proposed_decisions = [p for p in pages if p.page_type == "decision" and (p.doc.meta or {}).get("status") == "proposed"]
    parts.append(f"## Open Decisions ({len(proposed_decisions)})")
    if proposed_decisions:
        for d in proposed_decisions[:MAX_ITEMS]:
            desc = (d.doc.meta or {}).get("description", "")
            parts.append(f"- [[{d.title or Path(d.rel_path).stem}]] - {desc}")
    else:
        parts.append("- (none proposed)")
    parts.append("")

    # Tier 4: Inbox & Uncited Sources
    inbox_dir = vault.root / "01_Canon_and_Divergence" / "Sources" / "inbox"
    inbox_sources = list(inbox_dir.glob("*.md")) if inbox_dir.is_dir() else []
    parts.append(f"## Sources Inbox ({len(inbox_sources)} awaiting ingest)")
    if inbox_sources:
        for s in inbox_sources[:MAX_ITEMS]:
            parts.append(f"- {s.stem}")
        if len(inbox_sources) > MAX_ITEMS:
            parts.append(f"- ... and {len(inbox_sources) - MAX_ITEMS} more")
    else:
        parts.append("- (inbox clear)")
    parts.append("")

    # Tier 5: Vault Health
    findings = run_all_checks(vault)
    errors = [f for f in findings if f.severity == "error"]
    warnings = [f for f in findings if f.severity == "warning"]
    parts.append(f"## Vault Health: {len(errors)} error(s), {len(warnings)} warning(s)")
    if errors:
        for err in errors[:MAX_ITEMS]:
            parts.append(f"- [ERR] {err.path}: {err.message}")
        if len(errors) > MAX_ITEMS:
            parts.append(f"- ... and {len(errors) - MAX_ITEMS} more (run 'narr lint')")
    else:
        parts.append("- [OK] 100% compliant")

    text = "\n".join(parts) + "\n"
    if len(text) > BRIEF_MAX_CHARS:
        text = text[:BRIEF_MAX_CHARS].rsplit("\n", 1)[0] + "\n_(brief cut at 9,000 char budget)_\n"
    return text

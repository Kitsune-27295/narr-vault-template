"""Session brief and multi-tier operational memory management (ADR-005 / Second_brain parity)."""

from __future__ import annotations

from pathlib import Path

from narr.checks import run_all_checks
from narr.pages import Page
from narr.vault import Vault, read_text_or_none

BRIEF_MAX_CHARS = 8_999
HOT_MAX_LINES = 60
MAX_ITEMS = 5
CUT_NOTICE = "\n_(brief cut at 9,000 char budget)_\n"


def _is_active_thread_row(line: str) -> bool:
    """Check if table row declares an active thread without substring false-positives (e.g. inactive)."""
    if not line.startswith("|") or line.startswith("|---"):
        return False
    cells = [c.strip().lower() for c in line.strip().strip("|").split("|")]
    return any(c in {"active", "ativo"} for c in cells)


def _is_primed_gun_row(line: str) -> bool:
    """Check if table row declares a primed Chekhov gun without substring false-positives (e.g. unprimed)."""
    if not line.startswith("|") or line.startswith("|---"):
        return False
    cells = [c.strip().lower() for c in line.strip().strip("|").split("|")]
    return any(c in {"primed", "armada"} for c in cells)


def session_brief(vault: Vault) -> str:
    """Compile high-signal, budget-constrained operational session brief (<9,000 chars)."""
    parts: list[str] = [
        f"=== NARRATIVE VAULT SESSION BRIEF: {vault.name} ===",
        "",
    ]

    # Tier 1: Hot working memory (quoted, max 60 lines)
    hot_path = vault.root / "memory" / "hot.md"
    parts.append("## In Flight (memory/hot.md)")
    if hot_path.is_file():
        hot_text = read_text_or_none(hot_path) or ""
        lines = hot_text.strip().splitlines()
        kept_lines = lines[:HOT_MAX_LINES]
        for line in kept_lines:
            parts.append(f"> {line}")
        if len(lines) > HOT_MAX_LINES:
            parts.append(f"> _(cut: {len(lines) - HOT_MAX_LINES} lines exceeding 60-line budget)_")
    else:
        parts.append("> _memory/hot.md is empty or not created yet_")
    parts.append("")

    # Tier 2: Active Threads & Primed Chekhov Guns
    threads_path = vault.root / "08_Ledgers" / "LDG-Active_Threads.md"
    if threads_path.is_file():
        t_text = read_text_or_none(threads_path) or ""
        active_threads = [line.strip() for line in t_text.splitlines() if _is_active_thread_row(line)]
        parts.append(f"## Active Plot Threads ({len(active_threads)})")
        if active_threads:
            for item in active_threads[:MAX_ITEMS]:
                parts.append(f"- {item}")
            if len(active_threads) > MAX_ITEMS:
                parts.append(f"- ... and {len(active_threads) - MAX_ITEMS} more in LDG-Active_Threads.md")
        else:
            parts.append("- (none active)")
        parts.append("")
    else:
        parts.append("## Active Plot Threads (0)")
        parts.append("- (none active)")
        parts.append("")

    guns_path = vault.root / "08_Ledgers" / "LDG-Chekhov_Guns.md"
    if guns_path.is_file():
        g_text = read_text_or_none(guns_path) or ""
        primed_guns = [line.strip() for line in g_text.splitlines() if _is_primed_gun_row(line)]
        if primed_guns:
            parts.append(f"## Primed Chekhov Guns ({len(primed_guns)})")
            for item in primed_guns[:MAX_ITEMS]:
                parts.append(f"- {item}")
            if len(primed_guns) > MAX_ITEMS:
                parts.append(f"- ... and {len(primed_guns) - MAX_ITEMS} more in LDG-Chekhov_Guns.md")
            parts.append("")

    # Tier 3: Open Decisions (status: proposed in memory/decisions/)
    proposed_decisions: list[Page] = []
    decisions_dir = vault.root / "memory" / "decisions"
    if decisions_dir.is_dir():
        for d_file in sorted(decisions_dir.glob("*.md")):
            rel_p = vault.rel(d_file)
            p = Page.load(d_file, rel_p)
            if p and (p.doc.meta or {}).get("status") == "proposed":
                proposed_decisions.append(p)

    parts.append(f"## Open Decisions ({len(proposed_decisions)})")
    if proposed_decisions:
        for d in proposed_decisions[:MAX_ITEMS]:
            desc = (d.doc.meta or {}).get("description", "")
            desc_part = f" - {desc}" if desc else ""
            parts.append(f"- [[{d.title or Path(d.rel_path).stem}]]{desc_part}")
        if len(proposed_decisions) > MAX_ITEMS:
            parts.append(f"- ... and {len(proposed_decisions) - MAX_ITEMS} more in memory/decisions/")
    else:
        parts.append("- (none proposed)")
    parts.append("")

    # Tier 4: Inbox & Uncited Sources
    inbox_dir = vault.root / "01_Canon_and_Divergence" / "Sources" / "inbox"
    inbox_sources = sorted(inbox_dir.glob("*.md")) if inbox_dir.is_dir() else []
    parts.append(f"## Sources Inbox ({len(inbox_sources)} awaiting ingest)")
    if inbox_sources:
        for s in inbox_sources[:MAX_ITEMS]:
            parts.append(f"- {s.stem}")
        if len(inbox_sources) > MAX_ITEMS:
            parts.append(f"- ... and {len(inbox_sources) - MAX_ITEMS} more")
    else:
        parts.append("- (inbox clear)")
    parts.append("")

    # Tier 5: Vault Health
    findings = run_all_checks(vault)
    errors = [f for f in findings if f.severity == "error"]
    warnings = [f for f in findings if f.severity == "warning"]
    parts.append(f"## Vault Health: {len(errors)} error(s), {len(warnings)} warning(s)")
    if errors:
        for err in errors[:MAX_ITEMS]:
            parts.append(f"- [ERR] {err.path}: {err.message}")
        if len(errors) > MAX_ITEMS:
            parts.append(f"- ... and {len(errors) - MAX_ITEMS} more (run 'narr lint')")
    elif warnings:
        parts.append(f"- [OK] 0 errors, {len(warnings)} warning(s)")
    else:
        parts.append("- [OK] 100% compliant")

    text = "\n".join(parts) + "\n"
    if len(text) > BRIEF_MAX_CHARS:
        available = BRIEF_MAX_CHARS - len(CUT_NOTICE)
        cut_point = text[:available].rfind("\n")
        sliced = text[:cut_point] if cut_point > 0 else text[:available]
        text = sliced + CUT_NOTICE

    return text

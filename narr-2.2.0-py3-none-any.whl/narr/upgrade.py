"""Idempotent framework refresh and agent parity sync without touching vault data."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from narr import __version__
from narr.vault import Vault, read_text_or_none, write_text_atomic


@dataclass
class Change:
    path: str
    action: str  # "current" | "add" | "update"
    detail: str = ""

    def to_dict(self) -> dict[str, str]:
        return {"path": self.path, "action": self.action, "detail": self.detail}


def _sync_file(
    src: Path,
    dest: Path,
    rel_dest: str,
    dry_run: bool,
    changes: list[Change],
) -> None:
    """Sync a single file from src to dest atomically recording the change action."""
    source_content = read_text_or_none(src)
    if source_content is None:
        return
    dest_content = read_text_or_none(dest)

    if dest_content == source_content:
        changes.append(Change(path=rel_dest, action="current", detail="up to date"))
    elif dest_content is None:
        if not dry_run:
            write_text_atomic(dest, source_content)
        changes.append(Change(path=rel_dest, action="add", detail=f"added {src.name}"))
    else:
        if not dry_run:
            write_text_atomic(dest, source_content)
        changes.append(Change(path=rel_dest, action="update", detail=f"updated {src.name}"))


def check_version_alignment(vault: Vault) -> tuple[bool, str]:
    """Check whether the vault's stamped .narr-version matches the running framework.

    Args:
        vault: Story bible vault instance.

    Returns:
        Tuple of (is_aligned, detail_message).
    """
    narr_version_file = vault.root / ".narr-version"
    if not narr_version_file.is_file():
        return (
            False,
            f"Missing .narr-version. Vault unversioned; run 'narr upgrade' to stamp with framework {__version__}.",
        )

    v_text = narr_version_file.read_text(encoding="utf-8").strip()
    is_current = v_text == f"narr {__version__}" or v_text == __version__
    if is_current:
        return (True, f"Vault stamped at '{v_text}' matches framework {__version__}")
    return (
        False,
        f"Vault stamped at '{v_text}', current framework is {__version__}. Run 'narr upgrade' to sync.",
    )


def upgrade_vault(vault: Vault, dry_run: bool = False) -> list[Change]:
    """Synchronize agent rules and skills from canonical .agents/ to .claude/ idempotently.

    Files matching destination are reported as 'current'.
    Missing files are reported as 'add'.
    Modified files are reported as 'update'.

    Args:
        vault: Story bible vault instance.
        dry_run: If True, preview changes without writing files to disk.

    Returns:
        List of Change objects detailing affected paths and actions.
    """
    changes: list[Change] = []

    # 1. Synchronize agent rules
    a_rules = vault.root / ".agents" / "rules"
    c_rules = vault.root / ".claude" / "rules"
    if a_rules.is_dir():
        for rule_file in sorted(a_rules.glob("*.md")):
            dest = c_rules / rule_file.name
            rel_dest = dest.relative_to(vault.root).as_posix()
            _sync_file(rule_file, dest, rel_dest, dry_run, changes)

    # 2. Synchronize agent skills (including nested subdirectories)
    a_skills = vault.root / ".agents" / "skills"
    c_skills = vault.root / ".claude" / "skills"
    if a_skills.is_dir():
        for skill_dir in sorted(a_skills.iterdir()):
            if skill_dir.is_dir():
                for f in sorted(skill_dir.rglob("*")):
                    if f.is_file():
                        rel_in_skill = f.relative_to(skill_dir)
                        dest_f = c_skills / skill_dir.name / rel_in_skill
                        rel_dest = dest_f.relative_to(vault.root).as_posix()
                        _sync_file(f, dest_f, rel_dest, dry_run, changes)

    # 3. Synchronize .narr-version
    narr_v_file = vault.root / ".narr-version"
    rel_v = ".narr-version"
    expected_v = f"narr {__version__}\n"
    current_v = read_text_or_none(narr_v_file)

    if current_v is None:
        if not dry_run:
            write_text_atomic(narr_v_file, expected_v)
        changes.append(Change(path=rel_v, action="add", detail=f"stamped {expected_v.strip()}"))
    elif current_v == expected_v or current_v.strip() == expected_v.strip():
        changes.append(Change(path=rel_v, action="current", detail="up to date"))
    else:
        if not dry_run:
            write_text_atomic(narr_v_file, expected_v)
        changes.append(Change(path=rel_v, action="update", detail=f"updated to {expected_v.strip()}"))

    return changes

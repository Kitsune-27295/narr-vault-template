"""Idempotent framework refresh and agent parity sync without touching vault data."""

from __future__ import annotations

from dataclasses import dataclass

from narr.vault import Vault, read_text_or_none, write_text_atomic


@dataclass
class Change:
    path: str
    action: str  # "current" | "add" | "update"
    detail: str = ""

    def to_dict(self) -> dict[str, str]:
        return {"path": self.path, "action": self.action, "detail": self.detail}


def upgrade_vault(vault: Vault, dry_run: bool = False) -> list[Change]:
    """Synchronize agent rules and refresh framework files safely.

    Files matching destination are reported as 'current'.
    Missing files are reported as 'add'.
    Modified files are reported as 'update'.
    """
    changes: list[Change] = []

    a_rules = vault.root / ".agents" / "rules"
    c_rules = vault.root / ".claude" / "rules"
    if a_rules.is_dir():
        c_rules.mkdir(parents=True, exist_ok=True)
        for rule_file in sorted(a_rules.glob("*.md")):
            dest = c_rules / rule_file.name
            rel_dest = dest.relative_to(vault.root).as_posix()
            source_content = read_text_or_none(rule_file)
            dest_content = read_text_or_none(dest)

            if source_content is not None:
                if dest_content == source_content:
                    changes.append(Change(path=rel_dest, action="current", detail="up to date"))
                elif dest_content is None:
                    if not dry_run:
                        write_text_atomic(dest, source_content)
                    changes.append(Change(path=rel_dest, action="add", detail=f"added {rule_file.name}"))
                else:
                    if not dry_run:
                        write_text_atomic(dest, source_content)
                    changes.append(Change(path=rel_dest, action="update", detail=f"updated {rule_file.name}"))

    a_skills = vault.root / ".agents" / "skills"
    c_skills = vault.root / ".claude" / "skills"
    if a_skills.is_dir():
        c_skills.mkdir(parents=True, exist_ok=True)
        for skill_dir in sorted(a_skills.iterdir()):
            if skill_dir.is_dir():
                dest_dir = c_skills / skill_dir.name
                dest_dir.mkdir(parents=True, exist_ok=True)
                for f in sorted(skill_dir.glob("*")):
                    if f.is_file():
                        dest_f = dest_dir / f.name
                        rel_dest = dest_f.relative_to(vault.root).as_posix()
                        source_content = read_text_or_none(f)
                        dest_content = read_text_or_none(dest_f)

                        if source_content is not None:
                            if dest_content == source_content:
                                changes.append(Change(path=rel_dest, action="current", detail="up to date"))
                            elif dest_content is None:
                                if not dry_run:
                                    write_text_atomic(dest_f, source_content)
                                changes.append(Change(path=rel_dest, action="add", detail=f"added {f.name}"))
                            else:
                                if not dry_run:
                                    write_text_atomic(dest_f, source_content)
                                changes.append(Change(path=rel_dest, action="update", detail=f"updated {f.name}"))

    return changes

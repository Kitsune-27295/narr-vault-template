"""Idempotent framework refresh and agent parity sync without touching vault data."""

from __future__ import annotations

from narr.vault import Vault, read_text_or_none, write_text_atomic


def upgrade_vault(vault: Vault, dry_run: bool = False) -> list[str]:
    """Synchronize agent rules and refresh framework files safely."""
    actions: list[str] = []

    a_rules = vault.root / ".agents" / "rules"
    c_rules = vault.root / ".claude" / "rules"
    if a_rules.is_dir():
        c_rules.mkdir(parents=True, exist_ok=True)
        for rule_file in a_rules.glob("*.md"):
            dest = c_rules / rule_file.name
            content = read_text_or_none(rule_file)
            if content:
                if not dry_run:
                    write_text_atomic(dest, content)
                actions.append(f"Synchronized rule: {rule_file.name} -> .claude/rules/")

    a_skills = vault.root / ".agents" / "skills"
    c_skills = vault.root / ".claude" / "skills"
    if a_skills.is_dir():
        c_skills.mkdir(parents=True, exist_ok=True)
        for skill_dir in a_skills.iterdir():
            if skill_dir.is_dir():
                dest_dir = c_skills / skill_dir.name
                dest_dir.mkdir(parents=True, exist_ok=True)
                for f in skill_dir.glob("*"):
                    if f.is_file():
                        content = read_text_or_none(f)
                        if content and not dry_run:
                            write_text_atomic(dest_dir / f.name, content)
                actions.append(f"Synchronized skill: {skill_dir.name} -> .claude/skills/")

    return actions

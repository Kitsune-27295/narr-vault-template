"""YAML frontmatter parsing and serialization with strict duplicate key prevention."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import yaml

from narr.vault import BOM

_FENCE = "---"
_MERGE_TAG = "tag:yaml.org,2002:merge"


class FrontmatterError(ValueError):
    """Frontmatter syntax error or invalid structure."""


class _UniqueKeyLoader(yaml.SafeLoader):
    """safe_load that rejects duplicate keys."""

    def construct_mapping(self, node: yaml.MappingNode, deep: bool = False) -> dict[Any, Any]:
        seen: set[Any] = set()
        for key_node, _ in node.value:
            if not isinstance(key_node, yaml.ScalarNode) or key_node.tag == _MERGE_TAG:
                continue
            key = self.construct_object(key_node, deep=deep)
            if key in seen:
                raise yaml.constructor.ConstructorError(None, None, f"duplicate key {key!r} in frontmatter", key_node.start_mark)
            seen.add(key)
        return super().construct_mapping(node, deep)


@dataclass
class Doc:
    meta: dict[str, Any] = field(default_factory=dict)
    body: str = ""
    body_offset: int = 0


def parse(text: str) -> Doc:
    """Parse text into YAML frontmatter dict and markdown body."""
    lines = text.removeprefix(BOM).split("\n")
    if not lines or lines[0].strip() != _FENCE:
        return Doc({}, text, 0)
    for end in range(1, len(lines)):
        if lines[end].strip() == _FENCE:
            raw = "\n".join(lines[1:end])
            try:
                meta = yaml.load(raw, Loader=_UniqueKeyLoader) if raw.strip() else {}
            except (yaml.YAMLError, ValueError) as exc:
                raise FrontmatterError(f"Invalid YAML frontmatter: {exc}") from exc
            if not isinstance(meta, dict):
                raise FrontmatterError("Frontmatter must be a YAML mapping (key-value dictionary)")
            return Doc(meta, "\n".join(lines[end + 1 :]), end + 1)
    raise FrontmatterError("Frontmatter opened with '---' but never closed with matching '---'")


def dump(doc: Doc) -> str:
    """Serialize Doc back into markdown string with frontmatter."""
    if not doc.meta:
        return doc.body
    meta_str = yaml.safe_dump(doc.meta, sort_keys=False, allow_unicode=True).rstrip("\n")
    return f"{_FENCE}\n{meta_str}\n{_FENCE}\n{doc.body}"

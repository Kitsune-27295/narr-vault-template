"""Environment health check, FTS5 verification, and agent configuration diagnostics."""

from __future__ import annotations

import sqlite3
import sys
from dataclasses import dataclass

from narr.vault import Vault


@dataclass
class Diagnostic:
    name: str
    status: bool
    detail: str


def run_doctor(vault: Vault) -> list[Diagnostic]:
    """Run full environment diagnostics."""
    diagnostics: list[Diagnostic] = []

    # 1. Python version check
    py_ok = sys.version_info >= (3, 11)
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    diagnostics.append(
        Diagnostic(
            name="Python Version",
            status=py_ok,
            detail=f"Running Python {py_ver} (required: >= 3.11)",
        )
    )

    # 2. SQLite FTS5 support check
    fts_ok = False
    try:
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE VIRTUAL TABLE t USING fts5(content)")
        fts_ok = True
        conn.close()
    except Exception:
        pass
    diagnostics.append(
        Diagnostic(
            name="SQLite FTS5 Support",
            status=fts_ok,
            detail="Available" if fts_ok else "FTS5 not enabled in current SQLite binary",
        )
    )

    # 3. vault.yaml check
    cfg_ok = bool(vault.config.get("version"))
    diagnostics.append(
        Diagnostic(
            name="Vault Configuration",
            status=cfg_ok,
            detail=f"vault.yaml v{vault.config.get('version', 'unknown')} valid",
        )
    )

    # 4. Multi-agent parity check
    a_rules = vault.root / ".agents" / "rules"
    c_rules = vault.root / ".claude" / "rules"
    parity_ok = True
    if a_rules.is_dir() and c_rules.is_dir():
        a_set = {p.name for p in a_rules.glob("*.md")}
        c_set = {p.name for p in c_rules.glob("*.md")}
        parity_ok = a_set == c_set
    diagnostics.append(
        Diagnostic(
            name="Multi-Agent Parity",
            status=parity_ok,
            detail="Synchronized" if parity_ok else "Drift detected between .agents and .claude",
        )
    )

    return diagnostics

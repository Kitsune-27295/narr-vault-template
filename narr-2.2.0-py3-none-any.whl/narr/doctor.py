"""Environment health check, FTS5 verification, and agent configuration diagnostics."""

from __future__ import annotations

import hashlib
import sqlite3
import sys
from dataclasses import dataclass
from pathlib import Path

from narr.upgrade import check_version_alignment
from narr.vault import Vault


@dataclass
class Diagnostic:
    name: str
    status: bool
    detail: str


def _tree_digest(root: Path) -> dict[str, str]:
    """Map each file under root (relative POSIX path) to a line-ending-insensitive content hash."""
    digest: dict[str, str] = {}
    for path in sorted(root.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            data = path.read_bytes().replace(b"\r\n", b"\n")
            digest[path.relative_to(root).as_posix()] = hashlib.sha256(data).hexdigest()
    return digest


def parity_drift(vault: Vault) -> list[str]:
    """List files that differ between .agents and .claude (rules and skills), by name or content."""
    drift: list[str] = []
    for sub in ("rules", "skills"):
        a_dir = vault.root / ".agents" / sub
        c_dir = vault.root / ".claude" / sub
        if not (a_dir.is_dir() and c_dir.is_dir()):
            continue
        a_map, c_map = _tree_digest(a_dir), _tree_digest(c_dir)
        for name in sorted(set(a_map) | set(c_map)):
            if a_map.get(name) != c_map.get(name):
                drift.append(f"{sub}/{name}")
    return drift


def run_doctor(vault: Vault) -> list[Diagnostic]:
    """Run full environment diagnostics."""
    diagnostics: list[Diagnostic] = []

    # 1. Python version check
    py_ok = sys.version_info >= (3, 11)
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    diagnostics.append(
        Diagnostic(
            name="Python Version",
            status=py_ok,
            detail=f"Running Python {py_ver} (required: >= 3.11)",
        )
    )

    # 2. SQLite FTS5 support check
    fts_ok = False
    try:
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE VIRTUAL TABLE t USING fts5(content)")
        fts_ok = True
        conn.close()
    except Exception:
        pass
    diagnostics.append(
        Diagnostic(
            name="SQLite FTS5 Support",
            status=fts_ok,
            detail="Available" if fts_ok else "FTS5 not enabled in current SQLite binary",
        )
    )

    # 3. vault.yaml check
    cfg_ok = bool(vault.config.get("version"))
    diagnostics.append(
        Diagnostic(
            name="Vault Configuration",
            status=cfg_ok,
            detail=f"vault.yaml v{vault.config.get('version', 'unknown')} valid",
        )
    )

    # 4. Multi-agent parity check
    drift = parity_drift(vault)
    parity_ok = not drift
    diagnostics.append(
        Diagnostic(
            name="Multi-Agent Parity",
            status=parity_ok,
            detail="Synchronized"
            if parity_ok
            else "Drift detected between .agents and .claude: " + ", ".join(drift[:5]) + (" ..." if len(drift) > 5 else ""),
        )
    )

    # 5. Framework version check (.narr-version)
    ver_ok, ver_detail = check_version_alignment(vault)
    diagnostics.append(
        Diagnostic(
            name="Framework Version Alignment",
            status=ver_ok,
            detail=ver_detail,
        )
    )

    return diagnostics

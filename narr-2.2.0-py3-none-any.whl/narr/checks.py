"""Modular, pure lint engine for Narrative Story Bible Framework."""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from narr.pages import Page
from narr.vault import Vault, is_safe_name, read_text, read_text_or_none

_CJK_PATTERN = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]")
_AI_PREAMBLES = re.compile(r"(?i)^(certamente|com certeza|aqui est[aá]|espero que ajude|sure,|here is|certainly|as an ai|as requested)")
_PASSIVE_INDICATORS = re.compile(
    r"(?i)\b(foi feito por|foram criados por|foi aprovado pela|sendo realizado por|was done by|were created by)\b"
)

APPROVED_TYPES = frozenset(
    {
        "character",
        "location",
        "faction",
        "power_system",
        "power",
        "technique",
        "item",
        "cosmological_constant",
        "terminology",
        "event",
        "arc",
        "chapter",
        "decision",
        "baseline",
        "pod",
        "contradiction",
        "tone_bible",
        "design_sheet",
        "termbase",
        "ledger",
        "concept",
        "atlas",
        "guide",
        "source",
        "index",
    }
)


def budget(vault: Vault, key: str, default: int) -> int:
    """Read context budgets dynamically from vault.yaml with fallback (DEF-05)."""
    return int(vault.config.get("budgets", {}).get(key, default))


@dataclass(frozen=True)
class Finding:
    code: str
    path: str
    message: str
    severity: Literal["error", "warning", "info"] = "error"


def run_all_checks(vault: Vault, path_filter: str | None = None) -> list[Finding]:
    """Execute all modular lint rules across the vault."""
    findings: list[Finding] = []
    checks: list[Callable[[Vault, list[Page]], list[Finding]]] = [
        check_vault_budgets_and_parity,
        check_filenames_and_zones,
        check_frontmatter_and_properties,
        check_wikilinks_and_boundaries,
        check_style_and_language,
        check_relational_completeness,
        check_ledgers_and_continuity,
        check_sources_and_verbatim,
        check_worldbuilder_disease,
        check_manuscript_translation_parity,
        check_baseline_ontological_purity,
    ]

    # Preload pages
    pages: list[Page] = []
    for rel_path, entry in vault.entries(".md"):
        if path_filter and path_filter not in rel_path:
            continue
        p = Page.load(Path(entry.path), rel_path)
        if p:
            pages.append(p)

    for chk in checks:
        try:
            findings.extend(chk(vault, pages))
        except Exception as exc:
            findings.append(
                Finding(
                    code="LNT001",
                    path=chk.__name__,
                    message=f"Check crashed unexpectedly: {exc}",
                    severity="error",
                )
            )

    return sorted(findings, key=lambda f: (f.severity != "error", f.code, f.path))


def check_vault_budgets_and_parity(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []

    # VAL022: AGENTS.md budget check
    agents_md = vault.root / "AGENTS.md"
    if agents_md.is_file():
        text = read_text(agents_md)
        line_count = len(text.splitlines())
        limit_agents = budget(vault, "agents_lines", 200)
        if line_count > limit_agents:
            findings.append(
                Finding(
                    code="VAL022",
                    path="AGENTS.md",
                    message=f"AGENTS.md has {line_count} lines (budget: <={limit_agents}). Delegate detail to .agents/rules/.",
                    severity="error",
                )
            )

    # VAL015: hot.md budget check
    hot_md = vault.root / "memory" / "hot.md"
    if hot_md.is_file():
        line_count = len(read_text(hot_md).splitlines())
        limit_hot = budget(vault, "hot_memory_lines", 60)
        if line_count > limit_hot:
            findings.append(
                Finding(
                    code="VAL015",
                    path="memory/hot.md",
                    message=f"hot.md has {line_count} lines (budget: <={limit_hot}). Archive closed threads.",
                )
            )

    # VAL012: .agents vs .claude rules parity
    agents_rules = vault.root / ".agents" / "rules"
    claude_rules = vault.root / ".claude" / "rules"
    if agents_rules.is_dir() and claude_rules.is_dir():
        a_files = {p.name: read_text(p).replace("\r\n", "\n") for p in agents_rules.glob("*.md")}
        c_files = {p.name: read_text(p).replace("\r\n", "\n") for p in claude_rules.glob("*.md")}
        if a_files != c_files:
            findings.append(
                Finding(
                    code="VAL012",
                    path=".agents/rules",
                    message="Parity drift between .agents/rules and .claude/rules. Run narr upgrade to synchronize.",
                    severity="warning",
                )
            )

    # VAL018: Operational file exceeds 300 KB
    for rel_path, entry in vault.entries():
        try:
            size = entry.stat().st_size
            limit_bytes = budget(vault, "file_bytes", 307200)
            if size > limit_bytes and not rel_path.startswith("01_Canon_and_Divergence/Sources/"):
                findings.append(
                    Finding(
                        code="VAL018",
                        path=rel_path,
                        message=f"File exceeds 300 KB limit ({size // 1024} KB). Split or trim content.",
                        severity="warning",
                    )
                )
        except OSError:
            pass

    return findings


def check_filenames_and_zones(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    for rel_path, entry in vault.entries(".md"):
        name = entry.name
        # VAL003: Filename spaces or unsafe chars
        if not is_safe_name(name):
            findings.append(
                Finding(
                    code="VAL003",
                    path=rel_path,
                    message=f"Filename '{name}' contains spaces or illegal characters. Use underscores.",
                )
            )

        # VAL004: Type prefix matches directory zone
        if name.startswith("CHR-") and "02_Story_Bible/Characters" not in rel_path:
            findings.append(Finding(code="VAL004", path=rel_path, message="Character file outside Characters zone."))
        elif name.startswith("LOC-") and "02_Story_Bible/Locations" not in rel_path:
            findings.append(Finding(code="VAL004", path=rel_path, message="Location file outside Locations zone."))
        elif (
            name.startswith("SYS-") or name.startswith("PWR-") or name.startswith("TEC-")
        ) and "02_Story_Bible/Powers_and_Systems" not in rel_path:
            findings.append(Finding(code="VAL004", path=rel_path, message="Power/System file outside Powers_and_Systems zone."))
        elif name.startswith("CAN-") and "01_Canon_and_Divergence/Baselines" not in rel_path:
            findings.append(Finding(code="VAL004", path=rel_path, message="Baseline file outside Baselines zone."))
        elif name.startswith("POD-") and "01_Canon_and_Divergence/PODs" not in rel_path:
            findings.append(Finding(code="VAL004", path=rel_path, message="POD file outside PODs zone."))

    return findings


def check_frontmatter_and_properties(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    for p in pages:
        meta = p.doc.meta
        if not meta and p.rel_path.startswith(("01_Canon_and_Divergence/Baselines", "02_Story_Bible", "03_Continuity")):
            findings.append(
                Finding(
                    code="VAL001",
                    path=p.rel_path,
                    message="Missing required YAML frontmatter.",
                )
            )
            continue

        if meta:
            # VAL001: Missing uid, type, title, status
            for req in ("uid", "type", "title", "status"):
                if req not in meta:
                    findings.append(
                        Finding(
                            code="VAL001",
                            path=p.rel_path,
                            message=f"Frontmatter missing required field '{req}'.",
                        )
                    )

            # VAL006: Forbidden type
            ptype = str(meta.get("type", ""))
            if ptype and ptype not in APPROVED_TYPES:
                findings.append(
                    Finding(
                        code="VAL006",
                        path=p.rel_path,
                        message=f"Unapproved page type '{ptype}'. Must be one of {sorted(APPROVED_TYPES)}.",
                    )
                )

    return findings


def check_wikilinks_and_boundaries(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    existing_stems = {entry.name.split(".", 1)[0] for _, entry in vault.entries(".md")}
    existing_titles = {p.title for p in pages if p.title}
    all_targets = existing_stems | existing_titles

    for p in pages:
        if p.rel_path.startswith("Meta/Templates/"):
            continue
        for link in p.links:
            # VAL002: Dead wikilink
            clean_link = link.split("|", 1)[0].split("#", 1)[0].strip()
            if clean_link and clean_link not in all_targets:
                findings.append(
                    Finding(
                        code="VAL002",
                        path=p.rel_path,
                        message=f"Wikilink '[[{clean_link}]]' resolves to no file in the vault.",
                        severity="warning",
                    )
                )

            # VAL014: Story Bible linking into Sandbox zone
            if p.rel_path.startswith("02_Story_Bible/") and ("06_Ideation_and_Unblocking" in link or "SBX-" in link):
                findings.append(
                    Finding(
                        code="VAL014",
                        path=p.rel_path,
                        message=f"Epistemic boundary violation: Story Bible links to sandbox '{link}'.",
                    )
                )

    return findings


def check_style_and_language(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    for p in pages:
        body = p.doc.body
        # VAL010: CJK outside Sources/
        if not p.rel_path.startswith("01_Canon_and_Divergence/Sources/"):
            if _CJK_PATTERN.search(body):
                findings.append(
                    Finding(
                        code="VAL010",
                        path=p.rel_path,
                        message="CJK characters detected outside Sources/. Use Pinyin or English transliteration.",
                    )
                )

        # VAL009: ASCII art in text block
        if "```text\n+--" in body or "```ascii" in body:
            findings.append(
                Finding(
                    code="VAL009",
                    path=p.rel_path,
                    message="ASCII art diagram detected. Use Mermaid fenced code blocks instead.",
                )
            )

        # VAL024: Non-manuscript technical writing style violations
        if p.rel_path.startswith(("02_Story_Bible/", "08_Ledgers/", "Meta/")):
            for idx, line in enumerate(body.splitlines()[:10], start=1):
                if _AI_PREAMBLES.search(line.strip()):
                    findings.append(
                        Finding(
                            code="VAL024",
                            path=p.rel_path,
                            message=f"Line {idx}: Conversational AI preamble detected. Non-manuscript files must start directly with content.",
                        )
                    )
                    break

    return findings


def check_relational_completeness(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    for p in pages:
        body = p.doc.body
        ptype = p.page_type

        # VAL025: Power System missing Costs & Absolute Limitations
        if ptype == "power_system":
            if "Costs & Absolute Limitations" not in body and "Limitations" not in body:
                findings.append(
                    Finding(
                        code="VAL025",
                        path=p.rel_path,
                        message="Power System missing mandatory 'Costs & Absolute Limitations' section (Sanderson's First Law).",
                    )
                )

        # VAL025: Faction missing Secret Agenda
        if ptype == "faction":
            if "Secret Agenda" not in body and "True Motives" not in body:
                findings.append(
                    Finding(
                        code="VAL025",
                        path=p.rel_path,
                        message="Faction missing mandatory 'Secret Agenda & True Motives' section.",
                    )
                )

        # VAL026: Character missing Settei Visual HUD or Voice & Mannerisms
        if ptype == "character":
            if "Settei" not in body and "Visual HUD" not in body:
                findings.append(
                    Finding(
                        code="VAL026",
                        path=p.rel_path,
                        message="Character missing mandatory 'Settei & Visual HUD' section.",
                        severity="warning",
                    )
                )
            if "Voice & Mannerisms" not in body and "Voice" not in body:
                findings.append(
                    Finding(
                        code="VAL026",
                        path=p.rel_path,
                        message="Character missing mandatory 'Voice & Mannerisms' section.",
                        severity="warning",
                    )
                )

        # VAL013 & VAL016: Baseline missing negative boundary or Canon Basis (supports en and pt-BR)
        if ptype == "baseline":
            has_neg = any(
                k in body
                for k in ("What it does NOT establish", "Negative Boundary", "NÃO estabelece", "NÃO Estabelece", "Fronteiras Negativas")
            )
            if not has_neg:
                findings.append(
                    Finding(
                        code="VAL013",
                        path=p.rel_path,
                        message="Baseline missing 'What it does NOT establish' negative boundary section.",
                    )
                )
            has_basis = any(
                k in body
                for k in (
                    "Canon Basis",
                    "Verbatim Evidence",
                    "Source Grounding",
                    "Sources Cited",
                    "Fatos Canônicos",
                    "Base Canônica",
                    "Verdade Canônica",
                )
            )
            if not has_basis:
                findings.append(
                    Finding(
                        code="VAL016",
                        path=p.rel_path,
                        message="Baseline missing 'Canon Basis' section.",
                    )
                )

    return findings


def check_ledgers_and_continuity(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    # VAL019: POD missing link to CAN- baseline
    for p in pages:
        if p.page_type == "pod":
            has_can_link = any(link.startswith("CAN-") for link in p.links)
            if not has_can_link:
                findings.append(
                    Finding(
                        code="VAL019",
                        path=p.rel_path,
                        message="Point of Divergence (POD) must explicitly link to the CAN- baseline it diverges from.",
                    )
                )

    # VAL028: Foreshadowing ledger overdue items check
    fsh_file = vault.root / "08_Ledgers" / "LDG-Foreshadowing.md"
    if fsh_file.is_file():
        text = read_text(fsh_file)
        if "overdue" in text.lower():
            findings.append(
                Finding(
                    code="VAL028",
                    path="08_Ledgers/LDG-Foreshadowing.md",
                    message="Foreshadowing ledger contains overdue unresolved clues.",
                    severity="warning",
                )
            )

    return findings


def check_sources_and_verbatim(vault: Vault, pages: list[Page]) -> list[Finding]:
    from narr.ingest import norm_quote

    findings: list[Finding] = []
    sources_meta = vault.root / "01_Canon_and_Divergence" / "Sources" / ".meta.json"
    hashes: dict[str, Any] = {}
    if sources_meta.is_file():
        try:
            hashes = json.loads(read_text(sources_meta))
        except Exception:
            pass

    # VAL023: Frozen raw sources must be registered in .meta.json
    sources_dir = vault.root / "01_Canon_and_Divergence" / "Sources"
    if sources_dir.is_dir():
        for src in sorted(sources_dir.glob("*.*")):
            if not src.name.endswith(".json") and src.is_file() and src.stem.startswith("SRC-"):
                stem = src.stem
                if stem not in hashes and src.name not in hashes:
                    findings.append(
                        Finding(
                            code="VAL023",
                            path=f"01_Canon_and_Divergence/Sources/{src.name}",
                            message="Frozen source lacking sha256 hash in .meta.json. Run narr ingest close.",
                            severity="warning",
                        )
                    )

    # Pre-index all available source texts
    source_texts: dict[str, str] = {}
    for base in [vault.sources_dir, vault.sources_inbox_dir]:
        if base.is_dir():
            for sf in base.glob("*.*"):
                if sf.is_file() and sf.name != ".meta.json":
                    content = read_text_or_none(sf)
                    if content:
                        source_texts[sf.stem] = content

    for p in pages:
        # VAL030: Baselines naming and type invariant
        if p.rel_path.startswith("01_Canon_and_Divergence/Baselines/") and not p.rel_path.endswith("TMP-Baseline.md"):
            if not p.path.name.startswith("CAN-"):
                findings.append(
                    Finding(
                        code="VAL030",
                        path=p.rel_path,
                        message="Baseline page must start with prefix 'CAN-'.",
                        severity="error",
                    )
                )
            if p.page_type != "baseline":
                findings.append(
                    Finding(
                        code="VAL030",
                        path=p.rel_path,
                        message=f"Baseline page must have 'type: baseline', got '{p.page_type}'.",
                        severity="error",
                    )
                )

        # VAL031: PODs naming and type invariant
        if p.rel_path.startswith("01_Canon_and_Divergence/PODs/") and not p.rel_path.endswith("TMP-POD.md"):
            if not p.path.name.startswith("POD-"):
                findings.append(
                    Finding(
                        code="VAL031",
                        path=p.rel_path,
                        message="Divergence point page must start with prefix 'POD-'.",
                        severity="error",
                    )
                )
            if p.page_type not in ("pod", "divergence_point"):
                findings.append(
                    Finding(
                        code="VAL031",
                        path=p.rel_path,
                        message=f"Divergence point page must have 'type: pod', got '{p.page_type}'.",
                        severity="error",
                    )
                )

        # SRC001: Validate that cited source_ids exist in Sources/ or Sources/inbox/
        sids = p.doc.meta.get("source_ids") or []
        if isinstance(sids, str):
            sids = [sids]
        for sid in sids:
            sid_str = str(sid)
            if sid_str.startswith("SRC-") and sid_str not in source_texts:
                # Ignore placeholders in templates
                if "Meta/Templates" not in p.rel_path:
                    findings.append(
                        Finding(
                            code="SRC001",
                            path=p.rel_path,
                            message=f"Cited source ID '{sid_str}' not found in Sources/ or Sources/inbox/.",
                            severity="error",
                        )
                    )

        # QUO001: Verbatim quote verification in Baselines
        if p.rel_path.startswith("01_Canon_and_Divergence/Baselines/") and "Meta/Templates" not in p.rel_path:
            haystacks = [norm_quote(source_texts[s]) for s in sids if s in source_texts]
            if haystacks:
                for q in p.verbatim_quotes:
                    nq = norm_quote(q)
                    if not any(nq in h for h in haystacks):
                        findings.append(
                            Finding(
                                code="QUO001",
                                path=p.rel_path,
                                message=f'Literal quote not found in any cited source: *"{q}"*',
                                severity="error",
                            )
                        )

    return findings


def check_worldbuilder_disease(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    # WBL001: More than 10 lore entities without chapter reference
    lore_pages = [p for p in pages if p.rel_path.startswith("02_Story_Bible/")]
    chapters = [p for p in pages if p.rel_path.startswith("04_Manuscript/")]
    if len(chapters) == 0 and len(lore_pages) > 15:
        findings.append(
            Finding(
                code="WBL001",
                path="02_Story_Bible",
                message=f"Premature Worldbuilding Warning: {len(lore_pages)} lore pages exist but zero manuscript chapters have been written. Respect the 10/90 Iceberg Ratio.",
                severity="warning",
            )
        )
    return findings


def check_manuscript_translation_parity(vault: Vault, pages: list[Page]) -> list[Finding]:
    findings: list[Finding] = []
    # MSC004: Translation parity check between pt-BR and es chapters
    es_chapters = [p for p in pages if p.rel_path.startswith("04_Manuscript/es/Chapters/")]
    pt_chapters = {p.path.stem.split("_")[0]: p for p in pages if p.rel_path.startswith("04_Manuscript/pt-BR/Chapters/")}

    for es_p in es_chapters:
        c_prefix = es_p.path.stem.split("_")[0]
        if c_prefix in pt_chapters:
            pt_p = pt_chapters[c_prefix]
            pt_paras = [b.strip() for b in pt_p.doc.body.split("\n\n") if b.strip()]
            es_paras = [b.strip() for b in es_p.doc.body.split("\n\n") if b.strip()]
            diff = abs(len(pt_paras) - len(es_paras))
            tolerance = max(8, int(0.10 * len(pt_paras)))
            if diff > tolerance:
                findings.append(
                    Finding(
                        code="MSC004",
                        path=es_p.rel_path,
                        message=f"Translation divergence: {len(es_paras)} paragraphs in es vs {len(pt_paras)} in pt-BR (diff: {diff}, tolerance: {tolerance}).",
                        severity="warning",
                    )
                )
    return findings


def check_baseline_ontological_purity(vault: Vault, pages: list[Page]) -> list[Finding]:
    """VAL032: Ensure CAN- baselines maintain strict ontological purity and do not mix characters into worldbuilding (DEF-06, DEF-07)."""
    findings: list[Finding] = []
    char_markers = ("_abilities", "_profile", "_character", "chr-")
    for p in pages:
        if p.rel_path.startswith("01_Canon_and_Divergence/Baselines/") and "Meta/Templates" not in p.rel_path:
            raw_sids = p.doc.meta.get("source_ids") or p.doc.meta.get("sources") or []
            if isinstance(raw_sids, str):
                sids = [raw_sids]
            elif isinstance(raw_sids, list):
                sids = raw_sids
            else:
                sids = []

            # Identify character-specific source files using fandom-neutral tokens
            char_sources = [s for s in sids if any(k in str(s).lower() for k in char_markers)]

            is_char_baseline = (
                "CAN-CHR-" in p.rel_path
                or "Character" in p.title
                or any(k in p.rel_path.lower() for k in ["character", "lineage", "protagonist", "antagonist"])
                or p.page_type == "character"
            )
            if char_sources and not is_char_baseline:
                findings.append(
                    Finding(
                        code="VAL032",
                        path=p.rel_path,
                        message=f"Ontological impurity: Character-specific source(s) {char_sources} cited in non-character baseline '{p.title}'. Separate character profiles from macro-worldbuilding systems.",
                        severity="error",
                    )
                )
    return findings

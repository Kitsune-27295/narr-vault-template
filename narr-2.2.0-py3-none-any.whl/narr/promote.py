"""Sandbox distillation and promotion to authoritative Story Bible layers (ADR-004 & V1 sanitization)."""

from __future__ import annotations

import re
from pathlib import Path

import yaml

from narr.frontmatter import parse
from narr.vault import Vault, VaultError, read_text, read_text_or_none, write_text_atomic

CJK_PATTERN = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]")
WIKILINK_PATTERN = re.compile(r"\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|([^\]]+))?\]\]")

PROHIBITED_METATEXT_PATTERNS = [
    r"\bauthor['']?s note\b",
    r"\bmeta-commentary\b",
    r"\bstream[- ]of[- ]thought\b",
    r"\bideation dump\b",
    r"\brascunho bruto\b",
    r"\bdivagacao\b",
    r"\bcomo se fosse no anime\b",
    r"\bdragon ball\b",
]


def check_sandbox_cleanliness(file_path: Path, vault: Vault | None = None) -> list[str]:
    """Validate that candidate note leaving 06_Ideation_and_Unblocking is distilled and sanitized.

    Args:
        file_path: Absolute or vault-relative path to the candidate note.
        vault: Optional Vault instance to validate referenced wikilinks against existing entities.

    Returns:
        List of cleanliness and invariant violation messages (empty if compliant).
    """
    findings: list[str] = []
    if not file_path.is_file():
        return [f"File not found: {file_path}"]

    if " " in file_path.name:
        findings.append(f"Filename contains spaces: '{file_path.name}' (Zero-Space invariant)")

    content = read_text_or_none(file_path) or ""
    if CJK_PATTERN.search(content):
        findings.append("Contains raw CJK characters (Zero-CJK invariant). Use Pinyin/Romaji.")

    for pat in PROHIBITED_METATEXT_PATTERNS:
        matches = re.findall(pat, content, flags=re.IGNORECASE)
        if matches:
            findings.append(f"Contains un-distilled meta-analogy or sandbox chatter matching '{pat}': {matches[:2]}")

    if not content.startswith("---"):
        findings.append("Missing YAML frontmatter block")

    # Validate broken wikilinks if vault context is provided
    if vault is not None:
        existing_stems = {entry.name.split(".", 1)[0] for _, entry in vault.entries(".md")}
        for m in WIKILINK_PATTERN.finditer(content):
            target = m.group(1).strip()
            # Ignore self-references, templates, or links to the candidate file itself
            if target and target != file_path.stem and target not in existing_stems:
                findings.append(f"Broken wikilink: '[[{target}]]' resolves to no entity in the vault.")

    return findings


def promote_note(
    vault: Vault,
    source_file: Path,
    target_zone: str,
    target_prefix: str,
    slug: str,
    title: str,
    archive_source: bool = True,
) -> Path:
    """Promote sanitized sandbox note to authoritative layer.

    Args:
        vault: Target narrative vault instance.
        source_file: Path to candidate note in 06_Ideation_and_Unblocking/.
        target_zone: Destination zone name (characters, factions, locations, powers, cosmology, lore, pods).
        target_prefix: Entity prefix (e.g. CHR, FAC, LOC, PWR, SYS, SCP, POD, LOR).
        slug: Valid filename slug for the entity.
        title: Formal canonical title.
        archive_source: If True, moves the source file to 06_Ideation_and_Unblocking/archive/.

    Returns:
        Path to the promoted note in the authoritative layer.

    Raises:
        VaultError: If note fails cleanliness checks, zone is invalid, or destination file exists.
    """
    findings = check_sandbox_cleanliness(source_file, vault=vault)
    if findings:
        raise VaultError(f"Cannot promote note with cleanliness errors: {', '.join(findings)}")

    zone_map = {
        "characters": vault.root / "02_Story_Bible" / "Characters",
        "factions": vault.root / "02_Story_Bible" / "Factions",
        "locations": vault.root / "02_Story_Bible" / "Locations",
        "powers": vault.root / "02_Story_Bible" / "Powers_and_Systems",
        "cosmology": vault.root / "02_Story_Bible" / "Cosmology_and_Godhood",
        "lore": vault.root / "02_Story_Bible" / "Lore",
        "pods": vault.root / "01_Canon_and_Divergence" / "PODs",
    }

    target_dir = zone_map.get(target_zone.lower())
    if not target_dir:
        raise VaultError(f"Target zone '{target_zone}' invalid. Choose from: {list(zone_map.keys())}")

    target_dir.mkdir(parents=True, exist_ok=True)
    target_filename = f"{target_prefix}-{slug}.md"
    dest = target_dir / target_filename
    if dest.exists():
        raise VaultError(f"Destination {vault.rel(dest)} already exists.")

    raw = read_text(source_file)
    doc = parse(raw)
    doc.meta["uid"] = f"{target_prefix}-{slug}"
    doc.meta["title"] = title
    doc.meta["status"] = "active"

    new_fm = yaml.safe_dump(doc.meta, sort_keys=False, allow_unicode=True).strip()
    new_content = f"---\n{new_fm}\n---\n{doc.body}"
    write_text_atomic(dest, new_content)

    if archive_source and source_file.is_file():
        archive_dir = vault.root / "06_Ideation_and_Unblocking" / "archive"
        archive_dir.mkdir(parents=True, exist_ok=True)
        archive_dest = archive_dir / source_file.name
        if archive_dest.exists():
            archive_dest.unlink()
        source_file.rename(archive_dest)

    return dest

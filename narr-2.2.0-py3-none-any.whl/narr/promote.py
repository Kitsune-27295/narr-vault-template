"""Sandbox distillation and promotion to authoritative Story Bible layers (ADR-004 & V1 sanitization)."""

from __future__ import annotations

import re
from pathlib import Path

from narr.frontmatter import parse
from narr.vault import Vault, VaultError, read_text, read_text_or_none, write_text_atomic

CJK_PATTERN = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]")

PROHIBITED_METATEXT_PATTERNS = [
    r"\bauthor['']?s note\b",
    r"\bmeta-commentary\b",
    r"\bstream[- ]of[- ]thought\b",
    r"\bideation dump\b",
    r"\brascunho bruto\b",
    r"\bdivagacao\b",
    r"\bcomo se fosse no anime\b",
    r"\bdragon ball\b",
]


def check_sandbox_cleanliness(file_path: Path) -> list[str]:
    """Validate that candidate note leaving 06_Ideation_and_Unblocking is distilled and sanitized."""
    findings: list[str] = []
    if not file_path.is_file():
        return [f"File not found: {file_path}"]

    if " " in file_path.name:
        findings.append(f"Filename contains spaces: '{file_path.name}' (Zero-Space invariant)")

    content = read_text_or_none(file_path) or ""
    if CJK_PATTERN.search(content):
        findings.append("Contains raw CJK characters (Zero-CJK invariant). Use Pinyin/Romaji.")

    for pat in PROHIBITED_METATEXT_PATTERNS:
        matches = re.findall(pat, content, flags=re.IGNORECASE)
        if matches:
            findings.append(f"Contains un-distilled meta-analogy or sandbox chatter matching '{pat}': {matches[:2]}")

    if not content.startswith("---"):
        findings.append("Missing YAML frontmatter block")

    return findings


def promote_note(
    vault: Vault,
    source_file: Path,
    target_zone: str,
    target_prefix: str,
    slug: str,
    title: str,
) -> Path:
    """Promote sanitized sandbox note to authoritative layer."""
    findings = check_sandbox_cleanliness(source_file)
    if findings:
        raise VaultError(f"Cannot promote note with cleanliness errors: {', '.join(findings)}")

    zone_map = {
        "characters": vault.root / "02_Story_Bible" / "Characters",
        "factions": vault.root / "02_Story_Bible" / "Factions",
        "locations": vault.root / "02_Story_Bible" / "Locations",
        "powers": vault.root / "02_Story_Bible" / "Powers_and_Systems",
        "cosmology": vault.root / "02_Story_Bible" / "Cosmology_and_Godhood",
        "pods": vault.root / "01_Canon_and_Divergence" / "PODs",
    }

    target_dir = zone_map.get(target_zone.lower())
    if not target_dir:
        raise VaultError(f"Target zone '{target_zone}' invalid. Choose from: {list(zone_map.keys())}")

    target_dir.mkdir(parents=True, exist_ok=True)
    target_filename = f"{target_prefix}-{slug}.md"
    dest = target_dir / target_filename
    if dest.exists():
        raise VaultError(f"Destination {vault.rel(dest)} already exists.")

    raw = read_text(source_file)
    doc = parse(raw)
    doc.meta["uid"] = f"{target_prefix}-{slug}"
    doc.meta["title"] = title
    doc.meta["status"] = "active"

    import yaml

    new_fm = yaml.safe_dump(doc.meta, sort_keys=False, allow_unicode=True).strip()
    new_content = f"---\n{new_fm}\n---\n{doc.body}"
    write_text_atomic(dest, new_content)

    return dest

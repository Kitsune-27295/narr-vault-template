"""Link graph analysis, role classification, and directional orphan detection (Second_brain graph.py parity / ADR-038)."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from narr.pages import Page, is_placeholder
from narr.vault import Vault

Role = Literal["hub", "connector", "leaf", "orphan"]
Direction = Literal["incoming", "outgoing", "both"]
HUB_THRESHOLD = 5


@dataclass
class GraphReport:
    total_pages: int
    total_links: int
    dead_links: list[tuple[str, str]]  # (source_path, target)
    orphans: list[tuple[str, Role, int, int]]  # (path, role, inbound, outbound)
    hubs: list[tuple[str, int]]  # (title/stem, inbound_count)
    roles: dict[str, int]  # role -> count


def analyze_graph(vault: Vault, orphan_filter: Direction = "incoming") -> GraphReport:
    """Analyze the complete wikilink graph with node roles and directional orphan filtering."""
    pages: list[Page] = []
    page_by_stem: dict[str, Page] = {}
    stems: set[str] = set()

    for rel_path, entry in vault.entries(".md"):
        p = Page.load(vault.root / rel_path, rel_path)
        if p:
            pages.append(p)
            stem = Path(rel_path).stem.lower()
            stems.add(stem)
            page_by_stem[stem] = p
            if p.title:
                stems.add(p.title.lower())
            if p.uid:
                stems.add(p.uid.lower())

    inbound_map: dict[str, set[str]] = defaultdict(set)
    outbound_map: dict[str, set[str]] = defaultdict(set)
    dead_links: list[tuple[str, str]] = []
    total_links = 0

    for p in pages:
        p_stem = Path(p.rel_path).stem.lower()
        for link in p.links:
            total_links += 1
            clean_link = link.split("|", 1)[0].split("#", 1)[0].strip().lower()
            if clean_link in stems:
                inbound_map[clean_link].add(p_stem)
                outbound_map[p_stem].add(clean_link)
            else:
                if not p.rel_path.startswith("Meta/Templates") and not is_placeholder(link):
                    dead_links.append((p.rel_path, link))

    # Node Roles
    roles_count: dict[str, int] = {"hub": 0, "connector": 0, "leaf": 0, "orphan": 0}
    hubs: list[tuple[str, int]] = []
    orphans: list[tuple[str, Role, int, int]] = []

    for p in pages:
        if p.rel_path.startswith("Meta/Templates"):
            continue
        p_stem = Path(p.rel_path).stem.lower()
        in_count = len(inbound_map.get(p_stem, set()))
        out_count = len(outbound_map.get(p_stem, set()))

        role: Role
        if in_count == 0 and out_count == 0 or in_count == 0:
            role = "orphan"
        elif in_count >= HUB_THRESHOLD:
            role = "hub"
            hubs.append((p.title or Path(p.rel_path).stem, in_count))
        elif out_count > 0:
            role = "connector"
        else:
            role = "leaf"

        roles_count[role] = roles_count.get(role, 0) + 1

        # Directional filter for orphan listing
        is_orphan = False
        if (
            orphan_filter == "incoming"
            and in_count == 0
            or orphan_filter == "outgoing"
            and out_count == 0
            or orphan_filter == "both"
            and in_count == 0
            and out_count == 0
        ):
            is_orphan = True

        if is_orphan:
            orphans.append((p.rel_path, role, in_count, out_count))

    hubs.sort(key=lambda x: x[1], reverse=True)

    return GraphReport(
        total_pages=len(pages),
        total_links=total_links,
        dead_links=dead_links,
        orphans=orphans,
        hubs=hubs,
        roles=roles_count,
    )

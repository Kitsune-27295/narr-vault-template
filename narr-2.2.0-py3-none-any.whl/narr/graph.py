"""Link graph analysis, role classification, and directional orphan detection (Second_brain graph.py parity / ADR-038)."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from narr.pages import Page, is_placeholder
from narr.vault import Vault

Role = Literal["hub", "connector", "leaf", "orphan"]
Direction = Literal["incoming", "outgoing", "both"]
HUB_THRESHOLD = 5


@dataclass
class GraphReport:
    """Detailed topological and relational analysis of the vault note graph.

    Attributes:
        total_pages: Total number of scanned markdown pages.
        total_links: Total count of outbound wikilinks.
        dead_links: List of (source_path, target) tuples pointing to missing notes.
        orphans: List of (path, role, inbound, outbound) tuples for orphan nodes.
        hubs: List of (title/stem, inbound_count) for nodes with >= 5 incoming links.
        roles: Mapping of role name ('hub', 'connector', 'leaf', 'orphan') to counts.
        cycles: List of circular reference paths discovered in the link graph.
    """

    total_pages: int
    total_links: int
    dead_links: list[tuple[str, str]]  # (source_path, target)
    orphans: list[tuple[str, Role, int, int]]  # (path, role, inbound, outbound)
    hubs: list[tuple[str, int]]  # (title/stem, inbound_count)
    roles: dict[str, int]  # role -> count
    cycles: list[list[str]] = field(default_factory=list)


def detect_cycles(vault: Vault, pages: list[Page] | None = None) -> list[list[str]]:
    """Detect circular references / cycles in the vault note link graph.

    Args:
        vault: Story bible vault instance.
        pages: Optional pre-loaded pages to avoid redundant disk reads.

    Returns:
        List of cycle node paths (e.g. [['CHR-Leaf', 'CHR-Connector', 'CHR-Leaf']]).
    """
    stems: dict[str, str] = {}
    valid_pages: list[Page] = []

    if pages is None:
        for rel_path, entry in vault.entries(".md"):
            if rel_path.startswith("Meta/Templates"):
                continue
            p = Page.load(vault.root / rel_path, rel_path)
            if p:
                valid_pages.append(p)
    else:
        valid_pages = [p for p in pages if not p.rel_path.startswith("Meta/Templates")]

    for p in valid_pages:
        canon = Path(p.rel_path).stem
        stems[canon.lower()] = canon
        if p.title:
            stems[p.title.lower()] = canon
        if p.uid:
            stems[p.uid.lower()] = canon

    adj: dict[str, set[str]] = defaultdict(set)
    for p in valid_pages:
        src = Path(p.rel_path).stem
        for link in p.links:
            clean = link.split("|", 1)[0].split("#", 1)[0].strip().lower()
            if clean in stems and stems[clean] != src:
                adj[src].add(stems[clean])

    visited: dict[str, int] = {}  # 0: unvisited, 1: visiting, 2: visited
    cycles: list[list[str]] = []
    path: list[str] = []

    def dfs(node: str) -> None:
        visited[node] = 1
        path.append(node)
        for neighbor in sorted(adj.get(node, set())):
            if visited.get(neighbor, 0) == 1:
                idx = path.index(neighbor)
                cycle = [*path[idx:], neighbor]
                cycles.append(cycle)
            elif visited.get(neighbor, 0) == 0:
                dfs(neighbor)
        path.pop()
        visited[node] = 2

    for node in sorted(adj.keys()):
        if visited.get(node, 0) == 0:
            dfs(node)

    return cycles


def analyze_graph(vault: Vault, orphan_filter: Direction = "incoming") -> GraphReport:
    """Analyze the complete wikilink graph with node roles, directional orphan filtering, and cycles.

    Args:
        vault: Story bible vault instance.
        orphan_filter: Filter direction for orphan nodes ('incoming', 'outgoing', 'both').

    Returns:
        GraphReport containing hubs, roles, dead links, orphans, and cycle paths.
    """
    pages: list[Page] = []
    page_by_stem: dict[str, Page] = {}
    stems: set[str] = set()

    for rel_path, entry in vault.entries(".md"):
        p = Page.load(vault.root / rel_path, rel_path)
        if p:
            pages.append(p)
            stem = Path(rel_path).stem.lower()
            stems.add(stem)
            page_by_stem[stem] = p
            if p.title:
                stems.add(p.title.lower())
            if p.uid:
                stems.add(p.uid.lower())

    inbound_map: dict[str, set[str]] = defaultdict(set)
    outbound_map: dict[str, set[str]] = defaultdict(set)
    dead_links: list[tuple[str, str]] = []
    total_links = 0

    for p in pages:
        p_stem = Path(p.rel_path).stem.lower()
        for link in p.links:
            total_links += 1
            clean_link = link.split("|", 1)[0].split("#", 1)[0].strip().lower()
            if clean_link in stems:
                inbound_map[clean_link].add(p_stem)
                outbound_map[p_stem].add(clean_link)
            else:
                if not p.rel_path.startswith("Meta/Templates") and not is_placeholder(link):
                    dead_links.append((p.rel_path, link))

    # Node Roles
    roles_count: dict[str, int] = {"hub": 0, "connector": 0, "leaf": 0, "orphan": 0}
    hubs: list[tuple[str, int]] = []
    orphans: list[tuple[str, Role, int, int]] = []

    for p in pages:
        if p.rel_path.startswith("Meta/Templates"):
            continue
        p_stem = Path(p.rel_path).stem.lower()
        in_count = len(inbound_map.get(p_stem, set()))
        out_count = len(outbound_map.get(p_stem, set()))

        role: Role
        if (in_count == 0 and out_count == 0) or in_count == 0:
            role = "orphan"
        elif in_count >= HUB_THRESHOLD:
            role = "hub"
            hubs.append((p.title or Path(p.rel_path).stem, in_count))
        elif out_count > 0:
            role = "connector"
        else:
            role = "leaf"

        roles_count[role] = roles_count.get(role, 0) + 1

        # Directional filter for orphan listing
        is_orphan = False
        if (
            (orphan_filter == "incoming" and in_count == 0)
            or (orphan_filter == "outgoing" and out_count == 0)
            or (orphan_filter == "both" and in_count == 0 and out_count == 0)
        ):
            is_orphan = True

        if is_orphan:
            orphans.append((p.rel_path, role, in_count, out_count))

    hubs.sort(key=lambda x: x[1], reverse=True)
    cycles = detect_cycles(vault, pages=pages)

    return GraphReport(
        total_pages=len(pages),
        total_links=total_links,
        dead_links=dead_links,
        orphans=orphans,
        hubs=hubs,
        roles=roles_count,
        cycles=cycles,
    )

"""Canon source capture, FTS candidate planning, quote verification, and freeze-to-ledger ingest (ADR-004 & Second_brain parity)."""

from __future__ import annotations

import hashlib
import json
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from narr.pages import Page, extract_verbatim_quotes
from narr.search import search, sync_index
from narr.vault import Vault, VaultError, is_safe_name, read_text, read_text_or_none, slugify, write_text_atomic

GOLDILOCKS_MIN_BYTES = 3_000  # 3 KB
GOLDILOCKS_MAX_BYTES = 15_000  # 15 KB

_TYPOGRAPHY = str.maketrans(
    {
        "\u201c": '"',
        "\u201d": '"',
        "\u2018": "'",
        "\u2019": "'",
        "\u00ab": '"',
        "\u00bb": '"',
        "\u2014": "-",
        "\u2013": "-",
        "\u2026": "...",
    }
)


def norm_quote(text: str) -> str:
    """Normalize text for quote matching: NFKC, straight quotes, lowercase, whitespace folding.

    Args:
        text: Input string with potential typographical quotes, dashes or excess whitespace.

    Returns:
        Cleaned, normalized lowercase string.
    """
    norm = unicodedata.normalize("NFKC", text).translate(_TYPOGRAPHY)
    return " ".join(norm.split()).lower()


def sha256_file(path: Path) -> str:
    """Compute SHA-256 hash of a file.

    Args:
        path: Path to target file.

    Returns:
        Hexadecimal SHA-256 digest string.
    """
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    """Compute SHA-256 hash of a string.

    Args:
        text: Input string.

    Returns:
        Hexadecimal SHA-256 digest string.
    """
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_all_pages(vault: Vault) -> list[Page]:
    """Load all markdown pages from the vault.

    Args:
        vault: Target story bible Vault instance.

    Returns:
        List of parsed Page objects.
    """
    pages: list[Page] = []
    for path in vault.markdown_files():
        rel = vault.rel(path)
        p = Page.load(path, rel)
        if p:
            pages.append(p)
    return pages


def find_source_file(vault: Vault, source_id: str) -> tuple[Path | None, bool]:
    """Return (Path, is_frozen) for source_id, supporting both stem and filename forms.

    Args:
        vault: Story bible Vault instance.
        source_id: Source identifier (e.g. 'SRC-20261019-name' or 'SRC-20261019-name.md').

    Returns:
        Tuple of (Path to source file or None, is_frozen boolean).
    """
    clean_sid = Path(source_id).stem if source_id.endswith((".md", ".txt", ".html", ".htm", ".pdf")) else source_id
    for base, is_frozen in [(vault.sources_dir, True), (vault.sources_inbox_dir, False)]:
        if not base.exists():
            continue
        for p in sorted(base.glob(f"{clean_sid}.*")):
            if not p.name.endswith(".json"):
                return p, is_frozen
    return None, False


def read_sources_meta(vault: Vault) -> dict[str, Any]:
    """Read central Sources/.meta.json metadata file.

    Args:
        vault: Story bible Vault instance.

    Returns:
        Dictionary of source metadata entries keyed by source ID.
    """
    meta_path = vault.sources_meta_path
    if meta_path.is_file():
        try:
            return json.loads(read_text(meta_path)) or {}
        except Exception:
            return {}
    return {}


def write_sources_meta(vault: Vault, data: dict[str, Any]) -> None:
    """Atomically write central Sources/.meta.json metadata file.

    Args:
        vault: Story bible Vault instance.
        data: Metadata dictionary to persist.
    """
    write_text_atomic(vault.sources_meta_path, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def _freeze_source_files(vault: Vault, src_file: Path) -> tuple[Path, str]:
    """Relocate source file and any companion sidecar from inbox to Sources/, returning final path and hash.

    Args:
        vault: Story bible Vault instance.
        src_file: Current path to the source file (in inbox or already in Sources/).

    Returns:
        Tuple of (final_destination_path, sha256_hash).
    """
    sha = sha256_file(src_file)
    final_dest = vault.sources_dir / src_file.name
    if src_file.parent != vault.sources_dir:
        inbox_sidecar = vault.sources_inbox_dir / f"{src_file.stem}.meta.json"
        src_file.replace(final_dest)
        if inbox_sidecar.is_file():
            inbox_sidecar.replace(vault.sources_dir / inbox_sidecar.name)
    return final_dest, sha


def capture_source(
    vault: Vault,
    file_path: Path,
    url: str | None = None,
    custom_id: str | None = None,
) -> str:
    """Capture raw source file into Sources/inbox/ with metadata.

    Args:
        vault: Story bible Vault instance.
        file_path: Local file to copy into inbox.
        url: Optional original URL.
        custom_id: Optional explicit ID (must start with 'SRC-').

    Returns:
        Generated or validated source ID string.

    Raises:
        VaultError: If file not found or custom ID is malformed.
    """
    if not file_path.is_file():
        raise VaultError(f"Source file not found: {file_path}")

    content = file_path.read_bytes()
    sha = hashlib.sha256(content).hexdigest()

    if custom_id:
        if not custom_id.startswith("SRC-") or not is_safe_name(custom_id):
            raise VaultError(f"Custom ID must start with 'SRC-' and be safe filename, got {custom_id}")
        source_id = custom_id
    else:
        date_str = datetime.now().strftime("%Y%m%d")
        slug = slugify(file_path.stem)
        source_id = f"SRC-{date_str}-{slug}"

    ext = file_path.suffix.lower() or ".md"
    dest_name = f"{source_id}{ext}"
    dest_path = vault.sources_inbox_dir / dest_name

    dest_path.write_bytes(content)

    meta = read_sources_meta(vault)
    meta[source_id] = {
        "source_id": source_id,
        "filename": dest_name,
        "captured_at": datetime.now().isoformat(),
        "url": url or "",
        "sha256": sha,
        "status": "inbox",
        "size_bytes": len(content),
    }
    write_sources_meta(vault, meta)
    return source_id


def get_pending(vault: Vault) -> list[dict[str, Any]]:
    """List uncompiled sources: all in inbox, plus frozen sources not cited by any baseline.

    Args:
        vault: Story bible Vault instance.

    Returns:
        List of dictionaries with source_id, status, filename, and rel_path.
    """
    pages = load_all_pages(vault)
    all_cited_sources: set[str] = set()
    for p in pages:
        sids = p.doc.meta.get("source_ids") or []
        if isinstance(sids, list):
            for s in sids:
                all_cited_sources.add(str(s))
        elif isinstance(sids, str):
            all_cited_sources.add(sids)

    pending: list[dict[str, Any]] = []

    # Inbox sources
    if vault.sources_inbox_dir.exists():
        for sf in sorted(vault.sources_inbox_dir.iterdir()):
            if sf.is_file() and not sf.name.startswith(".") and not sf.name.endswith(".meta.json"):
                sid = sf.stem
                pending.append(
                    {
                        "source_id": sid,
                        "status": "inbox",
                        "filename": sf.name,
                        "path": vault.rel(sf),
                    }
                )

    # Frozen sources without citations
    meta = read_sources_meta(vault)
    if vault.sources_dir.exists():
        for sf in sorted(vault.sources_dir.iterdir()):
            if sf.is_file() and not sf.name.startswith(".") and not sf.name.endswith(".json") and sf.stem.startswith("SRC-"):
                sid = sf.stem
                if sid not in all_cited_sources and meta.get(sid, {}).get("status") != "skipped":
                    pending.append(
                        {
                            "source_id": sid,
                            "status": "frozen",
                            "filename": sf.name,
                            "path": vault.rel(sf),
                        }
                    )

    return pending


def plan_ingest(vault: Vault, source_id: str, limit: int = 10) -> dict[str, Any]:
    """Generate context plan for ingesting a source using FTS candidate search.

    Args:
        vault: Story bible Vault instance.
        source_id: Source ID to plan integration for.
        limit: Maximum candidate baselines to return.

    Returns:
        Dictionary containing source details, candidates, and Goldilocks sizing advice.

    Raises:
        VaultError: If source file cannot be found in inbox or Sources/.
    """
    src_file, is_frozen = find_source_file(vault, source_id)
    if not src_file:
        raise VaultError(f"Source {source_id} not found in Sources/ or Sources/inbox/")

    clean_sid = src_file.stem
    raw_text = read_text_or_none(src_file) or ""
    # Extract candidate title
    lines = raw_text.splitlines()
    title = clean_sid
    for line in lines:
        if line.startswith("# "):
            title = line[2:].strip()
            break

    pages = load_all_pages(vault)
    citing: list[str] = []
    for p in pages:
        sids = p.doc.meta.get("source_ids") or []
        if clean_sid in sids or (isinstance(sids, str) and clean_sid == sids):
            citing.append(p.rel_path)

    # Search existing baselines & story bible for candidate integration targets
    hits = search(vault, query=title if len(title) > 3 else clean_sid, limit=limit * 2)
    candidate_baselines = [
        {"title": h.title, "path": h.rel_path, "score": h.score, "snippet": h.snippet}
        for h in hits
        if "Baselines" in h.rel_path or "Story_Bible" in h.rel_path
    ][:limit]

    return {
        "source_id": clean_sid,
        "title": title,
        "status": "frozen" if is_frozen else "inbox",
        "file_path": vault.rel(src_file),
        "size_chars": len(raw_text),
        "right_sizing_guidance": "Target 3 KB to 15 KB per baseline, consolidating 2 to 5 closely related or versioned sources. Avoid 1:1 micro-stubs.",
        "currently_citing_pages": sorted(citing),
        "candidate_pages_to_integrate": candidate_baselines,
    }


@dataclass
class IngestFinding:
    code: str
    severity: str
    path: str
    message: str


def close_ingest(vault: Vault, source_id: str, dry_run: bool = False, pages: list[Page] | None = None) -> dict[str, Any]:
    """Validate quotes and links on citing baselines, check Goldilocks sizing, then freeze source and log.

    Args:
        vault: Story bible Vault instance.
        source_id: Source ID to validate and close.
        dry_run: When True, checks validity without moving files or logging.
        pages: Optional cached list of vault pages.

    Returns:
        Result dictionary containing success boolean, quotes_verified count, citing pages, and findings.

    Raises:
        VaultError: If source is not found, binary, or not cited by any vault baseline.
    """
    src_file, _is_frozen = find_source_file(vault, source_id)
    if not src_file:
        raise VaultError(f"Source {source_id} not found in Sources/ or Sources/inbox/")

    clean_sid = src_file.stem
    raw_source = read_text_or_none(src_file)
    if raw_source is None:
        raise VaultError(f"Source file {src_file.name} is binary or unreadable UTF-8")

    norm_source = norm_quote(raw_source)

    if pages is None:
        pages = load_all_pages(vault)
    citing_pages: list[Page] = []
    for p in pages:
        sids = p.doc.meta.get("source_ids") or []
        if clean_sid in sids or (isinstance(sids, str) and clean_sid == sids):
            citing_pages.append(p)

    if not citing_pages:
        raise VaultError(
            f"No page in vault cites source '{clean_sid}' in 'source_ids: [...]'. "
            f"Integrate or create a baseline in 01_Canon_and_Divergence/Baselines/ first."
        )

    findings: list[IngestFinding] = []
    quotes_verified = 0
    sibling_quotes_verified = 0

    # 1. Verify literal quotes *"..."* against source text
    for page in citing_pages:
        page_sids = page.doc.meta.get("source_ids") or []
        if isinstance(page_sids, str):
            page_sids = [page_sids]
        sibling_sources: dict[str, str] = {}
        for sid in page_sids:
            if str(sid) != clean_sid:
                s_file, _ = find_source_file(vault, str(sid))
                if s_file:
                    raw_s = read_text_or_none(s_file)
                    if raw_s:
                        sibling_sources[str(sid)] = norm_quote(raw_s)

        quotes = extract_verbatim_quotes(page.doc.body)
        for q in quotes:
            nq = norm_quote(q)
            if nq in norm_source:
                quotes_verified += 1
            elif any(nq in s_text for s_text in sibling_sources.values()):
                # Grounded in another cited source of this multi-source consolidated baseline
                sibling_quotes_verified += 1
            else:
                findings.append(
                    IngestFinding(
                        code="QUO001",
                        severity="error",
                        path=page.rel_path,
                        message=f'Literal quote not found in cited source {clean_sid} or any sibling cited source: *"{q}"*',
                    )
                )

    # 2. Verify wikilinks in citing pages resolve
    all_titles = {p.title for p in pages} | {p.path.stem for p in pages}
    for page in citing_pages:
        for link in page.links:
            if link not in all_titles and not link.startswith("SRC-"):
                findings.append(
                    IngestFinding(
                        code="LNK001",
                        severity="error",
                        path=page.rel_path,
                        message=f"Dead link [[{link}]] on citing page",
                    )
                )

    # 3. Check Goldilocks Zone (3 KB to 15 KB per ADR-004)
    for page in citing_pages:
        if page.page_type == "baseline":
            size = page.path.stat().st_size
            if size < GOLDILOCKS_MIN_BYTES:
                findings.append(
                    IngestFinding(
                        code="GLK001",
                        severity="warning",
                        path=page.rel_path,
                        message=f"Baseline size ({size} bytes) below Goldilocks minimum (3 KB). Propose consolidating related sources to avoid micro-stubs (ADR-004).",
                    )
                )
            elif size > GOLDILOCKS_MAX_BYTES:
                findings.append(
                    IngestFinding(
                        code="GLK002",
                        severity="warning",
                        path=page.rel_path,
                        message=f"Baseline size ({size} bytes) exceeds Goldilocks ceiling (15 KB). Propose splitting or pruning monolithic baseline (ADR-004).",
                    )
                )

    errors = [f for f in findings if f.severity == "error"]
    total_verified = quotes_verified + sibling_quotes_verified

    if errors:
        return {
            "success": False,
            "source_id": clean_sid,
            "dry_run": dry_run,
            "quotes_verified": quotes_verified,
            "sibling_quotes_verified": sibling_quotes_verified,
            "total_quotes_verified": total_verified,
            "citing_pages": [p.rel_path for p in citing_pages],
            "findings": [{"code": f.code, "severity": f.severity, "path": f.path, "message": f.message} for f in findings],
        }

    if dry_run:
        return {
            "success": True,
            "source_id": clean_sid,
            "dry_run": True,
            "quotes_verified": quotes_verified,
            "sibling_quotes_verified": sibling_quotes_verified,
            "total_quotes_verified": total_verified,
            "citing_pages": [p.rel_path for p in citing_pages],
            "findings": [{"code": f.code, "severity": f.severity, "path": f.path, "message": f.message} for f in findings],
            "message": f"[DRY-RUN OK] Source {clean_sid} valid and ready to close. {quotes_verified} quotes verified.",
        }

    # Execute freeze via shared helper
    final_dest, sha = _freeze_source_files(vault, src_file)

    # Update Sources/.meta.json
    meta = read_sources_meta(vault)
    entry = meta.get(clean_sid, {})
    entry.update(
        {
            "source_id": clean_sid,
            "filename": final_dest.name,
            "sha256": sha,
            "status": "frozen",
            "closed_at": datetime.now().isoformat(),
            "citing_pages": [p.rel_path for p in citing_pages],
            "quotes_verified": quotes_verified,
            "sibling_quotes_verified": sibling_quotes_verified,
        }
    )
    meta[clean_sid] = entry
    write_sources_meta(vault, meta)

    # Append to 08_Ledgers/LDG-Canon_Ingest_Log.md
    log_file = vault.ledgers_dir / "LDG-Canon_Ingest_Log.md"
    if log_file.is_file():
        today = datetime.now().strftime("%Y-%m-%d")
        citing_links = ", ".join(f"[[{p.path.stem}]]" for p in citing_pages)
        log_entry = f"| {today} | {clean_sid} | {src_file.stem} | {citing_links} | `{sha[:12]}` | narr ingest close |\n"
        old_text = read_text(log_file)
        write_text_atomic(log_file, old_text + log_entry)

    # Sync FTS index
    sync_index(vault)

    return {
        "success": True,
        "source_id": clean_sid,
        "dry_run": False,
        "sha256": sha,
        "quotes_verified": quotes_verified,
        "sibling_quotes_verified": sibling_quotes_verified,
        "total_quotes_verified": total_verified,
        "citing_pages": [p.rel_path for p in citing_pages],
        "findings": [{"code": f.code, "severity": f.severity, "path": f.path, "message": f.message} for f in findings],
        "message": f"Source {clean_sid} frozen and logged successfully ({quotes_verified} quotes verified).",
    }


def skip_ingest(vault: Vault, source_id: str, reason: str) -> bool:
    """Record a source as deliberately skipped without compiling, relocating it from inbox to Sources/.

    Args:
        vault: Story bible Vault instance.
        source_id: Source ID to skip.
        reason: Mandatory explanation of why the source is skipped.

    Returns:
        True upon successful recording.

    Raises:
        VaultError: If reason is empty or source file not found.
    """
    clean_reason = reason.strip()
    if not clean_reason:
        raise VaultError("Must provide --reason for skipping source")

    src_file, _is_frozen = find_source_file(vault, source_id)
    if not src_file:
        raise VaultError(f"Source {source_id} not found in Sources/ or Sources/inbox/")

    clean_sid = src_file.stem

    # If in inbox, move file and sidecar to Sources/ via shared helper
    final_dest, _sha = _freeze_source_files(vault, src_file)

    meta = read_sources_meta(vault)
    entry = meta.get(clean_sid, {})
    entry["source_id"] = clean_sid
    entry["filename"] = final_dest.name
    entry["status"] = "skipped"
    entry["skip_reason"] = clean_reason
    entry["skipped_at"] = datetime.now().isoformat()
    meta[clean_sid] = entry
    write_sources_meta(vault, meta)

    # Append to ledger
    log_file = vault.ledgers_dir / "LDG-Canon_Ingest_Log.md"
    if log_file.is_file():
        today = datetime.now().strftime("%Y-%m-%d")
        log_entry = f"| {today} | {clean_sid} | {src_file.stem} | SKIPPED | - | {clean_reason} |\n"
        old_text = read_text(log_file)
        write_text_atomic(log_file, old_text + log_entry)

    # Sync FTS index
    sync_index(vault)

    return True

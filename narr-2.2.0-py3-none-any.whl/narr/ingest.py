"""Canon source capture, FTS candidate planning, quote verification, and freeze-to-ledger ingest (ADR-004 & Second_brain parity)."""

from __future__ import annotations

import hashlib
import json
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from narr.pages import Page, extract_verbatim_quotes
from narr.search import search, sync_index
from narr.vault import Vault, VaultError, is_safe_name, read_text, read_text_or_none, slugify, write_text_atomic

_TYPOGRAPHY = str.maketrans(
    {
        "“": '"',
        "”": '"',
        "‘": "'",
        "’": "'",
        "«": '"',
        "»": '"',
        "—": "-",
        "–": "-",
    }
)


def norm_quote(text: str) -> str:
    """Normalize text for quote matching: NFKC, straight quotes, lowercase, whitespace folding."""
    norm = unicodedata.normalize("NFKC", text).translate(_TYPOGRAPHY)
    return " ".join(norm.split()).lower()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_all_pages(vault: Vault) -> list[Page]:
    pages: list[Page] = []
    for path in vault.markdown_files():
        rel = vault.rel(path)
        p = Page.load(path, rel)
        if p:
            pages.append(p)
    return pages


def find_source_file(vault: Vault, source_id: str) -> tuple[Path | None, bool]:
    """Return (Path, is_frozen) for source_id."""
    for base, is_frozen in [(vault.sources_dir, True), (vault.sources_inbox_dir, False)]:
        for p in sorted(base.glob(f"{source_id}.*")):
            if not p.name.endswith(".json"):
                return p, is_frozen
    return None, False


def read_sources_meta(vault: Vault) -> dict[str, Any]:
    meta_path = vault.sources_meta_path
    if meta_path.is_file():
        try:
            return json.loads(read_text(meta_path)) or {}
        except Exception:
            return {}
    return {}


def write_sources_meta(vault: Vault, data: dict[str, Any]) -> None:
    write_text_atomic(vault.sources_meta_path, json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def capture_source(
    vault: Vault,
    file_path: Path,
    url: str | None = None,
    custom_id: str | None = None,
) -> str:
    """Capture raw source file into Sources/inbox/ with metadata."""
    if not file_path.is_file():
        raise VaultError(f"Source file not found: {file_path}")

    content = file_path.read_bytes()
    sha = hashlib.sha256(content).hexdigest()

    if custom_id:
        if not custom_id.startswith("SRC-") or not is_safe_name(custom_id):
            raise VaultError(f"Custom ID must start with 'SRC-' and be safe filename, got {custom_id}")
        source_id = custom_id
    else:
        date_str = datetime.now().strftime("%Y%m%d")
        slug = slugify(file_path.stem)
        source_id = f"SRC-{date_str}-{slug}"

    ext = file_path.suffix.lower() or ".md"
    dest_name = f"{source_id}{ext}"
    dest_path = vault.sources_inbox_dir / dest_name

    dest_path.write_bytes(content)

    meta = read_sources_meta(vault)
    meta[source_id] = {
        "source_id": source_id,
        "filename": dest_name,
        "captured_at": datetime.now().isoformat(),
        "url": url or "",
        "sha256": sha,
        "status": "inbox",
        "size_bytes": len(content),
    }
    write_sources_meta(vault, meta)
    return source_id


def get_pending(vault: Vault) -> list[dict[str, Any]]:
    """List uncompiled sources: all in inbox, plus frozen sources not cited by any baseline."""
    pages = load_all_pages(vault)
    all_cited_sources: set[str] = set()
    for p in pages:
        sids = p.doc.meta.get("source_ids") or []
        if isinstance(sids, list):
            for s in sids:
                all_cited_sources.add(str(s))
        elif isinstance(sids, str):
            all_cited_sources.add(sids)

    pending: list[dict[str, Any]] = []

    # Inbox sources
    for sf in vault.sources_inbox_dir.iterdir():
        if sf.is_file() and not sf.name.startswith("."):
            sid = sf.stem
            pending.append(
                {
                    "source_id": sid,
                    "status": "inbox",
                    "filename": sf.name,
                    "path": vault.rel(sf),
                }
            )

    # Frozen sources without citations
    meta = read_sources_meta(vault)
    for sf in sorted(vault.sources_dir.iterdir()):
        if sf.is_file() and not sf.name.startswith(".") and not sf.name.endswith(".json") and sf.stem.startswith("SRC-"):
            sid = sf.stem
            if sid not in all_cited_sources and meta.get(sid, {}).get("status") != "skipped":
                pending.append(
                    {
                        "source_id": sid,
                        "status": "frozen",
                        "filename": sf.name,
                        "path": vault.rel(sf),
                    }
                )

    return pending


def plan_ingest(vault: Vault, source_id: str, limit: int = 10) -> dict[str, Any]:
    """Generate context plan for ingesting a source using FTS candidate search."""
    src_file, is_frozen = find_source_file(vault, source_id)
    if not src_file:
        raise VaultError(f"Source {source_id} not found in Sources/ or Sources/inbox/")

    raw_text = read_text_or_none(src_file) or ""
    # Extract candidate title
    lines = raw_text.splitlines()
    title = source_id
    for line in lines:
        if line.startswith("# "):
            title = line[2:].strip()
            break

    pages = load_all_pages(vault)
    citing: list[str] = []
    for p in pages:
        sids = p.doc.meta.get("source_ids") or []
        if source_id in sids or (isinstance(sids, str) and source_id == sids):
            citing.append(p.rel_path)

    # Search existing baselines & story bible for candidate integration targets
    hits = search(vault, query=title if len(title) > 3 else source_id, limit=limit * 2)
    candidate_baselines = [
        {"title": h.title, "path": h.rel_path, "score": h.score, "snippet": h.snippet}
        for h in hits
        if "Baselines" in h.rel_path or "Story_Bible" in h.rel_path
    ][:limit]

    return {
        "source_id": source_id,
        "title": title,
        "status": "frozen" if is_frozen else "inbox",
        "file_path": vault.rel(src_file),
        "size_chars": len(raw_text),
        "right_sizing_guidance": "Target 3 KB to 15 KB per baseline, consolidating 2 to 5 closely related or versioned sources. Avoid 1:1 micro-stubs.",
        "currently_citing_pages": sorted(citing),
        "candidate_pages_to_integrate": candidate_baselines,
    }


@dataclass
class IngestFinding:
    code: str
    severity: str
    path: str
    message: str


def close_ingest(vault: Vault, source_id: str, dry_run: bool = False, pages: list[Page] | None = None) -> dict[str, Any]:
    """Validate quotes and links on citing baselines, then freeze source and record to audit log."""
    src_file, is_frozen = find_source_file(vault, source_id)
    if not src_file:
        raise VaultError(f"Source {source_id} not found in Sources/ or Sources/inbox/")

    raw_source = read_text_or_none(src_file)
    if raw_source is None:
        raise VaultError(f"Source file {src_file.name} is binary or unreadable UTF-8")

    norm_source = norm_quote(raw_source)

    if pages is None:
        pages = load_all_pages(vault)
    citing_pages: list[Page] = []
    for p in pages:
        sids = p.doc.meta.get("source_ids") or []
        if source_id in sids or (isinstance(sids, str) and source_id == sids):
            citing_pages.append(p)

    if not citing_pages:
        raise VaultError(
            f"No page in vault cites source '{source_id}' in 'source_ids: [...]'. "
            f"Integrate or create a baseline in 01_Canon_and_Divergence/Baselines/ first."
        )

    findings: list[IngestFinding] = []
    quotes_verified = 0

    # 1. Verify literal quotes *"..."* against source text
    for page in citing_pages:
        # Support consolidated right-sized baselines (citing 2-5 related sources)
        page_sids = page.doc.meta.get("source_ids") or []
        if isinstance(page_sids, str):
            page_sids = [page_sids]
        sibling_sources: dict[str, str] = {}
        for sid in page_sids:
            if sid != source_id:
                s_file, _ = find_source_file(vault, str(sid))
                if s_file:
                    raw_s = read_text_or_none(s_file)
                    if raw_s:
                        sibling_sources[str(sid)] = norm_quote(raw_s)

        quotes = extract_verbatim_quotes(page.doc.body)
        for q in quotes:
            nq = norm_quote(q)
            if nq in norm_source:
                quotes_verified += 1
            elif any(nq in s_text for s_text in sibling_sources.values()):
                # Grounded in another cited source of this multi-source consolidated baseline
                pass
            else:
                findings.append(
                    IngestFinding(
                        code="QUO001",
                        severity="error",
                        path=page.rel_path,
                        message=f'Literal quote not found in cited source {source_id} or any sibling cited source: *"{q}"*',
                    )
                )

    # 2. Verify wikilinks in citing pages resolve
    all_titles = {p.title for p in pages} | {p.path.stem for p in pages}
    for page in citing_pages:
        for link in page.links:
            if link not in all_titles and not link.startswith("SRC-"):
                findings.append(
                    IngestFinding(
                        code="LNK001",
                        severity="error",
                        path=page.rel_path,
                        message=f"Dead link [[{link}]] on citing page",
                    )
                )

    errors = [f for f in findings if f.severity == "error"]
    if errors:
        return {
            "success": False,
            "source_id": source_id,
            "dry_run": dry_run,
            "quotes_verified": quotes_verified,
            "citing_pages": [p.rel_path for p in citing_pages],
            "findings": [{"code": f.code, "severity": f.severity, "path": f.path, "message": f.message} for f in findings],
        }

    if dry_run:
        return {
            "success": True,
            "source_id": source_id,
            "dry_run": True,
            "quotes_verified": quotes_verified,
            "citing_pages": [p.rel_path for p in citing_pages],
            "findings": [],
            "message": f"[DRY-RUN OK] Source {source_id} valid and ready to close. {quotes_verified} quotes verified.",
        }

    # Execute freeze
    sha = sha256_file(src_file)
    final_dest = vault.sources_dir / src_file.name
    if not is_frozen:
        src_file.replace(final_dest)
        src_file = final_dest

    # Update Sources/.meta.json
    meta = read_sources_meta(vault)
    entry = meta.get(source_id, {})
    entry.update(
        {
            "source_id": source_id,
            "filename": final_dest.name,
            "sha256": sha,
            "status": "frozen",
            "closed_at": datetime.now().isoformat(),
            "citing_pages": [p.rel_path for p in citing_pages],
            "quotes_verified": quotes_verified,
        }
    )
    meta[source_id] = entry
    write_sources_meta(vault, meta)

    # Append to 08_Ledgers/LDG-Canon_Ingest_Log.md
    log_file = vault.ledgers_dir / "LDG-Canon_Ingest_Log.md"
    if log_file.is_file():
        today = datetime.now().strftime("%Y-%m-%d")
        citing_links = ", ".join(f"[[{p.path.stem}]]" for p in citing_pages)
        log_entry = f"| {today} | {source_id} | {src_file.stem} | {citing_links} | `{sha[:12]}` | narr ingest close |\n"
        old_text = read_text(log_file)
        write_text_atomic(log_file, old_text + log_entry)

    # Sync FTS index
    sync_index(vault)

    return {
        "success": True,
        "source_id": source_id,
        "dry_run": False,
        "sha256": sha,
        "quotes_verified": quotes_verified,
        "citing_pages": [p.rel_path for p in citing_pages],
        "findings": [],
        "message": f"Source {source_id} frozen and logged successfully ({quotes_verified} quotes verified).",
    }


def skip_ingest(vault: Vault, source_id: str, reason: str) -> bool:
    """Record a source as deliberately skipped without compiling."""
    if not reason.strip():
        raise VaultError("Must provide --reason for skipping source")

    src_file, _is_frozen = find_source_file(vault, source_id)
    if not src_file:
        raise VaultError(f"Source {source_id} not found in Sources/ or Sources/inbox/")

    meta = read_sources_meta(vault)
    entry = meta.get(source_id, {})
    entry["status"] = "skipped"
    entry["skip_reason"] = reason
    entry["skipped_at"] = datetime.now().isoformat()
    meta[source_id] = entry
    write_sources_meta(vault, meta)

    # Append to ledger
    log_file = vault.ledgers_dir / "LDG-Canon_Ingest_Log.md"
    if log_file.is_file():
        today = datetime.now().strftime("%Y-%m-%d")
        log_entry = f"| {today} | {source_id} | {src_file.stem} | SKIPPED | - | {reason} |\n"
        old_text = read_text(log_file)
        write_text_atomic(log_file, old_text + log_entry)

    return True

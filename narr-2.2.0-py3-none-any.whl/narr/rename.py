"""Safe page renaming with global link refactoring and atomic undo journal (Second_brain rename.py parity / ADR-039)."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from narr.pages import Page
from narr.vault import Vault, read_text_or_none, write_text_atomic


@dataclass
class RenamePlan:
    """Pre-flight plan detailing link rewrites and path transitions.

    Attributes:
        old_rel_path: Original vault-relative path of the target note.
        new_rel_path: Destination vault-relative path.
        target_replacements: Mapping of file path to list of (line_idx, old_line, new_line) changes.
        total_references_updated: Total count of wikilink references updated across the vault.
        old_title: Original frontmatter or note title.
        new_title: Target frontmatter title derived from new stem or explicit name.
    """

    old_rel_path: str
    new_rel_path: str
    target_replacements: dict[str, list[tuple[int, str, str]]]  # file_path -> [(line_idx, old_line, new_line)]
    total_references_updated: int
    old_title: str = ""
    new_title: str = ""


def build_rename_plan(vault: Vault, old_name: str, new_name: str) -> RenamePlan:
    """Scan vault and formulate exact line-by-line replacement plan.

    Args:
        vault: Story bible vault instance.
        old_name: Current note title, UID, or filename stem.
        new_name: Proposed new name, title, or relative path.

    Returns:
        RenamePlan detailing file changes and reference substitutions.

    Raises:
        FileNotFoundError: If the source page cannot be found in the vault.
        FileExistsError: If target path already exists.
    """
    # 1. Resolve old file
    old_file_path: Path | None = None
    old_rel_path: str = ""
    old_stem: str = ""
    old_title: str = ""

    q_clean = old_name.strip().lower()
    for rel_path, entry in vault.entries(".md"):
        p_stem = Path(rel_path).stem.lower()
        if rel_path.lower() == q_clean or p_stem == q_clean:
            old_file_path = vault.root / rel_path
            old_rel_path = rel_path
            old_stem = Path(rel_path).stem
            p = Page.load(old_file_path, rel_path)
            if p and p.title:
                old_title = p.title
            break

    if not old_file_path or not old_file_path.is_file():
        raise FileNotFoundError(f"Source page '{old_name}' not found in vault.")

    # 2. Compute new relative path
    new_clean = new_name.strip()
    if "/" in new_clean or "\\" in new_clean:
        new_rel_path = new_clean.replace("\\", "/")
        if not new_rel_path.endswith(".md"):
            new_rel_path += ".md"
    else:
        new_stem = new_clean[:-3] if new_clean.endswith(".md") else new_clean
        new_rel_path = str(Path(old_rel_path).parent / f"{new_stem}.md").replace("\\", "/")

    new_file_path = vault.root / new_rel_path
    if new_file_path.exists() and new_file_path != old_file_path:
        raise FileExistsError(f"Target path '{new_rel_path}' already exists.")

    new_stem = Path(new_rel_path).stem

    # 3. Identify link patterns to match: [[old_stem]], [[old_stem|...]], [[old_title]]
    targets_to_replace = {old_stem}
    if old_title:
        targets_to_replace.add(old_title)

    # Regex pattern matching [[target]] or [[target|alias]] or [[target#header]]
    escaped_targets = [re.escape(t) for t in targets_to_replace]
    pattern_str = r"\[\[(" + "|".join(escaped_targets) + r")([\|#][^\]]*)?\]\]"
    pattern = re.compile(pattern_str, re.IGNORECASE)

    def replace_link(match: re.Match[str]) -> str:
        suffix = match.group(2) or ""
        return f"[[{new_stem}{suffix}]]"

    # 4. Find all files that contain links to replace
    replacements: dict[str, list[tuple[int, str, str]]] = {}
    total_refs = 0

    for rel_path, entry in vault.entries(".md"):
        f_path = vault.root / rel_path
        txt = read_text_or_none(f_path)
        if not txt:
            continue

        file_changes: list[tuple[int, str, str]] = []
        lines = txt.splitlines(keepends=True)
        for idx, line in enumerate(lines):
            # Do not replace frontmatter uid or title inside the old file itself
            if f_path == old_file_path and (line.startswith("uid:") or line.startswith("title:")):
                continue
            matches = list(pattern.finditer(line))
            if matches:
                new_line = pattern.sub(replace_link, line)
                if new_line != line:
                    file_changes.append((idx, line, new_line))
                    total_refs += len(matches)

        if file_changes:
            replacements[rel_path] = file_changes

    new_title = new_stem.replace("_", " ")
    return RenamePlan(
        old_rel_path=old_rel_path,
        new_rel_path=new_rel_path,
        target_replacements=replacements,
        total_references_updated=total_refs,
        old_title=old_title,
        new_title=new_title,
    )


def execute_rename(vault: Vault, plan: RenamePlan, dry_run: bool = False) -> dict[str, Any]:
    """Execute rename plan atomically and write undo journal.

    Args:
        vault: Story bible vault instance.
        plan: Prepared RenamePlan instance.
        dry_run: If True, preview planned changes without disk modifications.

    Returns:
        Status dictionary reporting affected files and updated reference count.
    """
    if dry_run:
        return {
            "status": "dry_run",
            "old_path": plan.old_rel_path,
            "new_path": plan.new_rel_path,
            "files_affected": len(plan.target_replacements),
            "references_updated": plan.total_references_updated,
        }

    journal_dir = vault.root / ".narr"
    journal_dir.mkdir(parents=True, exist_ok=True)
    journal_file = journal_dir / "mv_journal.jsonl"

    old_file = vault.root / plan.old_rel_path
    old_stem = Path(plan.old_rel_path).stem
    new_stem = Path(plan.new_rel_path).stem

    # Record journal entry first
    journal_entry = {
        "timestamp": datetime.now(UTC).isoformat(),
        "action": "rename",
        "old_path": plan.old_rel_path,
        "new_path": plan.new_rel_path,
        "old_stem": old_stem,
        "new_stem": new_stem,
        "old_title": plan.old_title,
        "new_title": plan.new_title,
        "replacements": [
            {"path": p, "changes": [[idx, old, new] for idx, old, new in changes]} for p, changes in plan.target_replacements.items()
        ],
    }
    with journal_file.open("a", encoding="utf-8") as jf:
        jf.write(json.dumps(journal_entry) + "\n")

    # Move the file
    new_file = vault.root / plan.new_rel_path
    new_file.parent.mkdir(parents=True, exist_ok=True)
    old_file.rename(new_file)

    # Update frontmatter UID and title inside new_file
    new_content = read_text_or_none(new_file)
    if new_content:
        updated_content = re.sub(
            r'^(uid:\s*["\']?)[^"\'\r\n]+(["\']?)',
            rf"\g<1>{new_stem}\g<2>",
            new_content,
            flags=re.MULTILINE,
        )
        if plan.new_title:
            updated_content = re.sub(
                r'^(title:\s*["\']?)[^"\'\r\n]+(["\']?)',
                rf"\g<1>{plan.new_title}\g<2>",
                updated_content,
                flags=re.MULTILINE,
            )
        if updated_content != new_content:
            write_text_atomic(new_file, updated_content)

    # Update line content across affected referencing files
    for r_path, changes in plan.target_replacements.items():
        actual_path = new_file if r_path == plan.old_rel_path else vault.root / r_path
        txt = read_text_or_none(actual_path)
        if txt is None:
            continue
        lines = txt.splitlines(keepends=True)
        for idx, _, new_line in changes:
            if idx < len(lines):
                lines[idx] = new_line
        write_text_atomic(actual_path, "".join(lines))

    return {
        "status": "applied",
        "old_path": plan.old_rel_path,
        "new_path": plan.new_rel_path,
        "files_affected": len(plan.target_replacements),
        "references_updated": plan.total_references_updated,
    }


def undo_last_rename(vault: Vault) -> dict[str, Any]:
    """Roll back the last recorded rename from the journal.

    Args:
        vault: Story bible vault instance.

    Returns:
        Status dictionary confirming reverted paths.

    Raises:
        FileNotFoundError: If journal does not exist or target file is missing.
        ValueError: If journal is empty or invalid.
    """
    journal_file = vault.root / ".narr" / "mv_journal.jsonl"
    if not journal_file.is_file():
        raise FileNotFoundError("No rename journal found in .narr/mv_journal.jsonl")

    lines = [l.strip() for l in journal_file.read_text(encoding="utf-8").splitlines() if l.strip()]
    if not lines:
        raise ValueError("Rename journal is empty.")

    last_entry = json.loads(lines[-1])
    if last_entry.get("action") != "rename":
        raise ValueError("Last journal entry is not a rename action.")

    old_path = last_entry["old_path"]
    new_path = last_entry["new_path"]
    old_stem = last_entry.get("old_stem") or Path(old_path).stem
    replacements = last_entry.get("replacements", [])

    current_file = vault.root / new_path
    restored_file = vault.root / old_path

    if not current_file.exists():
        raise FileNotFoundError(f"Cannot undo: '{new_path}' does not exist.")

    # Revert frontmatter UID and title in current_file before moving back
    curr_txt = read_text_or_none(current_file)
    if curr_txt:
        reverted_fm = re.sub(
            r'^(uid:\s*["\']?)[^"\'\r\n]+(["\']?)',
            rf"\g<1>{old_stem}\g<2>",
            curr_txt,
            flags=re.MULTILINE,
        )
        old_title = last_entry.get("old_title")
        if old_title:
            reverted_fm = re.sub(
                r'^(title:\s*["\']?)[^"\'\r\n]+(["\']?)',
                rf"\g<1>{old_title}\g<2>",
                reverted_fm,
                flags=re.MULTILINE,
            )
        if reverted_fm != curr_txt:
            write_text_atomic(current_file, reverted_fm)

    # Revert file content across referencing notes
    for item in replacements:
        r_path = item["path"]
        target_f = current_file if r_path == old_path else vault.root / r_path
        txt = read_text_or_none(target_f)
        if txt is None:
            continue
        flines = txt.splitlines(keepends=True)
        for idx, old_line, _ in item["changes"]:
            if idx < len(flines):
                flines[idx] = old_line
        write_text_atomic(target_f, "".join(flines))

    # Move file back
    restored_file.parent.mkdir(parents=True, exist_ok=True)
    current_file.rename(restored_file)

    # Pop last entry from journal
    write_text_atomic(journal_file, "\n".join(lines[:-1]) + ("\n" if len(lines) > 1 else ""))

    return {
        "status": "undone",
        "reverted_from": new_path,
        "restored_to": old_path,
    }

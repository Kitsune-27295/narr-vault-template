"""Safe page renaming with global link refactoring and atomic undo journal (Second_brain rename.py parity / ADR-039)."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from narr.pages import Page
from narr.vault import Vault, read_text_or_none


@dataclass
class RenamePlan:
    old_rel_path: str
    new_rel_path: str
    target_replacements: dict[str, list[tuple[int, str, str]]]  # file_path -> [(line_idx, old_line, new_line)]
    total_references_updated: int


def build_rename_plan(vault: Vault, old_name: str, new_name: str) -> RenamePlan:
    """Scan vault and formulate exact line-by-line replacement plan."""
    # 1. Resolve old file
    old_file_path: Path | None = None
    old_rel_path: str = ""
    old_stem: str = ""
    old_title: str = ""

    q_clean = old_name.strip().lower()
    for rel_path, entry in vault.entries(".md"):
        p_stem = Path(rel_path).stem.lower()
        if rel_path.lower() == q_clean or p_stem == q_clean:
            old_file_path = vault.root / rel_path
            old_rel_path = rel_path
            old_stem = Path(rel_path).stem
            p = Page.load(old_file_path, rel_path)
            if p and p.title:
                old_title = p.title
            break

    if not old_file_path or not old_file_path.is_file():
        raise FileNotFoundError(f"Source page '{old_name}' not found in vault.")

    # 2. Compute new relative path
    new_clean = new_name.strip()
    if "/" in new_clean or "\\" in new_clean:
        new_rel_path = new_clean.replace("\\", "/")
        if not new_rel_path.endswith(".md"):
            new_rel_path += ".md"
    else:
        new_stem = new_clean[:-3] if new_clean.endswith(".md") else new_clean
        new_rel_path = str(Path(old_rel_path).parent / f"{new_stem}.md").replace("\\", "/")

    new_file_path = vault.root / new_rel_path
    if new_file_path.exists() and new_file_path != old_file_path:
        raise FileExistsError(f"Target path '{new_rel_path}' already exists.")

    new_stem = Path(new_rel_path).stem

    # 3. Identify link patterns to match: [[old_stem]], [[old_stem|...]], [[old_title]]
    targets_to_replace = {old_stem}
    if old_title:
        targets_to_replace.add(old_title)

    # Regex pattern matching [[target]] or [[target|alias]] or [[target#header]]
    escaped_targets = [re.escape(t) for t in targets_to_replace]
    pattern_str = r"\[\[(" + "|".join(escaped_targets) + r")([\|#][^\]]*)?\]\]"
    pattern = re.compile(pattern_str, re.IGNORECASE)

    def replace_link(match: re.Match) -> str:
        suffix = match.group(2) or ""
        return f"[[{new_stem}{suffix}]]"

    # 4. Find all files that contain links to replace
    replacements: dict[str, list[tuple[int, str, str]]] = {}
    total_refs = 0

    for rel_path, entry in vault.entries(".md"):
        f_path = vault.root / rel_path
        txt = read_text_or_none(f_path)
        if not txt:
            continue

        file_changes: list[tuple[int, str, str]] = []
        lines = txt.splitlines(keepends=True)
        for idx, line in enumerate(lines):
            # Do not replace frontmatter uid or title inside the old file itself
            if f_path == old_file_path and (line.startswith("uid:") or line.startswith("title:")):
                continue
            if pattern.search(line):
                new_line = pattern.sub(replace_link, line)
                if new_line != line:
                    file_changes.append((idx, line, new_line))
                    total_refs += 1

        if file_changes:
            replacements[rel_path] = file_changes

    return RenamePlan(
        old_rel_path=old_rel_path,
        new_rel_path=new_rel_path,
        target_replacements=replacements,
        total_references_updated=total_refs,
    )


def execute_rename(vault: Vault, plan: RenamePlan, dry_run: bool = False) -> dict[str, Any]:
    """Execute rename plan atomically and write undo journal."""
    if dry_run:
        return {
            "status": "dry_run",
            "old_path": plan.old_rel_path,
            "new_path": plan.new_rel_path,
            "files_affected": len(plan.target_replacements),
            "references_updated": plan.total_references_updated,
        }

    journal_dir = vault.root / ".narr"
    journal_dir.mkdir(parents=True, exist_ok=True)
    journal_file = journal_dir / "mv_journal.jsonl"

    # Record journal entry first
    journal_entry = {
        "timestamp": datetime.now(UTC).isoformat(),
        "action": "rename",
        "old_path": plan.old_rel_path,
        "new_path": plan.new_rel_path,
        "replacements": [
            {"path": p, "changes": [[idx, old, new] for idx, old, new in changes]} for p, changes in plan.target_replacements.items()
        ],
    }
    with journal_file.open("a", encoding="utf-8") as jf:
        jf.write(json.dumps(journal_entry) + "\n")

    # Move the file
    old_file = vault.root / plan.old_rel_path
    new_file = vault.root / plan.new_rel_path
    new_file.parent.mkdir(parents=True, exist_ok=True)
    old_file.rename(new_file)

    # Update line content across affected files
    for r_path, changes in plan.target_replacements.items():
        actual_path = new_file if r_path == plan.old_rel_path else vault.root / r_path
        txt = read_text_or_none(actual_path)
        if txt is None:
            continue
        lines = txt.splitlines(keepends=True)
        for idx, _, new_line in changes:
            if idx < len(lines):
                lines[idx] = new_line
        actual_path.write_text("".join(lines), encoding="utf-8")

    return {
        "status": "applied",
        "old_path": plan.old_rel_path,
        "new_path": plan.new_rel_path,
        "files_affected": len(plan.target_replacements),
        "references_updated": plan.total_references_updated,
    }


def undo_last_rename(vault: Vault) -> dict[str, Any]:
    """Roll back the last recorded rename from the journal."""
    journal_file = vault.root / ".narr" / "mv_journal.jsonl"
    if not journal_file.is_file():
        raise FileNotFoundError("No rename journal found in .narr/mv_journal.jsonl")

    lines = [l.strip() for l in journal_file.read_text(encoding="utf-8").splitlines() if l.strip()]
    if not lines:
        raise ValueError("Rename journal is empty.")

    last_entry = json.loads(lines[-1])
    if last_entry.get("action") != "rename":
        raise ValueError("Last journal entry is not a rename action.")

    old_path = last_entry["old_path"]
    new_path = last_entry["new_path"]
    replacements = last_entry.get("replacements", [])

    current_file = vault.root / new_path
    restored_file = vault.root / old_path

    if not current_file.exists():
        raise FileNotFoundError(f"Cannot undo: '{new_path}' does not exist.")

    # Revert file content
    for item in replacements:
        r_path = item["path"]
        target_f = current_file if r_path == old_path else vault.root / r_path
        txt = read_text_or_none(target_f)
        if txt is None:
            continue
        flines = txt.splitlines(keepends=True)
        for idx, old_line, _ in item["changes"]:
            if idx < len(flines):
                flines[idx] = old_line
        target_f.write_text("".join(flines), encoding="utf-8")

    # Move file back
    restored_file.parent.mkdir(parents=True, exist_ok=True)
    current_file.rename(restored_file)

    # Pop last entry from journal
    journal_file.write_text("\n".join(lines[:-1]) + ("\n" if len(lines) > 1 else ""), encoding="utf-8")

    return {
        "status": "undone",
        "reverted_from": new_path,
        "restored_to": old_path,
    }
